<?php

$file = getcwd () .'/11.txt';
$content = file_get_contents ($file);
$a = preg_split ('/,/', $content);
//print_r ($a) ."\n";

foreach ($a as $key => $value) {
	$value = trim ($value);
	$str = 'https://www.eliteprospects.com/team/'.$value.'/a';
	print $str ."\t". 1 . "\n";
}

?>