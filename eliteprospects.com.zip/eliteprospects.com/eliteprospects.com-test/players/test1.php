<?php

$file = getcwd() .'/1.txt';
$content = file_get_contents ($file);
if (preg_match_all ('/\'(.+?)\'/ui', $content, $a1)) {
	foreach ($a1[1] as $key1 => $value1) {
		
		print $value1 ."\t". 1 . "\n";
	}
}
?>