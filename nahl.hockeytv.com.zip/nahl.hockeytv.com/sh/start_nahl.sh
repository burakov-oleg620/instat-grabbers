
#killall screen

screen -X -S p001 quit
screen -X -S p002 quit
screen -X -S p003 quit
screen -wipe

cd /usr/local/www/parservideo/workdir1/grabers/nahl.hockeytv.com/ && rm -f lockfile.txt
screen -d -m -S p001 bash -c "cd /usr/local/www/parservideo/workdir1/grabers/nahl.hockeytv.com/ && /usr/local/bin/php ./start2.php"

cd /usr/local/www/parservideo/workdir1/grabers/nahl.hockeytv.com-perl/ && rm -f lock_graber.txt
screen -d -m -S p002 bash -c "cd /usr/local/www/parservideo/workdir1/grabers/nahl.hockeytv.com-perl/ && /usr/local/bin/perl ./start2.pl"

cd /usr/local/www/parservideo/workdir1/grabers/nahl.hockeytv.com-perl2/ && rm -f lock_graber.txt
screen -d -m -S p003 bash -c "cd /usr/local/www/parservideo/workdir1/grabers/nahl.hockeytv.com-perl2/ && /usr/local/bin/perl ./start2.pl"


