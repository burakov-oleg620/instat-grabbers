<?php


$file = getcwd () .'/screen_check.txt';

if (is_file ($file)) {
	unlink ($file) or die;
}

$system = 'screen -x > '.$file;
system ($system);


$content = file_get_contents ($file);
$content = str_replace (array ("\n", "\r", "\t"), ' ', $content);


$g1 = array ();
if (preg_match_all ('/p(\d+)/ui', $content, $a1)) {
	foreach ($a1[1] as $key1 => $value1) {
		//print $value1 ."\n";
		//array_push ($g, $value1);
		$g1[$value1] = $value1;
		
	}
}

asort ($g1);
print_r ($g1) ."\n";

$g2 = array ();
if (preg_match_all ('/(Dead)/ui', $content, $a1)) {
	foreach ($a1[1] as $key1 => $value1) {
		//print $value1 ."\n";
		array_push ($g2, $value1);
		//$g2[$value1] = $value1;
	}
}

asort ($g2);
print_r ($g2) ."\n";


if (count ($g1) != 3 or count ($g2) > 0) {
				
	$system = './start_nahl.sh';
	system ($system);
	
	
	//$system = 'screen -d -m -S p'.$key1.' bash -c "cd /home/parser/vk2/workdir'.$value1.'/grabers/vk.com-php-users/ && sh start1"';
	// foreach ($users_a as $key1 => $value1) {
		// if (!isset ($g[$key1])) {
			
			// $system = 'screen -d -m -S p'.$key1.' bash -c "cd /home/parser/vk2/workdir'.$value1.'/grabers/vk.com-php-users/ && sh start1"';
			// print   $system ."\n";
			
			// system ($system);
			// sleep (5*60);
			
		// }
	// }
}













function good_str ($str) {
	while (mb_strlen ($str) < 3) {
		$str = '0'.$str;
	}
	return $str;
}


?>