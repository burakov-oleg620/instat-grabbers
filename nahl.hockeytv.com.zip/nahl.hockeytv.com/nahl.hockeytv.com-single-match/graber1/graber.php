<?php
	set_time_limit(0);
	
	include 'put_content_to_file_inc.php';    
	include 'get_base_path_inc.php';
	include 'clear_str_inc.php';
	include 'work_for_content_inc.php';
	include 'work_for_txt1_inc.php';
	include 'write_text_file_rewrite_inc.php';
	include 'simple_html_dom.php';
	include 'work_ini_file_inc.php';
	include 'work_mysql_graber_inc.php';
	include 'get_file_from_url_inc.php';
	include 'clear_dir_inc.php';
	include 'idna_convert.class.php';
	
	$work_ini_file = new work_ini_file ('graber.ini');
	$host_mysql = $work_ini_file -> get ('host_mysql');
	$user = $work_ini_file -> get ('user');
	$password = $work_ini_file -> get ('password');
	$table = $work_ini_file -> get ('table');
	$database = $work_ini_file -> get ('database');
	$host = $work_ini_file -> get ('host');
	$count_limit = $work_ini_file -> get ('count_limit');
	$count_start_from_ini = $work_ini_file -> get ('count_start_from_ini');

	$sleep1 = $work_ini_file -> get ('sleep1');
	$sleep2 = $work_ini_file -> get ('sleep2');
	
	
	$proxyip = '127.0.0.1:8080';
	

	//авторизация
	$url = "https://api.hockeytv.com/sessions/api_key";
	$curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, '{"email":"alexey.shishov@instatsport.com","password":"CSKA_champion1911!"}');
    curl_setopt($curl, CURLOPT_HTTPHEADER, ['APP_KEY: 098f6bcd4621d373cade4e832627b4f6']);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false); 	
	//curl_setopt($curl, CURLOPT_PROXY, $proxyip);
    $contents = curl_exec($curl);
	$info = curl_getinfo($curl);
	print $info ['http_code']."\t". $url ."\n";
	curl_close($curl);
	
    var_dump($contents);

    $contents = @json_decode($contents, true);
    $apiKey = $contents['api_key'];
    
	var_dump($apiKey);
	
	
	
	

    // $curl = curl_init();
    // curl_setopt($curl, CURLOPT_URL, 'http://api.hockeytv.com/users/495419/profile');
    // curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    // curl_setopt($curl, CURLOPT_HTTPHEADER, ['APP_KEY: 098f6bcd4621d373cade4e832627b4f6', "API_KEY: $apiKey"]);
	// curl_setopt($curl, CURLOPT_PROXY, $proxyip);
    // $contents = curl_exec($curl);
    // $info = curl_getinfo($curl);
    // curl_close($curl);

     // var_dump($contents);
	 
    // //print_r($info);
	
	
	
	$count = 0;
	$workdir = getcwd () .'/xls';
	$dh = opendir ($workdir) or die;
	while ($file = readdir ($dh)) {
		if ($file != '.' and $file != '..') {
			$file = $workdir.'/'.$file;
			$pattern = '/xls$/';
			preg_match ($pattern, $file, $array);
			if (count ($array) > 0) {
				$file_array = array ();
				$fh = fopen ($file, 'r') or die;
				while ($str = fgets ($fh)) {
					$clear_str = new clear_str ($str);
					$str = $clear_str -> delete_2 ();
					unset ($clear_str); 
					
					if (preg_match ('/\t/', $str)) {
						print ++$count ."\n";
						
						$temp1 = array ();
						$temp1 = preg_split ('/\t/', $str);				
						
						
						// print '*count = ' . count ($temp) ."\n";
						
						if (count ($temp1) > 1) {
							foreach ($temp1 as $key => $value) {
								$clear_str = new clear_str ($temp1 [$key]);
								$temp1 [$key] = $clear_str -> delete_2 ();
								unset ($clear_str); 
							}
							
							$game_id = $temp1[0];
							$game_id = preg_replace ('/^.+\//', '', $game_id);
							
														
							if (preg_match ('/\d+/ui', $game_id)) {
								$game_ok = 'ok';
							}
							
							if ($game_ok == 'ok') {
							
								//информация по матчу
								$url = 'http://api.hockeytv.com/games/'.$game_id.'?include[]=preroll&include[]=user_started&include[]=lineup';
								$curl = curl_init();
								curl_setopt($curl, CURLOPT_URL, $url);
								curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
								curl_setopt($curl, CURLOPT_HTTPHEADER, ['APP_KEY: 098f6bcd4621d373cade4e832627b4f6', "API_KEY: $apiKey"]);
								//curl_setopt($curl, CURLOPT_PROXY, $proxyip);
								$contents = curl_exec($curl);
								
								$rand = rand ($sleep1, $sleep2);
								sleep ($rand);
								
								$info = curl_getinfo($curl);
								print $info ['http_code']."\t". $url ."\n";
								curl_close($curl);
								//var_dump($contents);

								$file = 'http_'.MD5 ($url) .'_'.$game_id.'.html';
								$file = getcwd () .'/html/'.$file;
								$put_content_to_file = new put_content_to_file ($contents, $file);
								$put_content_to_file -> put ();
								unset ($put_content_to_file);
								
							
								//игроки
								//$url = 'http://api.hockeytv.com/games/913052/roster';
								$url = 'http://api.hockeytv.com/games/'.$game_id.'/roster';
								$curl = curl_init();
								curl_setopt($curl, CURLOPT_URL, $url);
								curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
								curl_setopt($curl, CURLOPT_HTTPHEADER, ['APP_KEY: 098f6bcd4621d373cade4e832627b4f6', "API_KEY: $apiKey"]);
								//curl_setopt($curl, CURLOPT_PROXY, $proxyip);
								$contents = curl_exec($curl);
								
								$rand = rand ($sleep1, $sleep2);
								sleep ($rand);
								
								$info = curl_getinfo($curl);
								print $info ['http_code']."\t". $url ."\n";
								curl_close($curl);
								//var_dump($contents);

								$file = 'http_'.MD5 ($url) .'_'.$game_id.'.html';
								$file = getcwd () .'/picture/'.$file;
								$put_content_to_file = new put_content_to_file ($contents, $file);
								$put_content_to_file -> put ();
								unset ($put_content_to_file);
								
								
								
								//видео по матчу1
								$curl = curl_init();
								curl_setopt($curl, CURLOPT_URL, 'http://api.hockeytv.com/games/'.$game_id.'/stream_url/1');
								curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
								curl_setopt($curl, CURLOPT_HTTPHEADER, ['APP_KEY: 098f6bcd4621d373cade4e832627b4f6', "API_KEY: $apiKey"]);
								//curl_setopt($curl, CURLOPT_PROXY, $proxyip);
								$contents = curl_exec($curl);
								
								$rand = rand ($sleep1, $sleep2);
								sleep ($rand);
								
								$info = curl_getinfo($curl);
								print $info ['http_code']."\t". $url ."\n";
								curl_close($curl);
								//var_dump($contents);
								
								$file = 'http_'.MD5 ($url) .'_'.$game_id.'.html';
								$file = getcwd () .'/outa/'.$file;
								$put_content_to_file = new put_content_to_file ($contents, $file);
								$put_content_to_file -> put ();
								unset ($put_content_to_file);
								
								
								
								//видео по матчу2
								
								$json = @json_decode($contents, true);
								if (isset ($json ['video'])) {
								
									$url =  $json ['video'];
									$url = preg_replace ('/https:/ui', 'http:', $url);
									
									
									$curl = curl_init();
									curl_setopt($curl, CURLOPT_URL, $url);
									curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
									curl_setopt($curl, CURLOPT_HTTPHEADER, ['APP_KEY: 098f6bcd4621d373cade4e832627b4f6', "API_KEY: $apiKey"]);
									//curl_setopt($curl, CURLOPT_PROXY, $proxyip);
									$contents = curl_exec($curl);
									
									$rand = rand ($sleep1, $sleep2);
									sleep ($rand);
									
									$info = curl_getinfo($curl);
									print $info ['http_code']."\t". $url ."\n";
									curl_close($curl);
									//var_dump($contents);
									
									$file = 'http_'.MD5 ($url) .'_'.$game_id.'.html';
									$file = getcwd () .'/outb/'.$file;
									$put_content_to_file = new put_content_to_file ($contents, $file);
									$put_content_to_file -> put ();
									unset ($put_content_to_file);
									
									$contents = str_replace (array ("\t", "\r", "\n"), ' ', $contents);
									
									$array = array ();					
									$pattern1 = '/\s+(http.+?)\s+/'; 
									$work_for_content1 = new work_for_content ($contents);
									$array1 = $work_for_content1 -> get_pattern ($pattern1);
									foreach ($array1[1] as $value1) {
									
										$value1 = strip_tags (html_entity_decode ($value1));
										$value1 = replace ('^\s+','', $value1);
										$value1 = replace ('\s+$','', $value1);
										$value1 = replace ('\s+',' ', $value1);
										$value1 = preg_replace ('/https:/', 'http:', $value1);
										
										array_push ($array, $value1);
									}
									
									
									
									if (count ($array) > 0) {
									
										$url =  $array[0];
										
										$curl = curl_init();
										curl_setopt($curl, CURLOPT_URL, $url);
										curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
										curl_setopt($curl, CURLOPT_HTTPHEADER, ['APP_KEY: 098f6bcd4621d373cade4e832627b4f6', "API_KEY: $apiKey"]);
										//curl_setopt($curl, CURLOPT_PROXY, $proxyip);
										$contents = curl_exec($curl);
										
										$rand = rand ($sleep1, $sleep2);
										sleep ($rand);
										
										$info = curl_getinfo($curl);
										print $info ['http_code']."\t". $url ."\n";
										curl_close($curl);
										//var_dump($contents);
										
										//$file = 'http_'.MD5 ($url) .'.html';
										$file = 'http_'.$game_id .'.html';
										$file = getcwd () .'/outc/'.$file;
										$put_content_to_file = new put_content_to_file ($contents, $file);
										$put_content_to_file -> put ();
										unset ($put_content_to_file);
									
									}
								}
							}
								
							
							
							
							
							
							
							
	


							
							// $curl = curl_init();
							// curl_setopt($curl, CURLOPT_URL, 'http://api.hockeytv.com/games/913052/played');
							// curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
							// curl_setopt($curl, CURLOPT_HTTPHEADER, ['APP_KEY: 098f6bcd4621d373cade4e832627b4f6', "API_KEY: $apiKey"]);
							// curl_setopt($curl, CURLOPT_POSTFIELDS,array ());
							// //curl_setopt($curl, CURLOPT_PROXY, $proxyip);
							// $contents = curl_exec($curl);
							// $info = curl_getinfo($curl);
							// curl_close($curl);
							// var_dump($contents);
						}
					}
				}
			}
		}
	}

	function replace ($pattern1, $pattern2, $content) { 
		$pattern1 = '/'.$pattern1.'/u';
		$content = preg_replace ($pattern1, $pattern2, $content);
		return $content;
	}	
	
?>	