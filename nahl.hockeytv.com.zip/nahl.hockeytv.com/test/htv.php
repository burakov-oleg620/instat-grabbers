<?php
    
	$proxyip = '127.0.0.1:8080';
	
	$curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, "http://api.hockeytv.com/sessions/api_key");
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, '{"email":"alexey.shishov@instatsport.com","password":"CSKA_champion1911!"}');
    curl_setopt($curl, CURLOPT_HTTPHEADER, ['APP_KEY: 098f6bcd4621d373cade4e832627b4f6']);
	//curl_setopt($curl, CURLOPT_PROXY, $proxyip);
    $contents = curl_exec($curl);
    curl_close($curl);

    var_dump($contents);

    $contents = @json_decode($contents, true);
    $apiKey = $contents['api_key'];

    var_dump($apiKey);

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, 'http://api.hockeytv.com/users/495419/profile');
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, ['APP_KEY: 098f6bcd4621d373cade4e832627b4f6', "API_KEY: $apiKey"]);
	//curl_setopt($curl, CURLOPT_PROXY, $proxyip);
    $contents = curl_exec($curl);
    $info = curl_getinfo($curl);
    curl_close($curl);

     var_dump($contents);
	 
    // //print_r($info);
	
	
    // $curl = curl_init();
    // curl_setopt($curl, CURLOPT_URL, 'http://api.hockeytv.com/schedule/search?date_disabled=false&limit=10&limit_favorites=false&offset=0&start_date=2018-04-16T00:00:00.000Z');
    // curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    // curl_setopt($curl, CURLOPT_HTTPHEADER, ['APP_KEY: 098f6bcd4621d373cade4e832627b4f6', "API_KEY: $apiKey"]);
	// //curl_setopt($curl, CURLOPT_PROXY, $proxyip);
    // $contents = curl_exec($curl);
    // $info = curl_getinfo($curl);
    // curl_close($curl);

    // var_dump($contents);
	
	
    // $curl = curl_init();
    // curl_setopt($curl, CURLOPT_URL, 'http://api.hockeytv.com/games/913052?include%5B%5D=preroll&include%5B%5D=user_started&include%5B%5D=lineup');
    // curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    // curl_setopt($curl, CURLOPT_HTTPHEADER, ['APP_KEY: 098f6bcd4621d373cade4e832627b4f6', "API_KEY: $apiKey"]);
	// //curl_setopt($curl, CURLOPT_PROXY, $proxyip);
    // $contents = curl_exec($curl);
    // $info = curl_getinfo($curl);
    // curl_close($curl);
	// var_dump($contents);

	
	
    // $curl = curl_init();
    // curl_setopt($curl, CURLOPT_URL, 'http://api.hockeytv.com/games/913052/stream_url/1');
    // curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    // curl_setopt($curl, CURLOPT_HTTPHEADER, ['APP_KEY: 098f6bcd4621d373cade4e832627b4f6', "API_KEY: $apiKey"]);
	// //curl_setopt($curl, CURLOPT_PROXY, $proxyip);
    // $contents = curl_exec($curl);
    // $info = curl_getinfo($curl);
    // curl_close($curl);
	// var_dump($contents);
	
	
    // $curl = curl_init();
    // curl_setopt($curl, CURLOPT_URL, 'http://api.hockeytv.com/games/913052/live_lookin/');
    // curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    // curl_setopt($curl, CURLOPT_HTTPHEADER, ['APP_KEY: 098f6bcd4621d373cade4e832627b4f6', "API_KEY: $apiKey"]);
	// //curl_setopt($curl, CURLOPT_PROXY, $proxyip);
    // $contents = curl_exec($curl);
    // $info = curl_getinfo($curl);
    // curl_close($curl);
	// var_dump($contents);
	
	// //[] пусто
    // $curl = curl_init();
    // curl_setopt($curl, CURLOPT_URL, 'http://api.hockeytv.com/games/913052/clips?limit=250&offset=1');
	
    // curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    // curl_setopt($curl, CURLOPT_HTTPHEADER, ['APP_KEY: 098f6bcd4621d373cade4e832627b4f6', "API_KEY: $apiKey"]);
	// //curl_setopt($curl, CURLOPT_PROXY, $proxyip);
    // $contents = curl_exec($curl);
    // $info = curl_getinfo($curl);
    // curl_close($curl);
	// var_dump($contents);

	
    // $curl = curl_init();
    // curl_setopt($curl, CURLOPT_URL, 'http://api.hockeytv.com/games/913052/roster');
    // curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    // curl_setopt($curl, CURLOPT_HTTPHEADER, ['APP_KEY: 098f6bcd4621d373cade4e832627b4f6', "API_KEY: $apiKey"]);
	// //curl_setopt($curl, CURLOPT_PROXY, $proxyip);
    // $contents = curl_exec($curl);
    // $info = curl_getinfo($curl);
    // curl_close($curl);
	// var_dump($contents);
	
    // $curl = curl_init();
    // curl_setopt($curl, CURLOPT_URL, 'http://api.hockeytv.com/games/913052/played');
    // curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    // curl_setopt($curl, CURLOPT_HTTPHEADER, ['APP_KEY: 098f6bcd4621d373cade4e832627b4f6', "API_KEY: $apiKey"]);
	// curl_setopt($curl, CURLOPT_POSTFIELDS,array ());
	// //curl_setopt($curl, CURLOPT_PROXY, $proxyip);
    // $contents = curl_exec($curl);
    // $info = curl_getinfo($curl);
    // curl_close($curl);
	// var_dump($contents);
	
	
	
	
	
?>	