#!/usr/bin/env perl
use strict;
use warnings;
use File::Path;
use Encode qw (decode encode);
use locale;
use List::Util qw (shuffle);

use threads;
use threads::shared;
use Thread::Queue;

use URI::URL;
use JSON::XS;

use LWP::UserAgent;
use HTTP::Request;
use HTTP::Response;
use HTTP::Cookies;
use URI::Escape;

use HTML::TreeBuilder::XPath;
# use LWP::Protocol::http;
# use Mozilla::CA;


#создаю экземпляр броузера
my $lwp = undef;
$lwp = LWP::UserAgent -> new ();
$lwp -> cookie_jar (HTTP::Cookies->new ());
$lwp -> agent ('Mozilla/5.0 (Windows NT 6.1; rv:47.0) Gecko/20100101 Firefox/47.0');
# $lwp ->ssl_opts( SSL_ca_file => Mozilla::CA::SSL_ca_file() );
$lwp -> timeout (60);
# $lwp -> proxy (['http', 'https'], 'http://127.0.0.1:8080');

# if (!-d 'c:/windows') {
	# my $ppp = get_ppp ();
	# $lwp -> proxy (['http', 'https'], 'http://'.$ppp);
# }

my $insert = {};
$insert = login ($insert);

# $insert = login_options ($insert);
# $insert = get_sessions ($insert);

$insert = get_profile ($insert);


# $insert = get_1 ($insert);

exit;






sub get_content_from_file {
	my $file = shift;
	my @file = ();
	open (my $fh, $file) or die;
	while (<$fh>) {push (@file, $_);}
	close ($fh); 
	my $pattern = ''; my $str = join ($pattern, @file); 
	return $str;
}

sub get_base_path {
	use Cwd; 
	my $cwd = getcwd ();
	return $cwd;
}

sub put_content_to_file {
	my $content = shift;
	my $file = shift;
	open (my $fh, '>'.$file) or die;
	print $fh $content; 
	close ($fh);
}

sub utf8_to_win1251 {
	use Encode qw (encode decode); 
	my $str = shift;
	$str = encode ('cp1251', decode ('utf8', $str)); 
	return $str;
}

sub entities_decode {
	use HTML::Entities;
	my $str = shift;
	#перед отдачей модулю нужно сделать decode с любой кодировки
	$str = decode ('cp1251', $str);
	$str = decode_entities ($str);
	$str = encode ('cp1251', $str);
	return $str;
}


sub Random {
	my $from = shift;
	my $to = shift;
	my $random = $from + rand(($to - $from));
	return $random;
}



sub login {
	my $insert = shift;
	# my $url = 'https://api.hockeytv.com/sessions/api_key';
	my $url = 'http://api.hockeytv.com/sessions/api_key';
	my $postdata = '{"email":"alexey.shishov@instatsport.com","password":"CSKA_champion1911!"}';
	
	push (@{ $lwp->requests_redirectable }, 'POST');
	my $req = HTTP::Request -> new (
	'POST' => $url,
		[
			# 'Host' => 'api.hockeytv.com',
			# 'User-Agent' => 'Mozilla/5.0 (Windows NT 6.1; rv:47.0) Gecko/20100101 Firefox/47.0',
			# 'Accept' => 'application/json',
			# 'Accept-Language' => 'ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
			# 'Accept-Encoding' => 'gzip, deflate, br',
			# 'Content-Type' => 'application/json;charset=utf-8',
			
			'APP_KEY' => '098f6bcd4621d373cade4e832627b4f6',
			# 'APP-KEY' => '098f6bcd4621d373cade4e832627b4f6',
			
			# 'APP_ID' => '1316.1523311874',
			# 'PLATFORM' => 'nahl',
			# 'UI_VERSION' => '1519053260420',
			# 'current_subscription' => 'null',
			# 'Referer' => 'https://nahl.hockeytv.com/',
			# 'Origin' => 'https://nahl.hockeytv.com',
			
		]
	);
	$req -> content ($postdata);
	my $file = getcwd () .'/txt/login.html';
	# my $res = $lwp -> request ($req, $file); 
	my $res = $lwp -> request ($req); 
	print $res -> code ."\t".$url."\n";
	my $content = $res -> content;
	$content =~ s/\n+//g;
	my $decode_json = decode_json ($content);
	$insert -> {api_key} = $decode_json -> {api_key};
	print '$insert -> {api_key} = ' . $insert -> {api_key} ."\n";
	
	
	# if (-f $file) {
		
		# my $content = get_content_from_file ($file);
		# print $content ."\n";
		# $content =~ s/\n+//g;
		# my $decode_json = decode_json ($content);
		# $insert -> {api_key} = $decode_json -> {api_key};
		# print '$insert -> {api_key} = ' . $insert -> {api_key} ."\n";
	# }
	
	
	# my $decode_json = decode_json ($content);
	# $insert -> {access_token} = $decode_json -> {access_token};
	# print '$insert -> {access_token} = ' . $insert -> {access_token} ."\n";
	
	# my $sleep = Random ($sleep2, $sleep3); 
	# sleep $sleep;	
	
	return $insert;
}


sub get_profile {
	my $insert  = shift;
	
	# print '$insert -> {api_key} = ' . $insert -> {api_key} . "\n";
	
	# my $url = 'https://api.hockeytv.com/users/495419/profile';
	my $url = 'http://api.hockeytv.com/users/495419/profile';
	
	my $req = HTTP::Request -> new (
		'GET' => $url,
		[	
			# 'Host'=> 'api.hockeytv.com',
			# 'User-Agent'=> 'Mozilla/5.0 (Windows NT 6.1; rv:47.0) Gecko/20100101 Firefox/47.0',
			# 'Accept' => 'application/json, text/plain, */*',
			
			# 'Accept'=> '*/*',
			# 'Content-type' => 'application/x-www-form-urlencoded',
			# 'Accept-Language' => 'ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
			# 'Accept-Encoding' => 'gzip, deflate, br',
			
			'APP_KEY' => '098f6bcd4621d373cade4e832627b4f6',
			'API_KEY' => $insert -> {api_key},
			
			# 'APP-KEY' => '098f6bcd4621d373cade4e832627b4f6',
			# 'API-KEY' => $insert -> {api_key},
			
			

			# 'APP_ID' => '1316.1523311874',
			# 'PLATFORM' => 'nahl',
			# 'UI_VERSION' => '1519053260420',
			# # 'current_subscription' => '{"id":139969,"account_code":495419,"plan_code":"365dp","uuid":"40b72d538bce3eb169457043a7859d00","state":"active","unit_amount_in_cents":19999,"quantity":1,"currency":"EUR","activated_at":"2017-10-23T03:38:28-0500","canceled_at":"2017-10-23T03:39:04-0500","current_period_started_at":"2017-10-23T03:38:28-0500","current_period_ends_at":"2018-10-23T03:38:28-0500","trial_started_at":"2017-10-23T03:39:04-0500","trial_ends_at":"2017-10-23T03:39:04-0500","tax_in_cents":null,"tax_type":null,"tax_rate":null,"po_number":null,"net_terms":0,"last_import":1508747944}',
			
			# 'Referer'=> 'https://nahl.hockeytv.com/',
			# 'Origin'=> 'https://nahl.hockeytv.com',
			# # 'X-Requested-With'=> 'XMLHttpRequest',
		]
	);

	my $file = getcwd () .'/txt/get_profile.html';
	# my $response = $lwp -> request ($req, $file);	
	my $response = $lwp -> request ($req);	
	print $response -> code ."\t".$url."\n";
	
	# my $headers = $response->headers; # HTTP::Headers object
	# print $headers -> as_string (); # 1 вариант
	# print '***' ."\n";
	# while (my ($key, $value) =  each (%$headers)) { # 2 вариант
		# print $key."\t".$value."\n";                
	# }	
	
	
	my $content2 = $response -> content;
	print $content2 ."\n";
	$content2 =~ s/\n+//g;
	
	# my $sleep = Random ($sleep2, $sleep3); 
	# sleep $sleep;	
	
	return $insert;
}




sub get_ppp {
	my $file = getcwd (). '/ip.txt';
	my @file = ();
	open (FILE, $file) or die (print $!);
	while (<FILE>) {
		$_ =~ s/\n+//g;
		$_ =~ s/\t+//g;
		$_ =~ s/\r+//g;
		if ($_ =~ /:\d+/) {
			push (@file, $_);
		}
	}
	close (FILE);
	return shift (@file);
}