<?php
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, "http://api.hockeytv.com/sessions/api_key");
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, '{"email":"alexey.shishov@instatsport.com","password":"CSKA_champion1911!"}');
    curl_setopt($curl, CURLOPT_HTTPHEADER, ['APP_KEY: 098f6bcd4621d373cade4e832627b4f6']);
    $contents = curl_exec($curl);
    curl_close($curl);

    var_dump($contents);

    $contents = @json_decode($contents, true);
    $apiKey = $contents['api_key'];

    var_dump($apiKey);

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, 'https://api.hockeytv.com/users/495419/profile');
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, ['APP_KEY: 098f6bcd4621d373cade4e832627b4f6', "API_KEY: $apiKey"]);
    $contents = curl_exec($curl);
    curl_close($curl);

    var_dump($contents);