<?php
$url = 'https://api.hockeytv.com/games/482275?include%5B%5D=preroll&include%5B%5D=user_started&include%5B%5D=lineup';
print urldecode ($url) ."\n";
?>