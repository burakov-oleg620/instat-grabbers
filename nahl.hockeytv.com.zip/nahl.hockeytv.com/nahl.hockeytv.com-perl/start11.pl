#!/usr/bin/env perl
use strict; 
use warnings;
use Cwd;
use lib getcwd().'/graber';
use clear_str;
use LWP::UserAgent;
use HTTP::Request;
use HTTP::Response;
use HTTP::Cookies;
use URI::Escape;
use JSON::XS;
use Data::Dumper;
use URI::URL;
use Tie::IxHash;
use JSON::XS;
use Net::FTP;
use File::Copy;
use File::Path;
use Data::Dumper;
use IO::Socket::SSL; #��� ���� ����� ��������� �������� SSL �����������

# # ������ ��������� ��������
my $lwp = undef;
$lwp = LWP::UserAgent -> new (
#���������� �������� SSL ����������� (� ��� �� �������)
ssl_opts => { 
        verify_hostname => 0, 
        SSL_verify_mode => IO::Socket::SSL::SSL_VERIFY_NONE 
    },

);

$lwp -> cookie_jar (HTTP::Cookies->new ());
$lwp -> agent ('Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.2.16) Gecko/20110319 Firefox/3.6.16');
$lwp -> timeout (180);
# $lwp -> proxy ('http', 'http://127.0.0.1:8080');



my $workdir0 = getcwd (); 
my $workdir1 = getcwd (). '/graber'; 
my $workdir2 = getcwd (). '/city'; 
my $lockfile_graber = 'lock_graber.txt'; 

my $count = 0;

if (!-f $lockfile_graber) {
	
	open (FILE, '>'.$lockfile_graber) or die;
	print FILE 'запуск грабера произведен';
	close (FILE); 

	my @file1 = ();
	opendir (DIR, $workdir2) or die (print $!);
	while (my $file1 = readdir (DIR)) {
		print ++$count ."\n";
		
		if ($file1 =~ /xls$/) {
			$file1 = $workdir2 .'/'.$file1;
			
			open (FILE, $file1) or die (print $!);
			while (<FILE>) {
				my $array = [];
				@$array = split ("\t", $_);
				foreach (@$array) {
					$_ =~ s/\n+//g;
					$_ =~ s/\r+//g;
				}
				if (scalar (@$array) == 12 and $array -> [0] =~ /\d+/) {
					push (@file1, $array);
				}
			}
			close (FILE);
		}
	}
	closedir (DIR); 


	if (scalar (@file1) > 0) {
			
		while  (scalar (@file1) > 0) {
			my @array = ();
			for (1 .. 1) {
				if (defined ($file1 [0])) {
					push (@array, shift (@file1));
				}
			}
			if (scalar (@array) > 0) {
				
				chdir ($workdir1); 
				
				my $file_url = $workdir1  .'/xls/001.xls';
				open (FILE, '>'.$file_url) or die (print $!);
				
				
				my $match_id = undef;
				foreach (@array) {
					print FILE join ("\t", @$_)."\n";
					$match_id = $_ -> [0];
				}
				close (FILE);
				
				
				
				
				my $get_instat_id_result = get_instat_id  ($match_id);
				if (scalar (@{$get_instat_id_result}) > 0) {
					foreach (@{$get_instat_id_result}) {
						my $get_instat_id_result_local = $_;
				
						# #заремарить!!!!!!!!!
						# $get_instat_id_result_local -> {instat_id} = 1334;
						
						if (
							defined ($get_instat_id_result_local -> {instat_id}) and 
							$get_instat_id_result_local -> {instat_id} != 0 and 
							# $get_instat_id_result_local -> {match_status} != 4 and 
							# $get_instat_id_result_local -> {match_status} != 5 and 
							# $get_instat_id_result_local -> {match_status} != 8 and 
							# $get_instat_id_result_local -> {match_magnitude} != 4
						) {				
							my $file2 = 'start1.cmd'; 
							if (-f $workdir1 .'/'. $file2 and -d 'c:/windows') {
								system $file2;
							}
							
							$file2 = './start1.pl'; 
							if (-f $workdir1 .'/'. $file2 and !-d 'c:/windows') {
								system $file2;
							}
						}
					}
				}
				
				chdir ($workdir0);
			}
			
		}
	}
	
	unlink ($lockfile_graber) or die;
}






sub get_instat_id {
	my $match_id = shift;
	
	my $response_code = 0;
	my $json_decode = '[{}]';
	my $content_ok = 'nok';
	
	do {
	
		# https://data.instatfootball.tv/api/Getinstatid?key=22812357092873478234729374&method=UpdateBasketballSynergyMatches&id=414219,414525,414357
		my $url = 'https://data.instatfootball.tv/api/Getinstatid?key=22812357092873478234729374&method=UpdateHockeyNahlHockeyTvMatches&id='.$match_id;
		
		my $method = 'GET';
		my $useragent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0';
		my $request = HTTP::Request -> new (
			$method => $url,
			[
				'User-Agent' => 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0',
				'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
				'Accept-Language' => 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
				'Accept-Charset' => 'windows-1251,utf-8;q=0.7,*;q=0.7',
			]
		);

		my $file = getcwd () .'/txt/get_1.html';
		# my $response = $lwp -> request ($request, $file);
		my $response = $lwp -> request ($request);
		print $response -> code  ."\t". $url ."\n";
		# print $response -> content ."\n";
		
		my $content = $response -> content;
		$content =~ s/\n+//g;
		$content =~ s/\r+//g;
		$content =~ s/\t+//g;
		
		if ($content =~ /^\[\{"id":"\d+",/) {
			$content_ok = 'ok';
			$json_decode = decode_json ($response -> content);	
		}
		
		#��������
		sleep 1;
		
	} while ($response_code != 200 and $content_ok ne 'ok');
	
	return $json_decode;
}

sub get_one {
	my $days = shift;
	my $response_code = 0;
	my $return = '';
	do {
		
		#my $url = 'https://data.instatfootball.tv/api/SyMatchesLast?key=22812357092873478234729374&days='.$days;
		#my $url = 'https://data.instatfootball.tv/api/GetExtIdListLast?key=22812357092873478234729374&method=UpdateBasketballSynergyMatches&days='.$days.'&no_video';
		# my $url = 'https://data.instatfootball.tv/api/GetExtIdListLast?key=22812357092873478234729374&method=UpdateBasketballSynergyMatches&days='.$days.'&no_video&matches_date_diff=30';
		# my $url = 'https://data.instatfootball.tv/api/GetExtIdListLast?key=22812357092873478234729374&method=UpdateHockeyNahlHockeyTvMatches&day='.$days.'&offset=0&limit=10&no_video&matches_date_diff=30';
		# my $url = 'https://data.instatfootball.tv/api/GetExtIdListLast?key=22812357092873478234729374&method=UpdateHockeyNahlHockeyTvMatches&days=2&offset=0&limit=10&no_video&matches_date_diff=3';
		# my $url = 'https://data.instatfootball.tv/api/GetExtIdListLast?key=22812357092873478234729374&method=UpdateHockeyNahlHockeyTvMatches&days=30&offset=0&limit=1&no_video';
		# my $url = 'https://data.instatfootball.tv/api/GetExtIdListLast?key=22812357092873478234729374&method=UpdateHockeyNahlHockeyTvMatches&days=30&offset=0&limit=100&no_video&has_instat_id';
		my $url = 'https://data.instatfootball.tv/api/GetExtIdListLast?key=22812357092873478234729374&method=UpdateHockeyNahlHockeyTvMatches&days=30&offset=0&limit=30&no_video&has_instat_id&has_video_links';
		
		my $method = 'GET';
		my $useragent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0';
		my $request = HTTP::Request -> new (
			$method => $url,
			[
				'User-Agent' => 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0',
				'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
				'Accept-Language' => 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
				'Accept-Charset' => 'windows-1251,utf-8;q=0.7,*;q=0.7',

			]
		);

		my $file = getcwd () .'/txt/get_1.html';
		# my $response = $lwp -> request ($request, $file);
		my $response = $lwp -> request ($request);
		print $response -> code  ."\t". $url ."\n";
		print $response -> content ."\n";
		$return =  $response -> content;
	
		# my $json_decode = decode_json ($response -> content);	
		$response_code = $response -> code;
		
		#��������
		#sleep 1;
	
	} while ($response_code != 200);

	return $return;
	
}
