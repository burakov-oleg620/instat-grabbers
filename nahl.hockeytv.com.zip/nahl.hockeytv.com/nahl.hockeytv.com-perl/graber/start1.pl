#!/usr/bin/env perl
use strict;
use warnings;
use Cwd qw (getcwd realpath);
use Date::Calc qw (Time_to_Date);

my $system = undef;

$system = './clear_table.pl'; 
system ($system);	

$system = './clear_dir.pl'; 
system ($system);	

#$system = './work1.pl'; 
#system ($system);

#$system = './graber2.pl'; 
#system ($system);

$system = 'php ./test1.php'; 
system ($system);

$system = './work3_video1.pl'; 
system ($system);
