#!/usr/bin/env perl
use strict;
use warnings;
use File::Path;
use Encode qw (decode encode);
use locale;
use List::Util qw (shuffle);
use Cwd;
use dir_scan_recurce;
use dir_scan_no_recurce;

use threads;
use threads::shared;
use Thread::Queue;

use read_inifile;
use read_select1;
use read_select2;
use clear_str;
use create_type_workdir;
use url_to_file;
use read_xml;

use work_mysql_graber;
use work_mysql_proxy;
use work_for_content;

use write_text_file_mode_add;
use write_text_file_mode_rewrite; 
use read_text_file;

use LWP::UserAgent;
use HTTP::Request;
use HTTP::Response;
use HTTP::Cookies;
use URI::Escape;
use JSON::XS;
use Data::Dumper;
use URI::URL;
use Tie::IxHash;
use JSON::XS;
use Net::FTP;
use File::Copy;
use File::Path;
use work_mysql_agregator;
use work_mysql_agregator2;

# use String::CRC32;


#system 'clear_table.pl'; 
#system 'clear_dir.pl';



#Читаю установки из ини файла
my $read_inifile = read_inifile -> new ('graber.ini'); 
my $mysql_dbdriver = $read_inifile -> get ('mysql_dbdriver');
my $mysql_host = $read_inifile -> get ('mysql_host');
my $mysql_port = $read_inifile -> get ('mysql_port');
my $mysql_user = $read_inifile -> get ('mysql_user');
my $mysql_user_password = $read_inifile -> get ('mysql_user_password');
if ($mysql_user_password eq ' ') {$mysql_user_password = '';}
my $mysql_base = $read_inifile -> get ('mysql_base');
my $mysql_table = $read_inifile -> get ('mysql_table');

my $threads_all = $read_inifile -> get ('threads_all'); 
my $sleep1 = $read_inifile -> get ('sleep1'); 
my $sleep2 = $read_inifile -> get ('sleep2'); 
my $sleep3 = $read_inifile -> get ('sleep3'); 

my $host = $read_inifile -> get ('host');	
my $set_proxy = $read_inifile -> get ('set_proxy');
my $count_all = $read_inifile -> get ('count_all');	

# читаем шаблоны (ссылок и прочее)
my $read_select2 = read_select2 -> new ('select2.txt'); 
my @read_select2 = $read_select2 -> get ();
$read_select2 = undef;

my $read_select3 = read_select2 -> new ('select3.txt'); 
my @read_select3 = $read_select3 -> get ();
$read_select3 = undef;

my $read_select4 = read_select2 -> new ('select4.txt'); 
my @read_select4 = $read_select4 -> get ();
$read_select4 = undef;	

my @proxy = (); #массив с прокси
my @useragent = (); 

use IO::Socket::SSL; #для того чтобы отключить проверку SSL сертификата

# # создаю экземпляр броузера
my $lwp = undef;
$lwp = LWP::UserAgent -> new (
#отключение проверки SSL сертификата (у нас он устарел)
ssl_opts => { 
        verify_hostname => 0, 
        SSL_verify_mode => IO::Socket::SSL::SSL_VERIFY_NONE 
    },

);

# my $lwp = undef;
# $lwp = LWP::UserAgent -> new ();
$lwp -> cookie_jar (HTTP::Cookies->new ());
$lwp -> agent ('Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.2.16) Gecko/20110319 Firefox/3.6.16');
$lwp -> timeout (60);
# $lwp -> proxy ('http', 'http://127.0.0.1:8080');

#очередь работы, куда добавляются задания
# my $queue_job = Thread::Queue->new ();
# my $queue_job_proxy = Thread::Queue->new ();

#гобальные переменные
# my @start_second = (); my $start_second = 0; #переменные для отслеживания запуска start_second ();
# my @pattern_from_select = (); my $pattern_from_select = undef; #проверка контента на наличие указанного шаблона текста

# my %tid_hash :shared; 
# %tid_hash = (); #глобальный хеш - работают потоки или нет.


# # устанавливаем соединение с базой данных
# # соединение для тела программы
# our $work_mysql_graber = work_mysql_graber -> new (
	# $mysql_dbdriver,
	# $mysql_host,
	# $mysql_port,
	# $mysql_user,
	# $mysql_user_password,
	# $mysql_base,
	# $mysql_table
# ); 

# #Создаем дескриптор на mysql соединение
# my $work_mysql_agregator = work_mysql_agregator -> new (
	# $mysql_dbdriver,
	# $mysql_host,
	# $mysql_port,
	# $mysql_user,
	# $mysql_user_password,
	# $mysql_base,
	# $read_inifile -> {agregator}
# ); 

# if ($read_inifile -> {clear_agregator} == 1) {
	# $work_mysql_agregator -> drop ();
# }
# $work_mysql_agregator -> create ();		
# # $work_mysql_agregator2 -> clear ($read_inifile -> {clear_agregator_time});

#Создаем дескриптор на mysql соединение
my $work_mysql_agregator2 = work_mysql_agregator2 -> new (
	$mysql_dbdriver,
	$mysql_host,
	$mysql_port,
	$mysql_user,
	$mysql_user_password,
	$mysql_base,
	$read_inifile -> {agregator2}
); 

if ($read_inifile -> {clear_agregator} == 1) {
	$work_mysql_agregator2 -> drop ();
}
$work_mysql_agregator2 -> create ();		
$work_mysql_agregator2 -> clear ($read_inifile -> {clear_agregator_time});	


my $workdir0 = getcwd ();
my $workdir1 = getcwd () .'/out';
my $workdir3 = getcwd () .'/out_concat';
my $count = 0;



do {
	
	$count = 0;
	opendir (DIR, $workdir1) or die;
	while (my $file1 = readdir (DIR)) {
		if ($file1 ne '.' and $file1 ne '..') {
			$file1 = $workdir1. '/'.$file1;
			if (-d $file1) {
			
				my $gameid = $file1;
				$gameid =~ s/^.+\///;
				
				my $workdir2 = $file1;
				chdir ($workdir2);
				
				my %files = ();
				tie %files, 'Tie::IxHash';
				
				my $dir_scan_recurce = dir_scan_no_recurce -> new ($workdir2);
				while (my $file1 = $dir_scan_recurce -> get_file ()) {
					
					if ($file1 =~ /wmv|mp4/) {
						#print $file1 ."\n";
						
						$file1 =~ s/^.+\///;
						
						my @file = split ('_', $file1);
						if (exists ($files {$file[2]})) {
							push (@{$files {$file[2]}}, $file1);
						} else {
							$files {$file[2]} = [];
							push (@{$files {$file[2]}}, $file1);
						}
					}
				}
				$dir_scan_recurce= undef;	
				
				my $match_id = undef;
				my $match_id_instat = undef;
				my $period = undef;
				my $match_upload_ok = 'ok';
				
				my $count_concat = 0;
				if (scalar (keys (%files)) > 0) {
					foreach (sort (keys (%files))) {
						
						my $file_concat =  'concat.txt';
						open (FILE, '>'.$file_concat) or die (print $!);
						
						my $ext = undef;
						my $file2 = undef;
						my @file2 = ();
						my $file2_source = undef;
						
						foreach (sort (@{$files {$_}})) {
							# print $_ ."\n";
							# print FILE $_ ."\n";
							
							print FILE 'file '. '\''.$_.'\''."\n";
							
							my @ext = split ('\.', $_);
							$ext = pop (@ext);
							
							@file2 = split ('_', $ext[0]);
							$file2 = $file2[1].'_'. $file2[2] .'.'.$ext;
							
							$match_id = $file2[1];
							$period = $file2[2];
							
							if (!-d ($workdir3.'/'.$file2[1])) {
								
								mkpath ($workdir3.'/'.$file2[1]) or die ();
							}
						}
						close (FILE);
						
						$count_concat++;
						# copy ('concat.txt', $match_id .'_' .$count_concat.'.txt');
						# print $file2 ."\n";
						# print $workdir2 ."\n";
						# print $workdir3.'/'.$file2[1] ."\n";
						
						
						
						my $get_instat_id_result = get_instat_id  ($match_id);
						if (scalar (@{$get_instat_id_result}) > 0) {
							foreach (@{$get_instat_id_result}) {
								my $get_instat_id_result_local = $_;
						
								# #заремарить!!!!!!!!!
								# $get_instat_id_result_local -> {instat_id} = 1334;
								# print Dumper ($get_instat_id_result_local) ."\n";
								
								
								if (
										defined ($get_instat_id_result_local -> {instat_id}) and 
										$get_instat_id_result_local -> {instat_id} != 0 
										#$get_instat_id_result_local -> {match_status} != 4 and 
										#$get_instat_id_result_local -> {match_status} != 5 and 
										#$get_instat_id_result_local -> {match_status} != 8 and 
										#$get_instat_id_result_local -> {match_magnitude} != 4
								) {
								
									$match_id_instat = $get_instat_id_result_local -> {instat_id};
									
									# если футбол,то ничего не прибавляем
									# $match_id_instat = $match_id_instat + 10000000;
									$match_id_instat = $match_id_instat + 10000000;
									
									$period = 0; # особенность этого грабера
									
									#новое имя инстат_id
									my $file2_name = $match_id_instat .'_'.$period.'.'.$ext;
									
									my $insert3 = {};
									$insert3 -> {name} = $match_id_instat .'_'.$period .'.*';
									
									my @post_file_exists_result = post_file_exists ($insert3);
									print '$file2_name = '. $file2_name ."\n";
									print 'scalar (@post_file_exists_result) = ' . scalar (@post_file_exists_result) ."\n";
									
									
									# if (scalar (@post_file_exists_result) > 0) {
									# if (scalar (@post_file_exists_result) == 0 or scalar (@post_file_exists_result) > 0) {
									if (scalar (@post_file_exists_result) == 0) {
									
										$match_upload_ok = 'nok';
										
										# отключили счетчик, ибо в разрезе условия он не действует и зацикливает скрипт.
										# print $count++ ."\n";
										
										$period = 0; #особенновать этого грабера
										my $file1 = $workdir2 .'/0_'.$match_id .'_'.$period.'.'.$ext;
										
										#старое имя не инстат
										$file2 = $workdir3.'/'.$file2[1] .'/'.$file2_name;
										
										if (-f $file1 and !-f $file2) {
											rename ($file1, $file2) or die;	
										}
										
										
										# # my $system = 'ffmpeg -f concat -i concat.txt -vcodec copy -acodec copy output.mp4';
										# if (!-f $file2) {
											# my $system = 'ffmpeg -f concat -i concat.txt -vcodec copy -acodec copy '.$file2;
											# if (!-d 'c:/windows') {
												# system ($system);
											# }
										# }
										
										#################_______RENME_________###############
										
										if (-f $file_concat) {
											unlink ($file_concat) or die (print $!);
										}
										
										if (-f $file2) {
										
											# match_id
											# period
											# folder: source
											# quality: source
											
											
											######### my $crc32 = get_crc32 ($file2);
											
											my $crc32 = get_system_crc32 ($file2);
											# my $crc32 = 11111;
											
											my $file3_name = $match_id_instat .'_'.$period.'.SRC.'. $crc32 .'.'.$ext;
											my $file3 = $workdir3.'/'.$file2[1] .'/'.$file3_name;
											
											
											if (-f $file2) {
												
												rename ($file2, $file3) or die (print $!);
												
												if (-f $file3) {
													open (FILE, '>'. $file3. '.done') or die;
													print FILE 1 ."\n";
													close (FILE);
												}
											}
											
											my $insert2 = [];
											my $insert1 = {};
											
											# $insert1 -> {match_id} = $match_id;
											$insert1 -> {match_id} = $match_id_instat;
											$insert1 -> {period} = $period;
											$insert1 -> {folder} = 'source';
											$insert1 -> {quality} = 'source';
											
											# foreach (keys (%{$insert1})) {
												# print $_ ."\t", $insert1 -> {$_} ."\n";
											# }
											# push (@$insert2, $insert1);
											# my $encode_json = encode_json ($insert1);
											
											my $post_add_result = post_add ($insert1);
											
											
											# my $insert3 = {};
											# $insert3 -> {name} = $match_id_instat .'_'.$period .'*';
											# my @post_file_exists_result = post_file_exists ($insert3);
											
											#поменять на !~ (если не присутсвует)
											# if ($post_add_result !~ /"status":"Error","message":"File already exist or loaded"/ and scalar (@post_file_exists_result) == 0) {
											# if ($post_add_result !~ /"status":"Error","message":"File already exist or loaded"/) {
											if ($post_add_result) {
											
												my $post_ftp_ak_result = post_ftp_ak ();
												
												my $post_ftp_ak_result_json = decode_json ($post_ftp_ak_result);
												if (defined ($post_ftp_ak_result_json -> {data} -> {sources} -> {host})) {
												
													my $ftp_host = $post_ftp_ak_result_json -> {data} -> {sources} -> {host} .':'. $post_ftp_ak_result_json -> {data} -> {upload} -> {port};
													my $ftp_user = $post_ftp_ak_result_json -> {data} -> {sources} -> {login};
													my $ftp_password = $post_ftp_ak_result_json -> {data} -> {sources} -> {password};
												
												
													my $ftp = Net::FTP -> new($ftp_host, Debug => 0) or die "Cannot connect to $ftp_host: $@";
													
													print '=== work FTP ===' ."\n";
													$ftp-> login ($ftp_user, $ftp_password) or die "Cannot login ", $ftp->message;
													
													# $ftp -> cwd ('import') or die; 
													
													$ftp-> binary; #режим для передачи еxe файлов, zip архивов
													
													my $ftp_file1 = $file3;
													my $ftp_file2 = $file3;
													$ftp_file2 =~ s/^.+\///;
													
													if (!-d 'c:/windows') {
														$ftp-> put ($ftp_file1, $ftp_file2) or die "put failed ", $ftp->message;
														$ftp-> put ($ftp_file1 .'.done', $ftp_file2 .'.done') or die "put failed ", $ftp->message;
													}
													
													$ftp-> quit;
													$ftp = undef;
													
													my $insert_upload_status = {};
													$insert_upload_status -> {name} = $match_id_instat .'_'.$period .'*';
													$insert_upload_status -> {folder} = 'source';
													
													#проверим статус задачи
													# my $post_upload_status_result = post_upload_status ($insert_upload_status);
													
													# sleep 2;	
													
													# my $post_upload_status_result = undef;
													# do {
														# $post_upload_status_result = post_upload_status ($insert_upload_status);
														# sleep 2;
													
													# } while ($post_upload_status_result =~ /"status":"progress"/);
												}
												
											}
											
										} else {
										
											die (print $! ."\n");
										}
									}
									
									
									#ЛОГ ВРЕМЕННО!!!! заремарить!!!!
									#пробуем писать временный лог.
									# my $log_file = $workdir0 .'/_log_.xls';
									# open (LOG, '>>'. $log_file) or die ();
									# print LOG $match_id ."\t". $match_id_instat . "\t". get_date ()."\n";
									# close (LOG);
									
									
									
								} #если статус удовлетворяет
								
								
								
							}
						}
					}
					
					
					#удаление файлов склейки out_concat
					if (-d $workdir3 .'/'.$match_id and $match_id =~ /\d+/) {
						# rmtree ($workdir3 .'/'.$match_id) or die (print $!);
					}
					
					chdir ($workdir1);
					
					#удаление файлов матча out
					if ($match_upload_ok eq 'ok') {
						print '$match_upload_ok = ' . $match_upload_ok ."\n";
						print '$match_id = ' . $match_id ."\n";
						if (defined ($match_id) and $match_id =~ /\d+/ and -d $workdir1.'/'.$match_id) {
							# rmtree ($workdir1.'/'.$match_id) or die (print $!);
						}
					}			
					
					##############работа с агрегатором
				
					my $insert = {};
					
					my $md5 = MD5 -> new ();
					my $hash = $md5 -> hexhash ($gameid);
					$md5 = undef;
					
					$insert -> {hash} = $hash;
					$insert -> {url} = $gameid; 
					$insert -> {match_id} = $gameid; 
					$insert -> {time} = time();
					
					#проверяем не качали ли мы это видео ранее.
					my $work_mysql_agregator_result = $work_mysql_agregator2 -> select ($insert); 
					if (scalar (@$work_mysql_agregator_result) > 0) {
					
					} else {
						
						#добавляем матч в агрегатор, чтобы больше не грузить
						$work_mysql_agregator2 -> insert ($insert);
						
						{
							my $insert2 = [];
							my $insert = {};
							tie (%$insert, 'Tie::IxHash');
							
							$insert -> {id} = $gameid;
							$insert -> {video_download_date} = get_date ();
							
							
							push (@{$insert2}, $insert);
							my $encode_json = encode_json ($insert2);
							
							print $encode_json ."\n";
							#post_matches ($encode_json);
						}
					}					
				}
				
			}
		}
	}
	closedir (DIR);
	
	
	print '==sleep 1==' ."\n";
	sleep 1;
	
} while ($count > 0);



sub Random {
	my $from = shift;
	my $to = shift;
	my $random = $from + rand(($to - $from));
	return $random;
}

sub post_add {
	
	my $insert1 = shift;
	my $postdata = encode_json ($insert1);
	
    my $url = 'http://videoapi.instatscout.com/files/uploading/add';	

	push (@{ $lwp->requests_redirectable }, 'POST');
	my $req = HTTP::Request -> new (
	'POST' => $url,
		[
			'Content-Type' => 'application/json',
			'User-Agent' => 'Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.2.16) Gecko/20110319 Firefox/3.6.16',
			'Accept' => '*/*',
			'X-Username' => 'infobasket_parser',
			'X-Password' => 'kZ0aJ8pD3mM3hW2yN4cJ2m',
			
		]
	);
	

	$req -> content ($postdata);
	my $file = getcwd () .'/txt/video_api_add.html';
	
	# print $file ."\n";
	# my $res = $lwp -> request ($req, $file); 
	
	my $res = $lwp -> request ($req); 
	
	print $res -> code ."\t" . $url ."\n";
	print $res -> content ."\n";
	
	my $sleep = Random ($sleep2, $sleep3); 
	sleep $sleep;		
	
	return $res -> content;
}

sub post_ftp_ak {
	
	# my $insert1 = shift;
	# my $postdata = encode_json ($insert1);
	# 3-й, блин, 4-й, блин и 12-й не работают
    my $content = undef;
	do {
		my $url = 'http://videoapi.instatscout.com/rip/video-upload';	

		push (@{ $lwp->requests_redirectable }, 'POST');
		my $req = HTTP::Request -> new (
		'POST' => $url,
			[
				'Content-Type' => 'application/json',
				'User-Agent' => 'Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.2.16) Gecko/20110319 Firefox/3.6.16',
				'Accept' => '*/*',
				'X-Username' => 'infobasket_parser',
				'X-Password' => 'kZ0aJ8pD3mM3hW2yN4cJ2m',
				
			]
		);
		

		# $req -> content ($postdata);
		$req -> content ('{}');
		my $file = getcwd () .'/txt/video-upload.html';
		
		# my $res = $lwp -> request ($req, $file); 
		my $res = $lwp -> request ($req); 
		
		print $res -> code ."\t" . $url ."\n";
		print $res -> content ."\n";
		
		$content = $res -> content;
		$content =~ s/\n+//g;
		$content =~ s/\t+//g;
		$content =~ s/\r+//g;

		my $sleep = Random ($sleep2, $sleep3); 
		sleep $sleep;		
		
	} while ($content =~ /"de3.instatfootball.tv"/ or $content =~ /"de4.instatfootball.tv"/ or $content =~ /"de12.instatfootball.tv"/);
	
	
	return $content;
}

sub post_upload_status {
	
	my $insert1 = shift;
	my $postdata = encode_json ($insert1);
	
    my $url = 'http://videoapi.instatscout.com/files/uploading/status';	

	push (@{ $lwp->requests_redirectable }, 'POST');
	my $req = HTTP::Request -> new (
	'POST' => $url,
		[
			'Content-Type' => 'application/json',
			'User-Agent' => 'Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.2.16) Gecko/20110319 Firefox/3.6.16',
			'Accept' => '*/*',
			'X-Username' => 'infobasket_parser',
			'X-Password' => 'kZ0aJ8pD3mM3hW2yN4cJ2m',
			
		]
	);
	

	# $req -> content ($postdata);
	
	$req -> content ($postdata);
	my $file = getcwd () .'/txt/video-upload-status.html';
	
	# my $res = $lwp -> request ($req, $file); 
	my $res = $lwp -> request ($req); 
	
	print $res -> code ."\t" . $url ."\n";
	print $res -> content ."\n";
	
	my $content = $res -> content;
	$content =~ s/\n+//g;
	$content =~ s/\t+//g;
	$content =~ s/\r+//g;

	# my $sleep = Random ($sleep2, $sleep3); 
	# sleep $sleep;		
	
	return $content;
}

sub post_file_exists {
	
	my $insert1 = shift;
	
	
	# {"name":"20006586_3.mp4"}
	my $postdata = encode_json ($insert1);
	
        my $url = 'http://videoapi.instatscout.com/folders/for-file-mask';	

	push (@{ $lwp->requests_redirectable }, 'POST');
	my $req = HTTP::Request -> new (
	'POST' => $url,
		[
			'Content-Type' => 'application/json',
			'User-Agent' => 'Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.2.16) Gecko/20110319 Firefox/3.6.16',
			'Accept' => '*/*',
			'X-Username' => 'infobasket_parser',
			'X-Password' => 'kZ0aJ8pD3mM3hW2yN4cJ2m',
			
		]
	);
	
	# $req -> content ($postdata);
	
	print $postdata ."\n";
	$req -> content ($postdata);
	my $file = getcwd () .'/txt/post_file_exists.html';
	
	# my $res = $lwp -> request ($req, $file); 
	my $res = $lwp -> request ($req); 
	
	print $res -> code ."\t" . $url ."\n";
	print $res -> content ."\n";
	
	my $content = $res -> content;
	$content =~ s/\n+//g;
	$content =~ s/\t+//g;
	$content =~ s/\r+//g;
	
	my $deocde_json = decode_json ($content);
	my @result = ();
	foreach (@{$deocde_json -> {data}}) {
		push (@result, $_);
	}

	# my $sleep = Random ($sleep2, $sleep3); 
	# sleep $sleep;		
	# print 'scalar (@result) = ' scalar (@result)."\n";
	
	return @result;
}


sub get_instat_id {
	my $match_id = shift;
	
	my $response_code = 0;
	my $json_decode = '[{}]';
	my $content_ok = 'nok';
	
	do {
		# https://data.instatfootball.tv/api/Getinstatid?key=22812357092873478234729374&method=UpdateBasketballSynergyMatches&id=414219,414525,414357
		my $url = 'https://data.instatfootball.tv/api/Getinstatid?key=22812357092873478234729374&method=UpdateHockeyNahlHockeyTvMatches&id='.$match_id;
		my $method = 'GET';
		my $useragent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0';
		my $request = HTTP::Request -> new (
			$method => $url,
			[
				'User-Agent' => 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0',
				'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
				'Accept-Language' => 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
				'Accept-Charset' => 'windows-1251,utf-8;q=0.7,*;q=0.7',
			]
		);

		my $file = getcwd () .'/txt/get_1.html';
		# my $response = $lwp -> request ($request, $file);
		my $response = $lwp -> request ($request);
		print $response -> code  ."\t". $url ."\n";
		print $response -> content ."\n";
		
		my $content = $response -> content;
		$content =~ s/\n+//g;
		$content =~ s/\r+//g;
		$content =~ s/\t+//g;
		
		if ($content =~ /^\[\{"id":"\d+",/) {
			$content_ok = 'ok';
			$json_decode = decode_json ($response -> content);	
		}
		
		#задержкв
		#sleep 1;
		
	} while ($response_code != 200 and $content_ok ne 'ok');
	
	return $json_decode;
}


# sub get_crc32 {
	# my $file1 = shift;
	
	# open (FILE, $file1) or die;
	# my $crc32 = crc32 (*FILE);
	# close(FILE);
	
	# print $crc32 ."\n";

	# return $crc32;
# }

sub get_system_crc32 {
	my $file = shift;
	
	my @file1 = split ('/', $file);
	pop (@file1);
	my $crc_file = join ('/', @file1) .'/crc32.txt';
	# print '$crc_file = ' . $crc_file ."\n";
	
	my $system = '/usr/bin/cksum -o 3 '.$file .' | awk \'{print $1}\' > '. $crc_file;
	system ($system);
	
	my @file = ();
	open (my $fh, $crc_file) or die (print $!);
	while (<$fh>) {
		$_ =~ s/\n+//g;
		$_ =~ s/\r+//g;
		$_ =~ s/\t+//g;
		push (@file, $_);
	}
	close ($fh);
	
	if (scalar (@file) > 0) {
		return $file[0];
	} else {
		return 1;
	}
}


sub post_matches {
	my $postdata = shift;
	
	
	my $key_import2 = '22812357092873478234729374';
    my $url = 'http://data.instatfootball.tv/api/import2?key='.$key_import2.'&method=UpdateHockeyNahlHockeyTvMatches';	
	# my $postdata = 'firstsec=1&email=is.fin.dept%40gmail.com&pwd=basket55&women=0&B1=Login';

	push (@{ $lwp->requests_redirectable }, 'POST');
	my $req = HTTP::Request -> new (
	'POST' => $url,
		[
			# 'User-Agent' => 'Mozilla/5.0 (Windows NT 5.1; rv:11.0) Gecko/20100101 Firefox/11.0',
			# 'Accept-Language' => 'ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
			# 'Referer' => 'http://basketball.eurobasket.com/player/Andrey-Vorontsevich/Russia/CSKA-Moscow/71366',
			# 'Content-Type' => 'application/json',
			
			'Accept' => '*/*',
			'Content-Type' => 'multipart/form-data; boundary=----------------------------4b5789fa8d3f',
			
		]
	);
	
	
	my $str = 
'------------------------------4b5789fa8d3f
Content-Disposition: form-data; name="json"

'.$postdata.'
------------------------------4b5789fa8d3f--';
	

	$req -> content ($str);
	
	my $file = getcwd () .'/txt/matches.html';
	my $res = $lwp -> request ($req, $file); 
	print $res -> code ."\t" . $url ."\n";
	
	# my $sleep = Random ($sleep2, $sleep3); 
	# sleep $sleep;		
	
	return 1;
}


sub get_date {
	use Date::Calc qw (Time_to_Date Date_to_Time);
	# my ($year,$month,$day, $hour,$min,$sec) = Time_to_Date (time ());
	my @date = Time_to_Date (time ());
	
	if (scalar (@date) > 0) {
		foreach (@date) {
			while (length ($_) < 2) {
				$_ = '0'.$_;
			}
		}
	}
	my $str = $date[0] .'-'.$date[1] .'-'.$date[2] .' '.$date [3] .':'.$date[4].':'.$date[5];
	return $str;
}	
