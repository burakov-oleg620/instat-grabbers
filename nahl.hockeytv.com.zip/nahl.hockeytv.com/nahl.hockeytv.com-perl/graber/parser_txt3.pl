#!/usr/bin/env perl
use strict;
use warnings;
use dir_scan_recurce;
use read_text_file; 
use write_text_file_mode_rewrite; 
use clear_str;
use delete_duplicate_from_array; 
use read_inifile;
use url_to_file;
use Encode qw (encode decode);
use date_time;
use MD5;
use File::Copy;
use File::Path;
use work_mysql;
use Date::Calc qw (Time_to_Date Date_to_Time);
use work_mysql_agregator;
use work_mysql_agregator2;
use MD5;
use Cwd qw (realpath);
use work_for_content;
use write_to_txt1;
use write_to_txt2;
use JSON::XS;
use Data::Dumper;
use locale;
use LWP::UserAgent;
use HTTP::Request;
use HTTP::Response;
use HTTP::Cookies;
use URI::Escape;
use HTML::TreeBuilder::XPath;
use URI::URL;
use JSON::XS;
use HTTP::Request::Common qw{ POST };
use Tie::IxHash;


sub get_base_path {
	use Cwd; 
	my $cwd = getcwd ();
	return $cwd;
}

my $read_inifile = read_inifile -> new ('graber.ini'); 
my $host = $read_inifile -> get ('host');	
#����� ��������� �� ��� �����
my $mysql_dbdriver = $read_inifile -> get ('mysql_dbdriver');
my $mysql_host = $read_inifile -> get ('mysql_host');
my $mysql_port = $read_inifile -> get ('mysql_port');
my $mysql_user = $read_inifile -> get ('mysql_user');
my $mysql_user_password = $read_inifile -> get ('mysql_user_password');
if ($mysql_user_password eq ' ') {$mysql_user_password = '';}
my $mysql_base = $read_inifile -> get ('mysql_base');
my $mysql_table = $read_inifile -> get ('mysql_table');
my $content_table = $read_inifile -> get ('content_table');

my $lwp = undef;
$lwp = LWP::UserAgent -> new ();
$lwp -> cookie_jar (HTTP::Cookies->new ());
$lwp -> agent ('Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.2.16) Gecko/20110319 Firefox/3.6.16');
$lwp -> timeout (60);
# $lwp -> proxy ('http', 'http://127.0.0.1:8080');


my $workdir1 = get_base_path.'/txt'; 
my $workdir2 = get_base_path.'/picture'; 

my $file1 = $workdir1.'/write_text_file_mode_rewrite1.xls'; 
my $file2 = $workdir1.'/write_text_file_mode_rewrite3.xls'; 
my $file3 = $workdir1.'/write_text_file_mode_rewrite33.xls'; 
my $file4 = $workdir1.'/write_text_file_mode_rewrite333.xls'; 

# my ($year,$month,$day, $hour,$min,$sec) = Time_to_Date (time () + 4*3600);
# my $file2 = $workdir1.'/write_text_file_mode_rewrite2.xls'; 
# my $file2 = $workdir1.'/'.$year.'-'.$month.'-'.$day.'-'. $hour.'-'.$min.'-'.$sec.'-'.$host.'.xls'; 


# my 	$work_mysql = work_mysql -> new (
		# $mysql_dbdriver,
		# $mysql_host,
		# $mysql_port,
		# $mysql_user,
		# $mysql_user_password,
		# $mysql_base
	# ); 	

# my $sql = 'SET NAMES CP1251';
# $work_mysql -> run_query ($sql); 


# #������� ���������� �� mysql ����������
# my $work_mysql_agregator = work_mysql_agregator -> new (
	# $mysql_dbdriver,
	# $mysql_host,
	# $mysql_port,
	# $mysql_user,
	# $mysql_user_password,
	# $mysql_base,
	# $read_inifile -> {agregator}
# ); 

# if ($read_inifile -> {clear_agregator} == 1) {
	# $work_mysql_agregator -> drop ();
# }
# $work_mysql_agregator -> create ();		
# # $work_mysql_agregator2 -> clear ($read_inifile -> {clear_agregator_time});

# #������� ���������� �� mysql ����������
# my $work_mysql_agregator2 = work_mysql_agregator2 -> new (
	# $mysql_dbdriver,
	# $mysql_host,
	# $mysql_port,
	# $mysql_user,
	# $mysql_user_password,
	# $mysql_base,
	# $read_inifile -> {agregator2}
# ); 

# if ($read_inifile -> {clear_agregator} == 1) {
	# $work_mysql_agregator2 -> drop ();
# }
# $work_mysql_agregator2 -> create ();		
# # $work_mysql_agregator2 -> clear ($read_inifile -> {clear_agregator_time});	


my $count = 0;
my @read_text_file1 = ();

my %file1 = ();
tie (%file1, 'Tie::IxHash');

my %file2 = ();
tie (%file2, 'Tie::IxHash');

my @file3 = ();

# {
	# my $workdir1 = getcwd () .'/xls';
	# my $dir_scan_recurce = dir_scan_recurce -> new ($workdir1);
	# while (my $file1 = $dir_scan_recurce -> get_file ()) {
		# print ++$count."\n";
		
		# my $pattern = 'xls$';
		# if ($file1 =~ /$pattern/) {	

			# my $read_text_file1 = read_text_file -> new ($file1); 
			# while (my $str1 = $read_text_file1 -> get_str ()) {
				# print ++$count."\n";
				
				# if ($str1 =~ /\t/) {
					# my $temp1 = []; my $pattern1 = "\t"; @$temp1 = split ($pattern1, $str1); 
					
					# # print '*' . scalar (@$temp1) ."\n";
					# if (scalar (@$temp1) > 1) {
						# foreach (@$temp1) {
							# my $clear_str = clear_str -> new ($_);
							# $_ = $clear_str -> delete_4 ();
							# $clear_str = undef;											
						# }
						
						# my @temp = split (/\s+/, $temp1 -> [1]);
						# foreach (@temp) {
							# my $clear_str = clear_str -> new ($_);
							# $_ = $clear_str -> delete_4 ();
							# $clear_str = undef;											
						# }
						# $temp1 -> [1] = join (' ', @temp);
						
						# $file1 {$temp1 -> [1]} = $temp1;
					# }
				# }
			# }
			
			# $read_text_file1 = undef;
		# }
	# }
# }
my $ex_count = 0;
my $read_text_file2 = read_text_file -> new ($file2); 
while (my $str1 = $read_text_file2 -> get_str ()) {
	# print ++$count."\n";
	
	if ($str1 =~ /\t/) {
		my $temp1 = []; my $pattern1 = "\t"; @$temp1 = split ($pattern1, $str1); 
		
		# print '*' . scalar (@$temp1) ."\n";
		if (scalar (@$temp1) > 1) {
			
			#����������� ��� ����, ����� ������ ������ ������
			foreach (@$temp1) {
				my $clear_str = clear_str -> new ($_);
				$_ = $clear_str -> delete_4 ();
				$clear_str = undef;											
			}
			
			$temp1 -> [1] =~ s/T/ /;
			# print $temp1 -> [1] ."\n";


			# 320,331,339636			
			my $exception = 0;
			my %exception = (
				'325,' => 1,
				
				'412,414,' => 2,
				'412,523,' => 2,
				'412,524,' => 2,
				'320,330,' => 3,
				
				'319,327,346' => 4,
				'319,327,461' => 4,
				'319,327,444' => 4,
				
				'321,' => 5,
				'320,331' => 5,
				
				'332,' => 6,
				'335,' => 6,
				
				'322,' => 7,
				
			);
			
			foreach (keys (%exception)) {
				if ($temp1 -> [20] =~ /$_/iu) {
					$exception = $exception {$_};
				}
			}
			
			my $team_id = undef;
			
			# if ($exception == 0) {
				
				# #������ ��������
				# {
					# my $key = $temp1 -> [4] .'_'.$temp1 -> [0] ;
					# if ($key ne '0' and $key =~ /\d+/  and $key !~ /^0/) {
						# $file1 {$key} = [];
						
						# push (@{$file1 {$key}}, $temp1 -> [4]);
						# push (@{$file1 {$key}}, $temp1 -> [5]);
						# push (@{$file1 {$key}}, $temp1 -> [6]);
						# push (@{$file1 {$key}}, $temp1 -> [7]);
						
						# if ($temp1 -> [12] eq 'true') {
							# push (@{$file1 {$key}}, $temp1 -> [13]);
						# } else {
							# push (@{$file1 {$key}}, $temp1 -> [14]);
						# }
						
						# push (@{$file1 {$key}}, $temp1 -> [1]);
						# push (@{$file1 {$key}}, $temp1 -> [18]);
						# push (@{$file1 {$key}}, $temp1 -> [19]);
						
						# # ������ ID ���� (��� ����� ��� ����������� ������������ XML
						# push (@{$file1 {$key}}, $temp1 -> [0]);
						
						# # if ($temp1 -> [6] eq 'Ilyasova') {
							# # my $str = join ("\t", @$temp1);
							# # push (@file3, $str);
						# # }
						
					# }
				# }

				
				# #������ ���������
				# {
					
					# my $key = $temp1 -> [8] .'_'.$temp1 -> [0] ;
					# if ($key ne '0' and $key =~ /\d+/  and $key !~ /^0/) {
						# $file1 {$key} = [];
						# push (@{$file1 {$key}}, $temp1 -> [8]);
						# push (@{$file1 {$key}}, $temp1 -> [9]);
						# push (@{$file1 {$key}}, $temp1 -> [10]);
						# push (@{$file1 {$key}}, $temp1 -> [11]);
						
						# if ($temp1 -> [12] eq 'true') {
							# push (@{$file1 {$key}}, $temp1 -> [13]);
						# } else {
							# push (@{$file1 {$key}}, $temp1 -> [14]);
						# }
						
						# push (@{$file1 {$key}}, $temp1 -> [1]);
						# push (@{$file1 {$key}}, $temp1 -> [18]);
						# push (@{$file1 {$key}}, $temp1 -> [19]);
						
						# # ������ ID ���� (��� ����� ��� ����������� ������������ XML
						# push (@{$file1 {$key}}, $temp1 -> [0]);
						
						
						# # if ($temp1 -> [6] eq 'Ilyasova') {
							# # my $str = join ("\t", @$temp1);
							# # push (@file3, $str);
						# # }
						
						
					# }
				# }
				
				# # #������ ��� ����������
				# # {
					# # my $key = $temp1 -> [21];
					# # if ($key ne '0' and $key =~ /^\d+$/) {
						# # $file1 {$key} = [];
						# # push (@{$file1 {$key}}, $temp1 -> [21]);
						# # push (@{$file1 {$key}}, $temp1 -> [22]);
						# # push (@{$file1 {$key}}, $temp1 -> [23]);
						# # push (@{$file1 {$key}}, $temp1 -> [24]);
						
						# # if ($temp1 -> [27] eq 'true') {
							# # push (@{$file1 {$key}}, $temp1 -> [13]);
						# # } else {
							# # push (@{$file1 {$key}}, $temp1 -> [14]);
						# # }
						
						# # push (@{$file1 {$key}}, $temp1 -> [1]);
						# # push (@{$file1 {$key}}, $temp1 -> [18]);
						# # push (@{$file1 {$key}}, $temp1 -> [19]);
						
						# # # ������ ID ���� (��� ����� ��� ����������� ������������ XML
						# # push (@{$file1 {$key}}, $temp1 -> [0]);
						
					# # }
				# # }
				
			# }
			
			# ########################## �������
			# if ($temp1 -> [6] eq 'Ilyasova') {
				# my $str = join ("\t", @$temp1);
				# push (@file3, $str);
			# }
			
			
			if ($exception == 1) {
				
				#������ ��������
				{
					my $key = $temp1 -> [4] .'_'.$temp1 -> [0] ;
					if ($key ne '0' and $key =~ /\d+/  and $key !~ /^0/) {
						$file1 {$key} = [];
						push (@{$file1 {$key}}, $temp1 -> [4]);
						push (@{$file1 {$key}}, $temp1 -> [5]);
						push (@{$file1 {$key}}, $temp1 -> [6]);
						push (@{$file1 {$key}}, $temp1 -> [7]);
						
						if ($temp1 -> [12] eq 'true') {
							push (@{$file1 {$key}}, $temp1 -> [13]);
							$team_id = $temp1 -> [13];
						} else {
							push (@{$file1 {$key}}, $temp1 -> [14]);
							$team_id = $temp1 -> [14];
						}
						
						push (@{$file1 {$key}}, $temp1 -> [1]);
						push (@{$file1 {$key}}, $temp1 -> [18]);
						push (@{$file1 {$key}}, $temp1 -> [19]);
						
						# ������ ID ���� (��� ����� ��� ����������� ������������ XML
						push (@{$file1 {$key}}, $temp1 -> [0]);
					}
				}
				
				# if ($temp1 -> [4] =~ '204427') {
					# print '$exception = ' . $exception ."\t". $temp1 -> [4] ."\t". $temp1 -> [5] ."\t". $temp1 -> [6]."\t". $temp1 -> [12] ."\t".'$team_id='.$team_id."\n";
				# }
				
				
				# #������ ���������
				# {
					
					# my $key = $temp1 -> [8] .'_'.$temp1 -> [0] ;
					# if ($key ne '0' and $key =~ /\d+/  and $key !~ /^0/) {
						# $file1 {$key} = [];
						# push (@{$file1 {$key}}, $temp1 -> [8]);
						# push (@{$file1 {$key}}, $temp1 -> [9]);
						# push (@{$file1 {$key}}, $temp1 -> [10]);
						# push (@{$file1 {$key}}, $temp1 -> [11]);
						
						# if ($temp1 -> [12] eq 'true') {
							# push (@{$file1 {$key}}, $temp1 -> [13]);
						# } else {
							# push (@{$file1 {$key}}, $temp1 -> [14]);
						# }
						
						# push (@{$file1 {$key}}, $temp1 -> [1]);
						# push (@{$file1 {$key}}, $temp1 -> [18]);
						# push (@{$file1 {$key}}, $temp1 -> [19]);
						
						# # ������ ID ���� (��� ����� ��� ����������� ������������ XML
						# push (@{$file1 {$key}}, $temp1 -> [0]);
						
					# }
				# }
			}

			if ($exception == 2) {
				
				#������ ��������
				{
					my $key = $temp1 -> [4] .'_'.$temp1 -> [0] ;
					
					if ($key ne '0' and $key =~ /\d+/  and $key !~ /^0/) {
						$file1 {$key} = [];
						push (@{$file1 {$key}}, $temp1 -> [4]);
						push (@{$file1 {$key}}, $temp1 -> [5]);
						push (@{$file1 {$key}}, $temp1 -> [6]);
						push (@{$file1 {$key}}, $temp1 -> [7]);
						
						if ($temp1 -> [12] eq 'true') {
							push (@{$file1 {$key}}, $temp1 -> [13]);
							$team_id = $temp1 -> [13];
						} else {
							push (@{$file1 {$key}}, $temp1 -> [14]);
							$team_id = $temp1 -> [14];
						}
						
						push (@{$file1 {$key}}, $temp1 -> [1]);
						push (@{$file1 {$key}}, $temp1 -> [18]);
						push (@{$file1 {$key}}, $temp1 -> [19]);
						
						# ������ ID ���� (��� ����� ��� ����������� ������������ XML
						push (@{$file1 {$key}}, $temp1 -> [0]);
					}
				}
				
				# if ($temp1 -> [4] =~ '204427') {
					# print '$exception = ' . $exception ."\t". $temp1 -> [4] ."\t". $temp1 -> [5] ."\t". $temp1 -> [6]."\t". $temp1 -> [12] ."\t".'$team_id='.$team_id."\n";
				# }
				
				#������ ���������
				{
					my $key = $temp1 -> [8] .'_'.$temp1 -> [0] ;
					
					if ($key ne '0' and $key =~ /\d+/ and $key !~ /^0/) {
						$file1 {$key} = [];
						push (@{$file1 {$key}}, $temp1 -> [8]);
						push (@{$file1 {$key}}, $temp1 -> [9]);
						push (@{$file1 {$key}}, $temp1 -> [10]);
						push (@{$file1 {$key}}, $temp1 -> [11]);
						
						if ($temp1 -> [12] eq 'true') {
							push (@{$file1 {$key}}, $temp1 -> [13]);
							$team_id = $temp1 -> [13];
						} else {
							push (@{$file1 {$key}}, $temp1 -> [14]);
							$team_id = $temp1 -> [14];
						}
						
						push (@{$file1 {$key}}, $temp1 -> [1]);
						push (@{$file1 {$key}}, $temp1 -> [18]);
						push (@{$file1 {$key}}, $temp1 -> [19]);
						
						# ������ ID ���� (��� ����� ��� ����������� ������������ XML
						push (@{$file1 {$key}}, $temp1 -> [0]);
						
						# print $temp1 -> [20] ."\n";
						# print $temp1 -> [8] ."\t". $temp1 -> [9] ."\t". $temp1 -> [10] ."\n";		
					}
				}
				
				# if ($temp1 -> [8] =~ '204427') {
					# print '$exception = ' . $exception ."\t". $temp1 -> [8] ."\t". $temp1 -> [9] ."\t". $temp1 -> [10]  ."\t". $temp1 -> [12]."\t".'$team_id='.$team_id."\n";
				# }
				
			}
			
			if ($exception == 3) {
				
				#������ ��������
				{
					my $key = $temp1 -> [4] .'_'.$temp1 -> [0] ;
					
					if ($key ne '0' and $key =~ /\d+/  and $key !~ /^0/) {
						$file1 {$key} = [];
						push (@{$file1 {$key}}, $temp1 -> [4]);
						push (@{$file1 {$key}}, $temp1 -> [5]);
						push (@{$file1 {$key}}, $temp1 -> [6]);
						push (@{$file1 {$key}}, $temp1 -> [7]);
						
						if ($temp1 -> [12] eq 'true') {
							push (@{$file1 {$key}}, $temp1 -> [13]);
							$team_id = $temp1 -> [13];
						} else {
							push (@{$file1 {$key}}, $temp1 -> [14]);
							$team_id = $temp1 -> [14];
						}
						
						push (@{$file1 {$key}}, $temp1 -> [1]);
						push (@{$file1 {$key}}, $temp1 -> [18]);
						push (@{$file1 {$key}}, $temp1 -> [19]);
						
						# ������ ID ���� (��� ����� ��� ����������� ������������ XML
						push (@{$file1 {$key}}, $temp1 -> [0]);
					}
				}
				
				# if ($temp1 -> [4] =~ '204427') {
					# print '$exception = ' . $exception ."\t". $temp1 -> [4] ."\t". $temp1 -> [5] ."\t". $temp1 -> [6] ."\t". $temp1 -> [12]."\t".'$team_id='.$team_id."\n";
				# }
				
				
				# #������ ���������
				# {
					# my $key = $temp1 -> [8] .'_'.$temp1 -> [0] ;
					
					# if ($key ne '0' and $key =~ /\d+/ and $key !~ /^0/) {
						# $file1 {$key} = [];
						# push (@{$file1 {$key}}, $temp1 -> [8]);
						# push (@{$file1 {$key}}, $temp1 -> [9]);
						# push (@{$file1 {$key}}, $temp1 -> [10]);
						# push (@{$file1 {$key}}, $temp1 -> [11]);
						
						# if ($temp1 -> [12] eq 'true') {
							# push (@{$file1 {$key}}, $temp1 -> [13]);
						# } else {
							# push (@{$file1 {$key}}, $temp1 -> [14]);
						# }
						
						# push (@{$file1 {$key}}, $temp1 -> [1]);
						# push (@{$file1 {$key}}, $temp1 -> [18]);
						# push (@{$file1 {$key}}, $temp1 -> [19]);
						
						# # ������ ID ���� (��� ����� ��� ����������� ������������ XML
						# push (@{$file1 {$key}}, $temp1 -> [0]);
						
					# }
				# }
			}
			

			if ($exception == 4) {
				
				#������ ��������
				{
					my $key = $temp1 -> [4] .'_'.$temp1 -> [0] ;
					
					if ($key ne '0' and $key =~ /\d+/  and $key !~ /^0/) {
						$file1 {$key} = [];
						push (@{$file1 {$key}}, $temp1 -> [4]);
						push (@{$file1 {$key}}, $temp1 -> [5]);
						push (@{$file1 {$key}}, $temp1 -> [6]);
						push (@{$file1 {$key}}, $temp1 -> [7]);
						
						if ($temp1 -> [12] eq 'true') {
							push (@{$file1 {$key}}, $temp1 -> [14]);
							$team_id = $temp1 -> [14];
						} else {
							push (@{$file1 {$key}}, $temp1 -> [13]);
							$team_id = $temp1 -> [13];
						}
						
						push (@{$file1 {$key}}, $temp1 -> [1]);
						push (@{$file1 {$key}}, $temp1 -> [18]);
						push (@{$file1 {$key}}, $temp1 -> [19]);
						
						# ������ ID ���� (��� ����� ��� ����������� ������������ XML
						push (@{$file1 {$key}}, $temp1 -> [0]);
					}
				}
				
				# if ($temp1 -> [4] =~ '204427') {
					# print '$exception = ' . $exception ."\t". $temp1 -> [4] ."\t". $temp1 -> [5] ."\t". $temp1 -> [6] ."\t". $temp1 -> [12]."\t".'$team_id='.$team_id."\n";
				# }
				
				
				# #������ ���������
				# {
					# my $key = $temp1 -> [8] .'_'.$temp1 -> [0] ;
					
					# if ($key ne '0' and $key =~ /\d+/ and $key !~ /^0/) {
						# $file1 {$key} = [];
						# push (@{$file1 {$key}}, $temp1 -> [8]);
						# push (@{$file1 {$key}}, $temp1 -> [9]);
						# push (@{$file1 {$key}}, $temp1 -> [10]);
						# push (@{$file1 {$key}}, $temp1 -> [11]);
						
						# if ($temp1 -> [12] eq 'true') {
							# push (@{$file1 {$key}}, $temp1 -> [13]);
						# } else {
							# push (@{$file1 {$key}}, $temp1 -> [14]);
						# }
						
						# push (@{$file1 {$key}}, $temp1 -> [1]);
						# push (@{$file1 {$key}}, $temp1 -> [18]);
						# push (@{$file1 {$key}}, $temp1 -> [19]);
						
						# # ������ ID ���� (��� ����� ��� ����������� ������������ XML
						# push (@{$file1 {$key}}, $temp1 -> [0]);
						
					# }
				# }
				
			}
			
			
			if ($exception == 5) {
				
				#������ ��������
				{
					my $key = $temp1 -> [4] .'_'.$temp1 -> [0] ;
					
					if ($key ne '0' and $key =~ /\d+/  and $key !~ /^0/ and $temp1 -> [8] != 0) {
						$file1 {$key} = [];
						push (@{$file1 {$key}}, $temp1 -> [4]);
						push (@{$file1 {$key}}, $temp1 -> [5]);
						push (@{$file1 {$key}}, $temp1 -> [6]);
						push (@{$file1 {$key}}, $temp1 -> [7]);
						
						if ($temp1 -> [12] eq 'true') {
							push (@{$file1 {$key}}, $temp1 -> [14]);
							$team_id = $temp1 -> [14];
						} else {
							push (@{$file1 {$key}}, $temp1 -> [13]);
							$team_id = $temp1 -> [13];
						}
						
						push (@{$file1 {$key}}, $temp1 -> [1]);
						push (@{$file1 {$key}}, $temp1 -> [18]);
						push (@{$file1 {$key}}, $temp1 -> [19]);
						
						# ������ ID ���� (��� ����� ��� ����������� ������������ XML
						push (@{$file1 {$key}}, $temp1 -> [0]);
					}
				}
				
				{
					my $key = $temp1 -> [4] .'_'.$temp1 -> [0] ;
					
					if ($key ne '0' and $key =~ /\d+/  and $key !~ /^0/ and $temp1 -> [8] == 0) {
						$file1 {$key} = [];
						push (@{$file1 {$key}}, $temp1 -> [4]);
						push (@{$file1 {$key}}, $temp1 -> [5]);
						push (@{$file1 {$key}}, $temp1 -> [6]);
						push (@{$file1 {$key}}, $temp1 -> [7]);
						
						if ($temp1 -> [12] eq 'true') {
							push (@{$file1 {$key}}, $temp1 -> [13]);
							$team_id = $temp1 -> [14];
						} else {
							push (@{$file1 {$key}}, $temp1 -> [14]);
							$team_id = $temp1 -> [13];
						}
						
						push (@{$file1 {$key}}, $temp1 -> [1]);
						push (@{$file1 {$key}}, $temp1 -> [18]);
						push (@{$file1 {$key}}, $temp1 -> [19]);
						
						# ������ ID ���� (��� ����� ��� ����������� ������������ XML
						push (@{$file1 {$key}}, $temp1 -> [0]);
					}
				}
				
				
				# if ($temp1 -> [4] =~ '204427') {
					# print '$exception = ' . $exception ."\t". $temp1 -> [4] ."\t". $temp1 -> [5] ."\t". $temp1 -> [6] ."\t". $temp1 -> [12]."\t".'$team_id='.$team_id."\n";
					# print '$temp1 -> [8] = ' . $temp1 -> [8] ."\n";
				# }
				
				
				# #������ ���������
				# {
					# my $key = $temp1 -> [8] .'_'.$temp1 -> [0] ;
					
					# if ($key ne '0' and $key =~ /^\d+$/ and $key !~ /^0/) {
						# $file1 {$key} = [];
						# push (@{$file1 {$key}}, $temp1 -> [8]);
						# push (@{$file1 {$key}}, $temp1 -> [9]);
						# push (@{$file1 {$key}}, $temp1 -> [10]);
						# push (@{$file1 {$key}}, $temp1 -> [11]);
						
						# if ($temp1 -> [12] eq 'true') {
							# push (@{$file1 {$key}}, $temp1 -> [13]);
						# } else {
							# push (@{$file1 {$key}}, $temp1 -> [14]);
						# }
						
						# push (@{$file1 {$key}}, $temp1 -> [1]);
						# push (@{$file1 {$key}}, $temp1 -> [18]);
						# push (@{$file1 {$key}}, $temp1 -> [19]);
						
						# # ������ ID ���� (��� ����� ��� ����������� ������������ XML
						# push (@{$file1 {$key}}, $temp1 -> [0]);
						
					# }
				# }
				
			}

			
			if ($exception == 6) {
				
				#������ ��������
				{
					my $key = $temp1 -> [4] .'_'.$temp1 -> [0] ;
					
					if ($key ne '0' and $key =~ /\d+/  and $key !~ /^0/) {
						$file1 {$key} = [];
						push (@{$file1 {$key}}, $temp1 -> [4]);
						push (@{$file1 {$key}}, $temp1 -> [5]);
						push (@{$file1 {$key}}, $temp1 -> [6]);
						push (@{$file1 {$key}}, $temp1 -> [7]);
						
						if ($temp1 -> [12] eq 'true') {
							push (@{$file1 {$key}}, $temp1 -> [13]);
							$team_id = $temp1 -> [13];
						} else {
							push (@{$file1 {$key}}, $temp1 -> [14]);
							$team_id = $temp1 -> [14];
						}
						
						push (@{$file1 {$key}}, $temp1 -> [1]);
						push (@{$file1 {$key}}, $temp1 -> [18]);
						push (@{$file1 {$key}}, $temp1 -> [19]);
						
						# ������ ID ���� (��� ����� ��� ����������� ������������ XML
						push (@{$file1 {$key}}, $temp1 -> [0]);
					}
				}
				
				# if ($temp1 -> [4] =~ '204427') {
					# print '$exception = ' . $exception ."\t". $temp1 -> [4] ."\t". $temp1 -> [5] ."\t". $temp1 -> [6] ."\t". $temp1 -> [12]."\t".'$team_id='.$team_id."\n";
				# }
				
				
				# #������ ���������
				# {
					# my $key = $temp1 -> [8] .'_'.$temp1 -> [0] ;
					
					# if ($key ne '0' and $key =~ /^\d+$/ and $key !~ /^0/) {
						# $file1 {$key} = [];
						# push (@{$file1 {$key}}, $temp1 -> [8]);
						# push (@{$file1 {$key}}, $temp1 -> [9]);
						# push (@{$file1 {$key}}, $temp1 -> [10]);
						# push (@{$file1 {$key}}, $temp1 -> [11]);
						
						# if ($temp1 -> [12] eq 'true') {
							# push (@{$file1 {$key}}, $temp1 -> [13]);
						# } else {
							# push (@{$file1 {$key}}, $temp1 -> [14]);
						# }
						
						# push (@{$file1 {$key}}, $temp1 -> [1]);
						# push (@{$file1 {$key}}, $temp1 -> [18]);
						# push (@{$file1 {$key}}, $temp1 -> [19]);
						
						# # ������ ID ���� (��� ����� ��� ����������� ������������ XML
						# push (@{$file1 {$key}}, $temp1 -> [0]);
						
					# }
				# }
			}
			
			if ($exception == 7) {
				
				#������ ��������
				{
					my $key = $temp1 -> [4] .'_'.$temp1 -> [0] ;
					
					if ($key ne '0' and $key =~ /\d+/  and $key !~ /^0/) {
						$file1 {$key} = [];
						push (@{$file1 {$key}}, $temp1 -> [4]);
						push (@{$file1 {$key}}, $temp1 -> [5]);
						push (@{$file1 {$key}}, $temp1 -> [6]);
						push (@{$file1 {$key}}, $temp1 -> [7]);
						
						if ($temp1 -> [12] eq 'true') {
							push (@{$file1 {$key}}, $temp1 -> [13]);
							$team_id = $temp1 -> [13];
						} else {
							push (@{$file1 {$key}}, $temp1 -> [14]);
							$team_id = $temp1 -> [14];
						}
						
						push (@{$file1 {$key}}, $temp1 -> [1]);
						push (@{$file1 {$key}}, $temp1 -> [18]);
						push (@{$file1 {$key}}, $temp1 -> [19]);
						
						# ������ ID ���� (��� ����� ��� ����������� ������������ XML
						push (@{$file1 {$key}}, $temp1 -> [0]);
					}
				}
			}
			
			








			#������ ��� ����������
			#�������� ��� ������� ��� ���� �������
			{
				my $key = $temp1 -> [21];
				if ($key ne '0' and $key =~ /^\d+$/) {
					
					my @a1 = split ('Ball Delivered >', $temp1 -> [25]);
					if (scalar (@a1) > 0) {
						
						my $a2_str_split = $temp1 -> [26];
						$a2_str_split =~ s/243,/244,/g;
						
						my @a2 = split (',244,', $a2_str_split);
						if (scalar (@a2) > 0) {
							foreach (@a2) {
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;
							}
						}
						
						if (scalar (@a1) != scalar (@a2)) {
							print 'scalar @a1 = ' . scalar (@a1) ."\n";
							print 'scalar @a2 = ' . scalar (@a2) ."\n";
							print join ('Ball Delivered',@a1) ."\n";
							print join ('244,',@a2) ."\n";
							print "\n\n";
						}

						foreach (@a1) {
							my $clear_str = clear_str -> new ($_);
							$_ = $clear_str -> delete_3_s ();
							$_ = $clear_str -> delete_4 ();
							$clear_str = undef;
							
							my $str2 = shift (@a2);
							my @str2 = split (',', $str2);
							
							
							my $player_id = undef;
							if (scalar (@str2) > 0) {
								foreach (@str2) {
									my $clear_str = clear_str -> new ($_);
									$_ = $clear_str -> delete_3_s ();
									$_ = $clear_str -> delete_4 ();
									$clear_str = undef;
								}
								$player_id = shift (@str2);
							}
							
							my $str1 = $_;
							my @str1 = split (/\s+/,$str1);
							
							my $player_fn = undef;
							my $player_ln = undef;
							my $player_number = undef;
							
							
							if (scalar (@str1) > 0) {
								foreach (@str1) {
									my $clear_str = clear_str -> new ($_);
									$_ = $clear_str -> delete_3_s ();
									$_ = $clear_str -> delete_4 ();
									$clear_str = undef;
								}
								
								$player_number = shift (@str1);
								$player_fn = shift (@str1);
								$player_ln = shift (@str1);
								
								
								$file1 {$player_id} = [];
								push (@{$file1 {$player_id}}, $player_id);
								push (@{$file1 {$player_id}}, $player_fn);
								push (@{$file1 {$player_id}}, $player_ln);
								push (@{$file1 {$player_id}}, $player_number);
								
								if ($temp1 -> [27] eq 'true') {
									push (@{$file1 {$player_id}}, $temp1 -> [13]);
								} else {
									push (@{$file1 {$player_id}}, $temp1 -> [14]);
								}
								
								push (@{$file1 {$player_id}}, $temp1 -> [1]);
								push (@{$file1 {$player_id}}, $temp1 -> [18]);
								push (@{$file1 {$player_id}}, $temp1 -> [19]);
								
								# ������ ID ���� (��� ����� ��� ����������� ������������ XML
								push (@{$file1 {$player_id}}, $temp1 -> [0]);
							}
							
						}
					}
				}
			}











			
			#�������
			{
				my $key = $temp1 -> [13];
				if ($key ne '0' and $key =~ /^\d+$/) {
					$file2 {$key} = [];
					push (@{$file2 {$key}}, $temp1 -> [13]);
					push (@{$file2 {$key}}, $temp1 -> [2]);
					push (@{$file2 {$key}}, $temp1 -> [15]);
					push (@{$file2 {$key}}, $temp1 -> [1]);
					
					push (@{$file2 {$key}}, $temp1 -> [18]);
					push (@{$file2 {$key}}, $temp1 -> [19]);
				}
			}
			
			{
				my $key = $temp1 -> [14];
				if ($key ne '0' and $key =~ /^\d+$/) {
					$file2 {$key} = [];
					push (@{$file2 {$key}}, $temp1 -> [14]);
					push (@{$file2 {$key}}, $temp1 -> [3]);
					push (@{$file2 {$key}}, $temp1 -> [16]);
					push (@{$file2 {$key}}, $temp1 -> [1]);
					
					push (@{$file2 {$key}}, $temp1 -> [18]);
					push (@{$file2 {$key}}, $temp1 -> [19]);
				}
			}
			
			
			
			
			
			
			
			
			
			
			
		}
	}
}
$read_text_file2 = undef;

#������� ����, ������ ����� ��� �� ���� � �������.
if (scalar (keys(%file1)) > 0) {

	my @headers = (
		'player_id',
		'player_FN',
		'player_LN',
		'player_number',
		'team_id',
		'date',
		'league',
		'gender',
		'game_id',		
	);	
	
	if (scalar (keys (%file1) > 0)) {
		my $write_text_file_mode_rewrite = write_text_file_mode_rewrite -> new ($file3);
		$write_text_file_mode_rewrite -> put_str (join ("\t", @headers)."\n");
		foreach (keys (%file1)) {
			my $str = join ("\t", @{$file1 {$_}});
			
			$write_text_file_mode_rewrite -> put_str ($str."\n");
			
			my $insert2 = [];
			my $insert = {};
			tie (%$insert, 'Tie::IxHash');
			
			$insert -> {id} = $file1 {$_} -> [0]; 
			$insert -> {player_first_name} = $file1 {$_} -> [1]; 
			$insert -> {player_last_name} = $file1 {$_} -> [2]; 
			$insert -> {player_number} = $file1 {$_} -> [3]; 
			$insert -> {team_id} = $file1 {$_} -> [4]; 
			$insert -> {match_date} = $file1 {$_} -> [5];
			$insert -> {league} = $file1 {$_} -> [6];
			
			
			my %league = (
				# 1 => 'NBA', 
				# 2 => 'WNBA', 
				# 5 => 'College Men', 
				# 6 => 'College Women',
				# 7 => 'FIBA - National Teams',
				# 8 => 'Summer League',
				# 9 => 'NBA Pre-Draft Camp',
				# 10 => 'NBA D-League', 
				# 28 => 'International', 
				# 30 => 'All-Star', 
				
				'NBA' => 1, 
				'WNBA' => 2, 
				'College Men' => 5,  
				'College Women' => 6,
				'FIBA - National Teams' => 7,
				'Summer League' => 8, 
				'NBA Pre-Draft Camp' => 9,
				'NBA D-League' => 10, 
				'International' => 28,
				'All-Star' => 30, 
			);
			
			
			if (exists ($league {$insert -> {league}})) {
				$insert -> {league_id} = $league {$insert -> {league}};
			}
			
			$insert -> {gender} = $file1 {$_} -> [7]; # 0 - ��� �� ���������, 1-�������, 2-�������
			$insert -> {match_id} = $file1 {$_} -> [8]; 
			
			# foreach (keys (%$insert)) {
				# print $_. "\t". $insert -> {$_} ."\n";
			# }
			
			push (@{$insert2}, $insert);

			my $encode_json = encode_json ($insert2);
			# print $encode_json ."\n";
			
			post_players ($encode_json);				
			
		}
		$write_text_file_mode_rewrite = undef;
	}
}


if (scalar (keys(%file2)) > 0) {

	my @headers = (
		'team_id',
		'team_name',
		'team_short_name',
		'date',
		'league',
		'gender',

	);	
	
	if (scalar (keys (%file2) > 0)) {
		my $write_text_file_mode_rewrite = write_text_file_mode_rewrite -> new ($file4);
		$write_text_file_mode_rewrite -> put_str (join ("\t", @headers)."\n");
		
		foreach (keys (%file2)) {
			my $str = join ("\t", @{$file2 {$_}});
			$write_text_file_mode_rewrite -> put_str ($str."\n");
			
			my $insert2 = [];
			my $insert = {};
			tie (%$insert, 'Tie::IxHash');
			
			$insert -> {id} = $file2 {$_} -> [0]; 
			$insert -> {team_name}= $file2 {$_} -> [1]; 
			$insert -> {team_short_name}= $file2 {$_} -> [2]; 
			$insert -> {match_date}= $file2 {$_} -> [3]; 
			$insert -> {league} = $file2 {$_} -> [4]; 
			$insert -> {gender} = $file2 {$_} -> [5]; 
			
			
			push (@{$insert2}, $insert);
			
			my $encode_json = encode_json ($insert2);
			# print $encode_json ."\n";
			
			
			post_teams ($encode_json);	
					
			
		}
		$write_text_file_mode_rewrite = undef;
	}
	
	
	# if (scalar (keys (%file2) > 0)) {
		# my $write_text_file_mode_rewrite = write_text_file_mode_rewrite -> new ($file4);
		# $write_text_file_mode_rewrite -> put_str (join ("\t", @headers)."\n");
		# foreach (keys (%file2)) {
			# my $temp2 = [];
			# push (@$temp2, $_);
			# push (@$temp2, $file2 {$_});
			# my $str = join ("\t", @$temp2);
			# $write_text_file_mode_rewrite -> put_str ($str."\n");
		# }
		# $write_text_file_mode_rewrite = undef;
	# }
}



# print '$ex_count  = ' . $ex_count ."\n";
# foreach (@file3) {
	# print $_ ."\n";
# }





sub entities_decode {
	use HTML::Entities;
	my $str = shift;
	#����� ������� ������ ����� ������� decode � ����� ���������
	$str = decode ('cp1251', $str);
	$str = decode_entities ($str);
	$str = encode ('cp1251', $str);
	return $str;
}

sub get_file_type_2 {
	my $file = shift;
	my %file = ();
	open (FILE, $file) or die;
	while (<FILE>) {
		chomp;
		$_ = encode ('cp1251', decode ('utf8', $_));
		if ($_ =~ /;/) {
			my $str = [];
			@$str = split (";",$_); 
			if (scalar (@$str) == 2) {
				$file{$str -> [1]} = $str -> [0];
			}
		}
	}
	return %file;
}


sub get_file_type_3 {
	my $file = shift;
	my %file = ();
	open (FILE, $file) or die;
	while (<FILE>) {
		chomp;
		$_ = encode ('cp1251', decode ('utf8', $_));
		if ($_ =~ /;/) {
			my $str = [];
			@$str = split (";",$_); 
			if (scalar (@$str) == 3) {

				$str->[2] =~ s/\"//g; 
				$str->[2] = lc ($str->[2]); 
				# print $str->[2] ."\n";
				# print $str->[0] ."\n";				
				$file{$str -> [2]} = $str -> [0];
			}
		}
	}
	return %file;
}


sub post_teams {
	my $postdata = shift;
	
	my $res = 0;
	do {
		my $key_import2 = '22812357092873478234729374';
		my $url = 'http://data.instatfootball.tv/api/import2?key='.$key_import2.'&method=UpdateBasketballSynergyTeams';	
		# my $postdata = 'firstsec=1&email=is.fin.dept%40gmail.com&pwd=basket55&women=0&B1=Login';

		push (@{ $lwp->requests_redirectable }, 'POST');
		my $req = HTTP::Request -> new (
		'POST' => $url,
			[
				# 'User-Agent' => 'Mozilla/5.0 (Windows NT 5.1; rv:11.0) Gecko/20100101 Firefox/11.0',
				# 'Accept-Language' => 'ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
				# 'Referer' => 'http://basketball.eurobasket.com/player/Andrey-Vorontsevich/Russia/CSKA-Moscow/71366',
				# 'Content-Type' => 'application/json',
				
				'Accept' => '*/*',
				'Content-Type' => 'multipart/form-data; boundary=----------------------------4b5789fa8d3f',
				
			]
		);
		
		
		my $str = 
'------------------------------4b5789fa8d3f
Content-Disposition: form-data; name="json"

'.$postdata.'
------------------------------4b5789fa8d3f--';

		$req -> content ($str);
		
		my $file = getcwd () .'/txt/teams.html';
		$res = $lwp -> request ($req, $file); 
		print $res -> code ."\t" . $url ."\n";
		
		
		#sleep 1;
		
	} while ($res -> code != 200);

	# my $sleep = Random ($sleep2, $sleep3); 
	# sleep $sleep;		
	
	return 1;
}
		
sub post_players {
	my $postdata = shift;
	my $res = 0;
	
	do {
	
		my $key_import2 = '22812357092873478234729374';
			my $url = 'http://data.instatfootball.tv/api/import2?key='.$key_import2.'&method=UpdateBasketballSynergyPlayers';	
		# my $postdata = 'firstsec=1&email=is.fin.dept%40gmail.com&pwd=basket55&women=0&B1=Login';

		push (@{ $lwp->requests_redirectable }, 'POST');
		my $req = HTTP::Request -> new (
		'POST' => $url,
			[
				# 'User-Agent' => 'Mozilla/5.0 (Windows NT 5.1; rv:11.0) Gecko/20100101 Firefox/11.0',
				# 'Accept-Language' => 'ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
				# 'Referer' => 'http://basketball.eurobasket.com/player/Andrey-Vorontsevich/Russia/CSKA-Moscow/71366',
				# 'Content-Type' => 'application/json',
				
				'Accept' => '*/*',
				'Content-Type' => 'multipart/form-data; boundary=----------------------------4b5789fa8d3f',
				
			]
		);
		
		
	my $str = 
'------------------------------4b5789fa8d3f
Content-Disposition: form-data; name="json"

'.$postdata.'
------------------------------4b5789fa8d3f--';
		

		$req -> content ($str);
		
		my $file = getcwd () .'/txt/players.html';
		$res = $lwp -> request ($req, $file); 
		print $res -> code ."\t" . $url ."\n";
		
		#sleep 1;
	} while ($res -> code != 200);
	
		
	# my $sleep = Random ($sleep2, $sleep3); 
	# sleep $sleep;		
	return 1;
}


