package get_phone;
use MD5;
use url_to_file;
use work_mysql;
use Encode qw (encode decode);
use Data::Dumper;

sub new {
	my $class = shift;
	my $content = shift;
	my $self = {};
	$self -> {content} = $content;
	return bless $self; 
}

sub do {
	my $self = shift;
	my $content2 = $self -> {content};
	my $return  = {};
	$content2 =~ s/<script.+?<\/script>//g;
	
	my $phone = '-'; 
	my $phone_short = '-'; 
	my @array = ();
	my $pattern1 = '<h3>Телефон:</h3>(.+?)</div>';
	my $work_for_content = work_for_content -> new ($content2); 
	my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
	if (defined $work_for_content_result -> [0]) {
		foreach (@$work_for_content_result) {		
			my $clear_str = clear_str -> new ($_);
			$_ = $clear_str -> delete_3 ();
			$_ = $clear_str -> delete_4 ();
			$clear_str = undef;			
			
			my $pattern1 = '(\d)';
			my $work_for_content = work_for_content -> new ($_); 
			my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
			if (defined $work_for_content_result -> [0]) {
				foreach (@$work_for_content_result) {		
					my $clear_str = clear_str -> new ($_);
					$_ = $clear_str -> delete_3 ();
					$_ = $clear_str -> delete_4 ();
					$clear_str = undef;									
			
					$_ =~ s/\s+//g;
					$_ =~ s/^\s+$//; 
					if ($_ eq '') {$_ = '-';}
					push (@array, $_);
				}
			}
		}
	}
	
	if (scalar (@array) > 0) {
		my $str = join ('', @array);
		$phone = $str;
		
		#определяем короткий номер (8 символов с конца)
		if (scalar (@array) > 8) {
			while (scalar (@array) > 8) {
				shift (@array); 
			}
			
			my $str2 = join ('', @array);
			$phone_short = $str2;
			
		} else {
			my $str2 = join ('', @array);
			$phone_short = $str2;
		}
		
	} else {
		$phone = '-';
		$phone_short = '-';
	}
		
	$return -> {phone} = $phone;		
	$return -> {phone_short} = $phone_short;
	
	return $return;
}



1;
