#!/usr/bin/env perl
use strict;
use warnings;
use locale;
use dir_scan_recurce;
use read_text_file; 
use write_text_file_mode_rewrite; 
use clear_str;
use delete_duplicate_from_array; 
use read_inifile;
use url_to_file;
use Encode qw (encode decode);
use Net::FTP;

sub get_base_path {
	use Cwd; 
	my $cwd = getcwd ();
	return $cwd;
}

my $read_inifile = read_inifile -> new ('graber.ini'); 
my $host = $read_inifile -> get ('host');	
my $ftp_host = $read_inifile -> get ('ftp_host');
my $ftp_user = $read_inifile -> get ('ftp_user');
my $ftp_password = $read_inifile -> get ('ftp_password');
my $company_id = $read_inifile -> get ('company_id');

my $workdir1 =  get_base_path ();
my $workdir2 = get_base_path ().'/txt'; 
my $workdir3 = 'pictures'; 
my $archive = 1; 

my $count = 0;
my @read_text_file1 = ();
my $dir_scan_recurce = dir_scan_recurce -> new ($workdir2);
while (my $file1 = $dir_scan_recurce -> get_file ()) {
	print ++$count."\n";
	
	my $pattern = 'csv$';
	if ($file1 =~ /$pattern/) {
		
		print $file1 ."\n";
		my $unlink_file = $file1; 
		
		$file1 =~ s/^.+\///;
		chdir ($workdir2); 
		
		$archive = $file1;
		$archive =~ s/\.csv$/.zip/;
		$archive = $workdir1.'/'.$archive;
		
		my $system = 'zip '.$archive.' '. $file1;
		system ($system);
		
		chdir ($workdir1); 
		
		$system = 'zip -r '.$archive.' '. $workdir3;
		system ($system);
		chdir ($workdir1);
	}
}


if (-f $archive) {
	my $file1 = $archive; 
	$file1 =~ s/^.+\///;
	my $ftp = Net::FTP -> new($ftp_host, Debug => 0) or die "Cannot connect to $ftp_host: $@";
	$ftp-> login ($ftp_user, $ftp_password) or die "Cannot login ", $ftp->message;
	$ftp -> cwd ('import') or die; 
	$ftp-> binary; #����� ��� �������� �xe ������, zip �������
	$ftp-> put ($file1, $file1) or die "put failed ", $ftp->message;
	$ftp-> quit;
	$ftp = undef;

	chdir ($workdir1); 
	# unlink ($file1) or die (print $file1. "\n");

	
}



	







sub entities_decode {
	use HTML::Entities;
	my $str = shift;
	#����� ������� ������ ����� ������� decode � ����� ���������
	$str = decode ('cp1251', $str);
	$str = decode_entities ($str);
	$str = encode ('cp1251', $str);
	return $str;
}
