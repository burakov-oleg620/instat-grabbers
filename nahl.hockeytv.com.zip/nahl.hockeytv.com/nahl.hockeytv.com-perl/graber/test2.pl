#!/usr/bin/env perl
use strict;
use warnings;

sub get_date {
	use Date::Calc qw (Time_to_Date Date_to_Time);
	# my ($year,$month,$day, $hour,$min,$sec) = Time_to_Date (time ());
	my @date = Time_to_Date (time ());
	
	if (scalar (@date) > 0) {
		foreach (@date) {
			while (length ($_) < 2) {
				$_ = '0'.$_;
			}
		}
	}
	my $str = $date[0] .'-'.$date[1] .'-'.$date[2] .' '.$date [3] .':'.$date[4].':'.$date[5];
	return $str;
}	


print get_date () ."\n";