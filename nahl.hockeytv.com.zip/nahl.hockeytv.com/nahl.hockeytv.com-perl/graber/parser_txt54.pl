#!/usr/bin/env perl
use strict;
use warnings;
use dir_scan_recurce;
use read_text_file; 
use write_text_file_mode_rewrite; 
use clear_str;
use delete_duplicate_from_array; 
use read_inifile;
use url_to_file;
use Encode qw (encode decode);
use date_time;
use MD5;
use File::Copy;
use File::Path;

use work_mysql;
use Date::Calc qw (Time_to_Date Date_to_Time);
use work_mysql_agregator;
use work_mysql_agregator2;
use MD5;
use Cwd qw (realpath);
use work_for_content;
use write_to_txt1;
use write_to_txt2;
use JSON::XS;
use Data::Dumper;
use locale;
use Tie::IxHash;
use LWP::UserAgent;
use HTTP::Request;
use HTTP::Response;
use HTTP::Cookies;


sub get_base_path {
	use Cwd; 
	my $cwd = getcwd ();
	return $cwd;
}

my $read_inifile = read_inifile -> new ('graber.ini'); 
my $host = $read_inifile -> get ('host');	
#Читаю установки из ини файла
my $mysql_dbdriver = $read_inifile -> get ('mysql_dbdriver');
my $mysql_host = $read_inifile -> get ('mysql_host');
my $mysql_port = $read_inifile -> get ('mysql_port');
my $mysql_user = $read_inifile -> get ('mysql_user');
my $mysql_user_password = $read_inifile -> get ('mysql_user_password');
if ($mysql_user_password eq ' ') {$mysql_user_password = '';}
my $mysql_base = $read_inifile -> get ('mysql_base');
my $mysql_table = $read_inifile -> get ('mysql_table');
my $content_table = $read_inifile -> get ('content_table');

my $lwp = undef;
$lwp = LWP::UserAgent -> new ();
$lwp -> cookie_jar (HTTP::Cookies->new ());
$lwp -> agent ('Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.2.16) Gecko/20110319 Firefox/3.6.16');
$lwp -> timeout (60);
# $lwp -> proxy ('http', 'http://127.0.0.1:8080');


my $workdir1 = get_base_path.'/txt'; 
my $workdir2 = get_base_path.'/picture'; 

my $file1 = $workdir1.'/write_text_file_mode_rewrite333s.xls'; 
my $file2 = $workdir1.'/write_text_file_mode_rewrite33s.xls'; 
my $file3 = $workdir1.'/write_text_file_mode_rewrite55.xls'; 



# my ($year,$month,$day, $hour,$min,$sec) = Time_to_Date (time () + 4*3600);
# my $file2 = $workdir1.'/write_text_file_mode_rewrite2.xls'; 
# my $file2 = $workdir1.'/'.$year.'-'.$month.'-'.$day.'-'. $hour.'-'.$min.'-'.$sec.'-'.$host.'.xls'; 


# my 	$work_mysql = work_mysql -> new (
		# $mysql_dbdriver,
		# $mysql_host,
		# $mysql_port,
		# $mysql_user,
		# $mysql_user_password,
		# $mysql_base
	# ); 	

# my $sql = 'SET NAMES CP1251';
# $work_mysql -> run_query ($sql); 


# #Создаем дескриптор на mysql соединение
# my $work_mysql_agregator = work_mysql_agregator -> new (
	# $mysql_dbdriver,
	# $mysql_host,
	# $mysql_port,
	# $mysql_user,
	# $mysql_user_password,
	# $mysql_base,
	# $read_inifile -> {agregator}
# ); 

# if ($read_inifile -> {clear_agregator} == 1) {
	# $work_mysql_agregator -> drop ();
# }
# $work_mysql_agregator -> create ();		
# # $work_mysql_agregator2 -> clear ($read_inifile -> {clear_agregator_time});

#Создаем дескриптор на mysql соединение
my $work_mysql_agregator2 = work_mysql_agregator2 -> new (
	$mysql_dbdriver,
	$mysql_host,
	$mysql_port,
	$mysql_user,
	$mysql_user_password,
	$mysql_base,
	$read_inifile -> {agregator2}
); 

if ($read_inifile -> {clear_agregator} == 1) {
	$work_mysql_agregator2 -> drop ();
}
$work_mysql_agregator2 -> create ();		
$work_mysql_agregator2 -> clear ($read_inifile -> {clear_agregator_time});	



my $count = 0;
my @read_text_file1 = ();
my %file1 = ();
tie (%file1, 'Tie::IxHash');

{
	#для того, чтобы забрать инстат_ID берем справочник команд
	my $read_text_file2 = read_text_file -> new ($file1); 
	while (my $str1 = $read_text_file2 -> get_str ()) {
		print ++$count."\n";
		
		if ($str1 =~ /\t/) {
			my $temp1 = []; my $pattern1 = "\t"; @$temp1 = split ($pattern1, $str1); 
			
			# print '*' . scalar (@$temp1) ."\n";
			if (scalar (@$temp1) > 1) {
				
				#конструкция для того, чтобы убрать пустые строки
				foreach (@$temp1) {
					my $clear_str = clear_str -> new ($_);
					$_ = $clear_str -> delete_4 ();
					$clear_str = undef;											
				}
				
				$file1 {$temp1 -> [0]} = $temp1;
			}			
		}
	}
}

my %file2 = ();
tie (%file2, 'Tie::IxHash');

{
	#для того, чтобы забрать инстат_ID берем справочник игроков
	my $read_text_file2 = read_text_file -> new ($file2); 
	while (my $str1 = $read_text_file2 -> get_str ()) {
		print ++$count."\n";
		
		if ($str1 =~ /\t/) {
			my $temp1 = []; my $pattern1 = "\t"; @$temp1 = split ($pattern1, $str1); 
			
			# print '*' . scalar (@$temp1) ."\n";
			if (scalar (@$temp1) > 1) {
				
				#конструкция для того, чтобы убрать пустые строки
				foreach (@$temp1) {
					my $clear_str = clear_str -> new ($_);
					$_ = $clear_str -> delete_4 ();
					$clear_str = undef;											
				}
				
				$file2 {$temp1 -> [0]} = $temp1;
			}			
		}
	}
}


my $read_text_file2 = read_text_file -> new ($file3); 
while (my $str1 = $read_text_file2 -> get_str ()) {
	print ++$count."\n";
	
	if ($str1 =~ /\t/) {
		my $temp1 = []; my $pattern1 = "\t"; @$temp1 = split ($pattern1, $str1); 
		
		# print '*' . scalar (@$temp1) ."\n";
		if (scalar (@$temp1) > 1) {
			
			#конструкция для того, чтобы убрать пустые строки
			foreach (@$temp1) {
				my $clear_str = clear_str -> new ($_);
				$_ = $clear_str -> delete_4 ();
				$clear_str = undef;											
			}
			
			my $match_id = $temp1 -> [0];			
			
			my $temp2 = [];
			
			
			push (@$temp2, '<gsmrs version="2.0" sport="soccer" lang="en" last_generated="'.get_date ().'" last_updated="'.get_date ().'">');
			
			push (@$temp2, '<method method_id="2" name="get_matches">');
			push (@$temp2, '<parameter name="detailed" value="yes"/>');
			push (@$temp2, '<parameter name="host" value="'.$host.'"/>');
			push (@$temp2, '<parameter name="id" value="'.$match_id.'"/>');
			push (@$temp2, '<parameter name="instat_id" value="'.$temp1 -> [14].'"/>');
			push (@$temp2, '<parameter name="date" value="'.$temp1 -> [1].'"/>');
			push (@$temp2, '<parameter name="unixtime" value="'.get_date_to_time ($temp1 -> [1]).'" />');
			
			
			push (@$temp2, '<parameter name="lang" value="en"/>');
			push (@$temp2, '<parameter name="type" value="match"/>');
			#push (@$temp2, '<parameter name="url" value="'.$temp1 -> [0].'" />');
			push (@$temp2, '</method>');
			
			push (@$temp2, '<competition>');
			push (@$temp2, '<year>'.$temp1 -> [10].'</year>');
			push (@$temp2, '<name>'.$temp1 -> [11].'</name>');
			push (@$temp2, '</competition>');
			
			
			push (@$temp2, '<teams>');
			push (@$temp2, '<team>');
			push (@$temp2, '<homeTeamId>'.entities_encode ($temp1 -> [5]).'</homeTeamId> ');
			push (@$temp2, '<homeTeamCode>'.entities_encode ($temp1 -> [4]).'</homeTeamCode> ');
			push (@$temp2, '<homeTeamName>'.entities_encode ($temp1 -> [3]).'</homeTeamName> ');
			push (@$temp2, '<homeTeamFullName>'.entities_encode($temp1 -> [2]).'</homeTeamFullName> ');
			if (exists ($file1 {$temp1 -> [5]})) {
				push (@$temp2, '<homeTeamIdInstat>'.entities_encode ($file1 {$temp1 -> [5]} -> [6]).'</homeTeamIdInstat> ');
			}
			
			push (@$temp2, '</team>');
			
			push (@$temp2, '<team>');
			push (@$temp2, '<awayTeamId>'.entities_encode ($temp1 -> [9]).'</awayTeamId> ');
			push (@$temp2, '<awayTeamCode>'.entities_encode ($temp1 -> [8]).'</awayTeamCode> ');
			push (@$temp2, '<awayTeamName>'.entities_encode ($temp1 -> [7]).'</awayTeamName> ');
			push (@$temp2, '<awayTeamFullName>'.entities_encode ($temp1 -> [6]).'</awayTeamFullName> ');
			if (exists ($file1 {$temp1 -> [9]})) {
				push (@$temp2, '<awayTeamIdInstat>'.entities_encode ($file1 {$temp1 -> [9]} -> [6]).'</awayTeamIdInstat> ');
			}
			
			push (@$temp2, '</team>');
			push (@$temp2, '</teams>');
			
			push (@$temp2, '<scores>');
			push (@$temp2, '<homeScore>'.entities_encode ($temp1 -> [12]).'</homeScore> ');
			push (@$temp2, '<awayScore>'.entities_encode ($temp1 -> [13]).'</awayScore> ');
			push (@$temp2, '</scores>');
			
			
			if ($temp1 -> [16] ne '-') {
				
				my $picture =  $temp1 -> [16];
				my @picture = split ('\|\|', $picture);
				if (scalar (@picture) > 0) {
					push (@$temp2, '<events>');	
					foreach (@picture) {
						my $clear_str = clear_str -> new ($_);
						$_ = $clear_str -> delete_4 ();
						$clear_str = undef;		
						
						push (@$temp2, '<event>');
						
						my $pattern1 = '(<.+?>.+?<\/.+?>)';
						my $work_for_content = work_for_content -> new ($_); 
						my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								
								my $label = undef;
								my $value = undef;
								
								my $pattern1 = '^<(.+?)>';
								my $work_for_content = work_for_content -> new ($_); 
								my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
								if (defined $work_for_content_result -> [0]) {
									foreach (@$work_for_content_result) {		
										my $clear_str = clear_str -> new ($_);
										# $_ = $clear_str -> delete_3_s ();
										$_ = $clear_str -> delete_4 ();
										$clear_str = undef;		
										
										$label = $_;
									}
								}
								
								$pattern1 = '^(.+)$';
								$work_for_content = work_for_content -> new ($_); 
								$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
								if (defined $work_for_content_result -> [0]) {
									foreach (@$work_for_content_result) {		
										my $clear_str = clear_str -> new ($_);
										$_ = $clear_str -> delete_3_s ();
										$_ = $clear_str -> delete_4 ();
										$clear_str = undef;		
										
										$value = entities_encode ($_);
									}
								}
								
								if (defined ($label) and  defined ($value)) {
									my $str = '<'.$label.'>'.$value.'</'.$label.'>';
									push (@$temp2, $str);
								}
								
							}							
						}
						push (@$temp2, '</event>');
					}
					push (@$temp2, '</events>');
				}
			}
			
			
			if ($temp1 -> [15] ne '-') {
				
				my $picture =  $temp1 -> [15];
				
				my @picture = split ('\|\|', $picture);
				if (scalar (@picture) > 0) {
					push (@$temp2, '<players>');	
					foreach (@picture) {
						my $clear_str = clear_str -> new ($_);
						$_ = $clear_str -> delete_4 ();
						$clear_str = undef;		
						
						push (@$temp2, '<player>');
						
						my $pattern1 = '(<.+?>.+?<\/.+?>)';
						my $work_for_content = work_for_content -> new ($_); 
						my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								
								my $label = undef;
								my $value = undef;
								
								my $pattern1 = '^<(.+?)>';
								my $work_for_content = work_for_content -> new ($_); 
								my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
								if (defined $work_for_content_result -> [0]) {
									foreach (@$work_for_content_result) {		
										my $clear_str = clear_str -> new ($_);
										# $_ = $clear_str -> delete_3_s ();
										$_ = $clear_str -> delete_4 ();
										$clear_str = undef;		
										
										$label = $_;
									}
								}
								
								$pattern1 = '^(.+)$';
								$work_for_content = work_for_content -> new ($_); 
								$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
								if (defined $work_for_content_result -> [0]) {
									foreach (@$work_for_content_result) {		
										my $clear_str = clear_str -> new ($_);
										$_ = $clear_str -> delete_3_s ();
										$_ = $clear_str -> delete_4 ();
										$clear_str = undef;		
										
										$value = entities_encode ($_);
									}
								}
								
								if (defined ($label) and  defined ($value)) {
									my $str = '<'.$label.'>'.$value.'</'.$label.'>';
									push (@$temp2, $str);
								}
							}
						}
								
						push (@$temp2, '</player>');
					}
					push (@$temp2, '</players>');
				}
			}
			
			
			push (@$temp2, '</gsmrs>');
			
			
			
			
			push (@read_text_file1, $temp2);

			{
				my $file2 = getcwd () .'/out_xml/'.good_count ($match_id).'.xml';
				my $write_text_file_mode_rewrite = write_text_file_mode_rewrite -> new ($file2);
				
				my $str = join ("\n", @$temp2);
				$write_text_file_mode_rewrite -> put_str ($str."\n");
				
				my $proc = "xml_parse_events";
				my $sport = 2;
				my $params = {
					# "_px_data" => [$c, "in"],    #text, IN - players/teams
					"_px_data" => [$str, "in"],    #text, IN - players/teams
				};
				
				
				
				my $get_instat_id_result = get_instat_id  ($match_id);
				if (scalar (@{$get_instat_id_result}) > 0) {
					foreach (@{$get_instat_id_result}) {
						my $get_instat_id_result_local = $_;
						
						# print '$get_instat_id_result_local -> {match_status} = '. $get_instat_id_result_local -> {match_status} ."\n";
		
						if (
								defined ($get_instat_id_result_local -> {instat_id}) and 
								$get_instat_id_result_local -> {instat_id} != 0 and 
								
								($get_instat_id_result_local -> {match_status} == 1 or
								$get_instat_id_result_local -> {match_status} == 6 or
								$get_instat_id_result_local -> {match_status} == 9)
						) {
							PGapi ($proc, $params, $sport);
							# sleep 30;
						}
					}
				}
				
				$write_text_file_mode_rewrite = undef;
				
				
				if (-d $read_inifile -> {copy_path1}) {
					my $file3 = $file2;
					$file3 =~ s/^.+\///;
					if (-f getcwd () .'/picture/'. $file3) {
						$file2 = getcwd () .'/picture/'. $file3;
						$file3 = $read_inifile -> {copy_path1} .'/'.$file3;
						copy ($file2, $file3) or die (print $!);
					}
				}
				
				if (-d $read_inifile -> {copy_path2}) {
					my $file3 = $file2;
					$file3 =~ s/^.+\///;
					if (-f getcwd () .'/media/'. $file3) {
						$file2 = getcwd () .'/media/'. $file3;
						$file3 = $read_inifile -> {copy_path2} .'/'.$file3;
						copy ($file2, $file3) or die (print $!);
					}
				}
				
				if (-d $read_inifile -> {copy_path3}) {
					my $file3 = $file2;
					$file3 =~ s/^.+\///;
					
					if (-f getcwd () .'/out_xml/'. $file3) {
						$file2 = getcwd () .'/out_xml/'. $file3;
						$file3 = $read_inifile -> {copy_path3} .'/'.$file3;
						copy ($file2, $file3) or die (print $!);
					}
				}
				
				
				
				#############
				# тут после всех загрузок нужно окончательно такого запросить, чтобы внести матч в агрегатор
				# и больше его не запрашивать
				# КАКОЙ ТО ДОПОЛЬНИТЕЛЬНЫЙ СУПЕР ЗАПРОС НА НАШЕ АПИ, чтобы удостовериться, что по матчу все ОК! и его можно запомнить!
						
				my $md5 = MD5 -> new ();
				my $hash = $md5 -> hexhash ($temp1 -> [0]);
					$md5 = undef;
				
				my $insert = {};
				$insert -> {hash} = $hash;
				$insert -> {url} = $temp1 -> [0];
				$insert -> {match_id} = $temp1 -> [0];
				$insert -> {time} = time();
				
				my $work_mysql_agregator_result = $work_mysql_agregator2 -> select ($insert); 
				if (scalar (@$work_mysql_agregator_result) > 0) {
				
				} else {
				
					my $str = join ("\t", @$temp1);
					# push (@read_text_file1, $str);
					$file2 {$temp1 -> [0]} = $str;
					
					
					# Работаем с агрегтором, запоминаем матч, чтобы повторно не работать с ним и не качать по нему видео.
					# $work_mysql_agregator2 -> insert ($insert);
					
				}
			}
		}
	}
}
$read_text_file2 = undef;

# #создаем файл, только когда что то есть в массиве.
# if (scalar (keys(%file2)) > 0) {
	# my $write_text_file_mode_rewrite = write_text_file_mode_rewrite -> new ($file4);
	# foreach (keys (%file2)) {
		
		# my $temp2 = [];
		# push (@$temp2, join ("\t", @{$file2{$_}}));
		
		# #это игроки
		# if (exists ($file1 {$file2{$_} -> [0]})) {
			
			# my @array1 = ();
			
			# foreach (@{$file1 {$file2{$_} -> [0]}}) {
				# my @array2 = ();
				
				# my $str = undef;
				
				# $str = '<player_id>'.$_  -> [0].'</player_id>';
				# push (@array2, $str);
				
				# $str = '<first_name>'.$_  -> [1].'</first_name>';
				# push (@array2, $str);
				
				# $str = '<last_name>'.$_  -> [2].'</last_name>';
				# push (@array2, $str);
				
				# $str = '<team_id>'.$_  -> [3].'</team_id>';
				# push (@array2, $str);
				
				# $str = '<match_date>'.$_  -> [4].'</match_date>';
				# push (@array2, $str);
				
				# $str = '<league>'.$_  -> [5].'</league>';
				# push (@array2, $str);
				
				# $str = '<gender>'.$_  -> [6].'</gender>';
				# push (@array2, $str);
				
				# if (scalar (@array2) > 0) {
					# my $str = join ('', @array2);
					# push (@array1, $str);
				# }
				
			# }
			
			# if (scalar (@array1) > 0) {
				# my $str = join ('||', @array1);
				# push (@$temp2, $str);
			# }
		# }
		
		# #Это события
		# if (exists ($file3 {$file2{$_} -> [0]})) {
			# my @array1 = ();
			
			# foreach (@{$file3 {$file2{$_} -> [0]}}) {
				# my @array2 = ();
				
				# my $str = undef;
				
				# $str = '<gameClock>'.$_  -> [14].'</gameClock>';
				# push (@array2, $str);

				# $str = '<description>'.$_  -> [15].'</description>';
				# push (@array2, $str);
				
				# if (scalar (@array2) > 0) {
					# my $str = join ('', @array2);
					# push (@array1, $str);
				# }
				
			# }
			
			# if (scalar (@array1) > 0) {
				# my $str = join ('||', @array1);
				# push (@$temp2, $str);
			
			# }
		# }
		
		
		
		
		# $write_text_file_mode_rewrite -> put_str (join ("\t", @$temp2)."\n");
		
	# }
	
	# $write_text_file_mode_rewrite = undef;
# }
	


sub entities_decode {
	use HTML::Entities;
	my $str = shift;
	#перед отдачей модулю нужно сделать decode с любой кодировки
	$str = decode ('cp1251', $str);
	$str = decode_entities ($str);
	$str = encode ('cp1251', $str);
	return $str;
}

sub get_file_type_2 {
	my $file = shift;
	my %file = ();
	open (FILE, $file) or die;
	while (<FILE>) {
		chomp;
		$_ = encode ('cp1251', decode ('utf8', $_));
		if ($_ =~ /;/) {
			my $str = [];
			@$str = split (";",$_); 
			if (scalar (@$str) == 2) {
				$file{$str -> [1]} = $str -> [0];
			}
		}
	}
	return %file;
}


sub get_file_type_3 {
	my $file = shift;
	my %file = ();
	open (FILE, $file) or die;
	while (<FILE>) {
		chomp;
		$_ = encode ('cp1251', decode ('utf8', $_));
		if ($_ =~ /;/) {
			my $str = [];
			@$str = split (";",$_); 
			if (scalar (@$str) == 3) {

				$str->[2] =~ s/\"//g; 
				$str->[2] = lc ($str->[2]); 
				# print $str->[2] ."\n";
				# print $str->[0] ."\n";				
				$file{$str -> [2]} = $str -> [0];
			}
		}
	}
	return %file;
}


sub post {
	my $postdata = shift;
	
	
	my $key_import2 = '22812357092873478234729374';
        my $url = 'http://data.instatfootball.tv/api/import2?key='.$key_import2.'&method=UpdateBasketballSynergyMatches';	
	# my $postdata = 'firstsec=1&email=is.fin.dept%40gmail.com&pwd=basket55&women=0&B1=Login';

	push (@{ $lwp->requests_redirectable }, 'POST');
	my $req = HTTP::Request -> new (
	'POST' => $url,
		[
			# 'User-Agent' => 'Mozilla/5.0 (Windows NT 5.1; rv:11.0) Gecko/20100101 Firefox/11.0',
			# 'Accept-Language' => 'ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
			# 'Referer' => 'http://basketball.eurobasket.com/player/Andrey-Vorontsevich/Russia/CSKA-Moscow/71366',
			# 'Content-Type' => 'application/json',
			
			'Accept' => '*/*',
			'Content-Type' => 'multipart/form-data; boundary=----------------------------4b5789fa8d3f',
			
		]
	);
	
	
	my $str = 
'------------------------------4b5789fa8d3f
Content-Disposition: form-data; name="json"

'.$postdata.'
------------------------------4b5789fa8d3f--';
	

	$req -> content ($str);
	
	my $file = getcwd () .'/txt/matches.html';
	my $res = $lwp -> request ($req, $file); 
	print $res -> code ."\t" . $url ."\n";
	
	# my $sleep = Random ($sleep2, $sleep3); 
	# sleep $sleep;		
}

sub get_date { 
	use  Date::Calc qw (Time_to_Date Date_to_Time);
	my ($year,$month,$day, $hour,$min,$sec) = Time_to_Date(time());
	my $str = $year .'-'.$month.'-'.$day .' '.$hour.':'.$min.':'.$sec;
	return $str;
}


sub get_date_to_time { 
	my $str = shift;
	use  Date::Calc qw (Time_to_Date Date_to_Time);
	
	my $time = 1;
	my @temp = split (/\s+/, $str);
	if (scalar (@temp) == 2) {
		foreach (@temp) {
			my $clear_str = clear_str -> new ($_);
			$_ = $clear_str -> delete_4 ();
			$clear_str = undef;		
		}
		
		my @date = split ('-', $temp[0]);
		if (scalar (@date) > 0) {
			foreach (@date) {
				my $clear_str = clear_str -> new ($_);
				$_ = $clear_str -> delete_4 ();
				$clear_str = undef;		
			}
		}
		
		my @time = split (':', $temp[1]);
		if (scalar (@date) > 0) {
			foreach (@date) {
				my $clear_str = clear_str -> new ($_);
				$_ = $clear_str -> delete_4 ();
				$clear_str = undef;		
			}
		}
		
		# $time = Date_to_Time($year,$month,$day, $hour,$min,$sec)
		$time = Date_to_Time($date[0],$date[1],$date[2], $time[0],$time[1],$time[2]);
	}
	
	return $time;
}

sub good_count {
	my $str = shift;
	while (length ($str) < 5) {
		$str = '0'.$str;
	}
	return $str;
}

sub entities_encode {
	use HTML::Entities;
	my $str = shift;
	$str = encode_entities ($str, '<>"\'&');
	return $str;
}


sub get_instat_id {
	my $match_id = shift;
	
	my $response_code = 0;
	my $json_decode = '[{}]';
	my $content_ok = 'nok';
	
	do {
	
		# https://data.instatfootball.tv/api/Getinstatid?key=22812357092873478234729374&method=UpdateBasketballSynergyMatches&id=414219,414525,414357
		my $url = 'https://data.instatfootball.tv/api/Getinstatid?key=22812357092873478234729374&method=UpdateBasketballSynergyMatches&id='.$match_id;
		my $method = 'GET';
		my $useragent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0';
		my $request = HTTP::Request -> new (
			$method => $url,
			[
				'User-Agent' => 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0',
				'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
				'Accept-Language' => 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
				'Accept-Charset' => 'windows-1251,utf-8;q=0.7,*;q=0.7',
			]
		);

		my $file = getcwd () .'/txt/get_1.html';
		# my $response = $lwp -> request ($request, $file);
		my $response = $lwp -> request ($request);
		print $response -> code  ."\t". $url ."\n";
		print $response -> content ."\n";
		
		my $content = $response -> content;
		$content =~ s/\n+//g;
		$content =~ s/\r+//g;
		$content =~ s/\t+//g;
		
		if ($content =~ /^\[\{"id":"\d+",/) {
			$content_ok = 'ok';
			$json_decode = decode_json ($response -> content);	
		}
		
		#задержкв
		#sleep 1;
		
	} while ($response_code != 200 and $content_ok ne 'ok');
	
	return $json_decode;
}



sub PGapi {
	
	my $proc = shift;
	my $params = shift;
	my $sport = shift;
	
	
	my $url = 'http://service.instatfootball.com/ws.php';
	
    my $databases = {
        1 => 'football',
        2 => 'basketball',
        3 => 'hockey',
    };
    
	my $request_data = {
        'server' => 'instatfootball.com',
        'base' => $databases -> {$sport},
        'login' => 'views_football',
        'pass' => 'RcGBBwVqMn7K9Fdz',
        'proc' => $proc,
        'params' => $params,
    };
	
	my $json_str = encode_json ($request_data);
	my $postdata = $json_str;
	# my $res = $lwp-> post ($url, $postdata, 'Content-Type' => 'application/json');	
	
	push (@{ $lwp->requests_redirectable }, 'POST');
	my $req = HTTP::Request -> new (
	'POST' => $url,
		[
			# 'Host' => 'www.synergysportstech.com',
			# 'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; .NET4.0C; .NET4.0E; rv:11.0) like Gecko',
			# 'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			# 'Accept-Language' => 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
			# 'Referer' => 'https://www.synergysportstech.com/synergy/',
			# 'Content-Type' => 'application/x-www-form-urlencoded',
			
			'Content-Type' => 'application/json',
		]
	);
	
	$req -> content ($postdata);
	my $file = getcwd () .'/txt/PGapi.html';
	# my $res = $lwp -> request ($req, $file); 
	my $res = $lwp -> request ($req); 
	
	
	print $res -> code ."\t".$url."\n";
	print $res -> content ."\n";
	
	
	
	# my $content = get_content_from_file ($file);
	# my $decode_json = decode_json ($content);
	# $insert -> {access_token} = $decode_json -> {access_token};
	# print '$insert -> {access_token} = ' . $insert -> {access_token} ."\n";
	
	# my $sleep = Random ($sleep2, $sleep3); 
	# sleep $sleep;	
	
	return 1;
}

