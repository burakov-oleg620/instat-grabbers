package work_mysql_agregator;
use strict;
use warnings;
use MD5;
use url_to_file;
use work_mysql;
use Encode qw (encode decode);
use Data::Dumper;

sub new {
	my $class = shift;
	
	my $mysql_dbdriver = shift; 
	my $mysql_host = shift; 
	my $mysql_port = shift; 
	my $mysql_user = shift;  
	my $mysql_user_password = shift; 
	my $mysql_base = shift; 
	my $mysql_table = shift;
	
	my $work_mysql = work_mysql -> new (
		$mysql_dbdriver,
		$mysql_host,
		$mysql_port,
		$mysql_user,
		$mysql_user_password,
		$mysql_base
	); 	

	my $sql = 'SET NAMES UTF8';
	$work_mysql -> run_query ($sql) or die (print $!);
	
	my $self = {};
	$self -> {work_mysql} = $work_mysql;
	$self -> {table} = $mysql_table;

	return bless $self; 
}

sub create {
	my $self = shift;
	
	my $sql  = '
	create table if not exists '. $self -> {table}.' (
		`hash` char (32) PRIMARY KEY,
		`url` text, 
		`time` int(11)
	) ENGINE=InnoDB  DEFAULT CHARSET=utf8;'; 
	$self -> {work_mysql} -> run_query ($sql) or die (print $!);
}


sub drop  {
	my $self = shift;
	my $sql = 'drop table if exists '.$self->{table}; 		
	$self -> {work_mysql} -> run_query ($sql) or die (print $!);
}

sub insert {
	my $self = shift;
	my $table = $self -> {table};
	my $insert = shift;
	
	my $sql = 'insert into '.$table.' (
		`hash`, 
		`url`,
		`time`
	)	
	value (
		"'.quotemeta ($insert -> {hash}).'",
		"'.quotemeta ($insert -> {url}).'",
		"'.quotemeta ($insert -> {time}).'"
	)'; 		
	
	$self -> {work_mysql} -> run_query ($sql) or die (print $!);
	return $sql;
}

sub select {
	my $self = shift;
	my $insert = shift;
	
	my $sql = 'select * from '.$self->{table}.' where `hash` = "'.$insert -> {hash}.'"'; 		
	$self -> {work_mysql} -> run_query ($sql);
	
	my $return = [];
	my @row = $self -> {work_mysql} -> get_row_hashref ();
	if (scalar (@row) > 0) {
		foreach (@row) {
			push (@$return, $_);
		}
	}
	return $return; 
}

sub delete {
	my $self = shift;
	my $insert = shift;
	
	my $sql = 'delete from '.$self->{table}.' where `hash` = "'.$insert -> {hash}.'"'; 		
	$self -> {work_mysql} -> run_query ($sql);
	return 1; 
}



sub select_all {
	my $self = shift;
	my $insert = shift;
	
	my $sql = 'select * from '.$self->{table}; 		
	$self -> {work_mysql} -> run_query ($sql);
	
	my $return = [];
	my @row = $self -> {work_mysql} -> get_row_hashref ();
	if (scalar (@row) > 0) {
		foreach (@row) {
			push (@$return, $_);
		}
	}
	return $return; 
}

sub  clear  {
	my $self = shift;
	my $clear_time = shift;
	
	my $time = time () - $clear_time * 24*3600;
	my $sql = 'select * from '.$self-> {table}.' where `time` BETWEEN "0" AND '.$time;
	$self -> {work_mysql} -> run_query ($sql) or die (print $!);
	
	my @row = $self -> {work_mysql} -> get_row_hashref ();
	if (scalar (@row) > 0) {
		foreach (@row) {
			my$sql = 'delete from '.$self->{table}.' where `hash` = "'.$_->{hash}.'"';
			$self -> {work_mysql} -> run_query ($sql) or die (print $!);
		}
	}
	return 1;

}		

1;
