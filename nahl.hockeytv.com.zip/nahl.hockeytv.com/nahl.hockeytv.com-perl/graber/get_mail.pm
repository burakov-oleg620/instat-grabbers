package get_mail;
use strict;
use warnings;
use MD5;
use url_to_file;
use work_mysql;
use Encode qw (encode decode);
use Data::Dumper;
use Cwd;

sub new {
	my $class = shift;
	my $content = shift;
	my $lwp = shift;
	my $read_inifile = shift;
	my $self = {};
	$self -> {content} = $content;
	$self -> {lwp} = $lwp;
	$self -> {read_inifile} = $read_inifile;
	return bless $self; 
}

sub do {
	my $self = shift;
	my $content2 = $self -> {content};
	my $lwp = $self -> {lwp};
	my $read_inifile = $self -> {read_inifile};
	my $host = $read_inifile -> {host};
	my $return  = {};
	
	my $pattern1 = '(<div id="get-mail".+?</div>)';
	my $work_for_content = work_for_content -> new ($content2); 
	my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
	if (defined $work_for_content_result -> [0]) {
		foreach (@$work_for_content_result) {		
			my $clear_str = clear_str -> new ($_);
			$_ = $clear_str -> delete_4 ();
			$clear_str = undef;	
			
			my $pattern1 = '(<input name="advid".+?>)';
			my $work_for_content = work_for_content -> new ($_); 
			my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
			if (defined $work_for_content_result -> [0]) {
				foreach (@$work_for_content_result) {		
					my $clear_str = clear_str -> new ($_);
					$_ = $clear_str -> delete_4 ();
					$clear_str = undef;							
			
					#оставляем признак наличия блока майл
					$return -> {advid} = $_;
					
					my $value = '-';  my $hash = '-';	my $refid = '-'; 	my $file = '-';
					
					my $pattern1 = 'value="(.+?)"';
					my $work_for_content = work_for_content -> new ($_); 
					my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
					if (defined $work_for_content_result -> [0]) {
						foreach (@$work_for_content_result) {		
							my $clear_str = clear_str -> new ($_);
							$_ = $clear_str -> delete_4 ();
							$clear_str = undef;
							$value = $_;
							
							# http://reklama.vesti.lv/services/send_email-ajax.php?init=true&advid=9676184
							my $url = 'http://reklama.vesti.lv/services/send_email-ajax.php?init=true&advid='.$_ ;
							my $useragent = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.2.16) Gecko/20110319 Firefox/3.6.16';										
							my $method = 'GET';
							my $referer = $host;
							
								
							my $req = HTTP::Request -> new (
								$method => $url,
								[	
									'User-Agent' => $useragent,
									'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
									'Accept-Language' => 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
									'Accept-Charset' => 'windows-1251,utf-8;q=0.7,*;q=0.7',
									'Referer' => $referer, 
								]
							);

							# $file = getcwd () .'/media/'.$_ .'.html';
							# my $response = $lwp -> request ($req, $file);
							my $response = $lwp -> request ($req);
							print $response -> code ."\t". $url. "\n";
							
							#задержка
							my $sleep = _Random ($read_inifile -> {sleep2}, $read_inifile -> {sleep3}); 
							sleep $sleep;	
							
							
							if ($response -> code == 200) {
								
								my $content1 = $response -> content;
								my $clear_str = clear_str -> new ($content1);
								$content1 = $clear_str -> delete_4 ();
								$clear_str = undef;																	
								
								#hash
								my $pattern1 = '"hash":"(.+?)"';
								my $work_for_content = work_for_content -> new ($content1); 
								my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
								if (defined $work_for_content_result -> [0]) {
									foreach (@$work_for_content_result) {		
										my $clear_str = clear_str -> new ($_);
										$_ = $clear_str -> delete_4 ();
										$clear_str = undef;	
										$hash  = $_;
									}
								}
								
								#refid
								$pattern1 = '"refid":"(.+?)"';
								$work_for_content = work_for_content -> new ($content1); 
								$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
								if (defined $work_for_content_result -> [0]) {
									foreach (@$work_for_content_result) {		
										my $clear_str = clear_str -> new ($_);
										$_ = $clear_str -> delete_4 ();
										$clear_str = undef;	
										$refid = $_;
									}
								}											
								
								#img
								$pattern1 = '"img":"(.+?)"';
								$work_for_content = work_for_content -> new ($content1); 
								$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
								if (defined $work_for_content_result -> [0]) {
									foreach (@$work_for_content_result) {		
										my $clear_str = clear_str -> new ($_);
										$_ = $clear_str -> delete_4 ();
										$clear_str = undef;	
										$_ =~ s/\\//g;
										my $url = $_;
										
										my $req = HTTP::Request -> new (
											$method => $url,
											[	
												'User-Agent' => $useragent,
												'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
												'Accept-Language' => 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
												'Accept-Charset' => 'windows-1251,utf-8;q=0.7,*;q=0.7',
												'Referer' => $referer, 
											]
										);
										
										
										my $md5 = MD5 -> new ();
										my $hash = $md5 -> hexhash ($url);
										$md5 = undef;
										
										$file = getcwd () .'/picture/'.$hash .'.png';
										my $response = $lwp -> request ($req, $file);
										print $response -> code ."\t". $url. "\n";													

										
										#задержка
										my $sleep = _Random ($read_inifile -> {sleep2}, $read_inifile -> {sleep3}); 
										sleep $sleep;	

									}
								}
							}
							
							
							if (-f $file) {
								$return -> {file} = $file;
								
								#Антигейт.
								use WebService::Antigate;
								my $recognizer = WebService::Antigate->new(key => $read_inifile -> {antigate_key});
								my $captcha = $recognizer->upload_and_recognize (file => $file);
								# or die $recognizer->errstr;
								$return -> {captcha} = $captcha;
								
								if (defined $captcha) { 
								
									print "Recognized captcha is: ", $captcha, "\n";
									# http://reklama.vesti.lv/services/send_email-ajax.php?advid=9676184&hash=a6fc95f55b88005349da32578283f2d7&refid=9c7ce68909cbafd8729fa2b1633c4215&botcheck=f5b5
									my $url = 'http://reklama.vesti.lv/services/send_email-ajax.php?advid='.$value.'&hash='.$hash.'&refid='.$refid.'&botcheck='.$captcha;
									my $req = HTTP::Request -> new (
										$method => $url,
										[	
											'User-Agent' => $useragent,
											'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
											'Accept-Language' => 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
											'Accept-Charset' => 'windows-1251,utf-8;q=0.7,*;q=0.7',
											'X-Requested-With' => 'XMLHttpRequest',
											# 'Referer' => $referer, 
										]
									);
									
									
									my $md5 = MD5 -> new ();
									my $hash = $md5 -> hexhash ($url);
									$md5 = undef;
									
									# $file = getcwd () .'/media/result_'.$value .'.html';
									# my $response = $lwp -> request ($req, $file);
									my $response = $lwp -> request ($req);
									print $response -> code ."\t". $url. "\n";													
									
									if ($response -> code == 200) {
									
										my $content1 = $response -> content;
										my $clear_str = clear_str -> new ($content1);
										$content1 = $clear_str -> delete_4 ();
										$clear_str = undef;																	
									
										$content1 =~ s/\"\"/" "/g;
										$pattern1 = '"email":"(.+?)"';
										$work_for_content = work_for_content -> new ($content1); 
										$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
										if (defined $work_for_content_result -> [0]) {
											foreach (@$work_for_content_result) {		
												my $clear_str = clear_str -> new ($_);
												$_ = $clear_str -> delete_4 ();
												$clear_str = undef;											
												$_ =~ s/\s//g;
												$_ =~ s/^\s+$//;
												if ($_ eq '') {$_ = '-';}
												
												$return -> {mail} = $_;
												# print '$return -> {mail} = ' . $return -> {mail} ."\n";
											}
										}
									}
									
									#задержка
									my $sleep = _Random ($read_inifile -> {sleep2}, $read_inifile -> {sleep3}); 
									sleep $sleep;	

								} 
							}
						}
					}
				}
			}
		}
	}
	
	return $return;
}

sub do2 {
	my $self = shift;
	my $content2 = $self -> {content};
	my $lwp = $self -> {lwp};
	my $read_inifile = $self -> {read_inifile};
	my $return  = {};
	
		
	my $pattern1 = '"mailto:(.+?)"';
	my $work_for_content = work_for_content -> new ($content2); 
	my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
	if (defined $work_for_content_result -> [0]) {
		foreach (@$work_for_content_result) {		
			my $clear_str = clear_str -> new ($_);
			$_ = $clear_str -> delete_4 ();
			$clear_str = undef;
			$return -> {mail_to} = $_;
		}
	}
	return $return;
}


sub _Random {
	my $from = shift;
	my $to = shift;
	my $_Random = $from + rand(($to - $from));
	return $_Random;
}

1;
