#!/usr/bin/env perl
use strict;
use warnings;
use locale;
use dir_scan_recurce;
use read_text_file; 
use write_text_file_mode_rewrite; 
use Encode qw (encode decode);
use clear_str;
use read_inifile;

use work_mysql_graber;
use work_for_content;
use write_to_txt1;
use write_to_txt2;

use Date::Calc;
use HTML::TreeBuilder::XPath;
use MD5;

use LWP::UserAgent;
use HTTP::Request;
use HTTP::Response;
use HTTP::Cookies;
use URI::Escape;
use HTML::TreeBuilder::XPath;
use LWP::Protocol::http;
use Data::Dumper;
use JSON::XS;

sub get_base_path {
	use Cwd; 
	my $cwd = getcwd ();
	return $cwd;
}


my $read_inifile = read_inifile -> new ('graber.ini'); 
my $host = $read_inifile -> get ('host');	

#����� ��������� �� ��� �����
my $mysql_dbdriver = $read_inifile -> get ('mysql_dbdriver');
my $mysql_host = $read_inifile -> get ('mysql_host');
my $mysql_port = $read_inifile -> get ('mysql_port');
my $mysql_user = $read_inifile -> get ('mysql_user');
my $mysql_user_password = $read_inifile -> get ('mysql_user_password');
if ($mysql_user_password eq ' ') {$mysql_user_password = '';}
my $mysql_base = $read_inifile -> get ('mysql_base');
my $mysql_table = $read_inifile -> get ('mysql_table');


my $lwp = undef;
$lwp = LWP::UserAgent -> new ();
$lwp -> cookie_jar (HTTP::Cookies->new ());
$lwp -> agent ('Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.2.16) Gecko/20110319 Firefox/3.6.16');
$lwp -> timeout (60);
# $lwp -> proxy ('http', 'http://127.0.0.1:8080');


#������� ���������� �� mysql ����������
my $work_mysql_graber = work_mysql_graber -> new (
	$mysql_dbdriver,
	$mysql_host,
	$mysql_port,
	$mysql_user,
	$mysql_user_password,
	$mysql_base,
	$mysql_table
); 

# my 	$work_mysql = work_mysql -> new (
		# $mysql_dbdriver,
		# $mysql_host,
		# $mysql_port,
		# $mysql_user,
		# $mysql_user_password,
		# $mysql_base
	# ); 	
	
# my $sql = 'set names utf8';
# $work_mysql -> run_query ($sql);

	

my $workdir1 = get_base_path.'/media'; 
my $workdir2 = get_base_path.'/txt'; 

my $write_text_file_mode_rewrite1 = undef;
my $write_file1 = $workdir2.'/write_text_file_mode_rewrite51.xls'; 
$write_text_file_mode_rewrite1 = write_text_file_mode_rewrite -> new ($write_file1);

# my $file1 = $workdir2.'/write_text_file_mode_rewrite2.xls'; 

my $count = 0 ;

# my %file1 = ();
# tie %file1, 'Tie::IxHash';
# {
	# my $read_text_file2 = read_text_file -> new ($file2); 
	# while (my $str1 = $read_text_file2 -> get_str ()) {
		# print ++$count."\n";
		
		# if ($str1 =~ /\t/) {
			# my $temp1 = []; my $pattern1 = "\t"; @$temp1 = split ($pattern1, $str1); 
			
			# # print '*' . scalar (@$temp1) ."\n";
			# if (scalar (@$temp1) > 1) {
				
				# #����������� ��� ����, ����� ������ ������ ������
				# foreach (@$temp1) {
					# my $clear_str = clear_str -> new ($_);
					# $_ = $clear_str -> delete_4 ();
					# $clear_str = undef;											
				# }
				
				# $file1 {$temp1 -> [0]} = 1;
			# }			
		# }
	# }
# }

my $iGameClock = '';
my $dir_scan_recurce = dir_scan_recurce -> new ($workdir1);
while (my $file1 = $dir_scan_recurce -> get_file ()) {
	my $pattern = 'xml$';
	if ($file1 =~ /$pattern/) {
	
		print ++$count."\n";
		
		my @file1 = ();	
		my $read_text_file = read_text_file -> new ($file1); 
		while (my $str1 = $read_text_file -> get_str ()) {
			my $clear_str = clear_str -> new ($str1); 
			$str1 = $clear_str -> delete_4 ();
			$clear_str = undef;			
			push (@file1, $str1); 
		}
		$read_text_file = undef;
		
		my $content1 = join (' ', @file1); 
		# $content1 = entities_decode1 ($content1);
		# $content1 = utf8_to_win1251 ($content1);
		
		# $content1 =~ s/\'/"/g;

		# $content1 =~ s/>\s+</> </g;
		# $content1 =~ s/></> </g;
		# $content1 =~ s/\?//g;
		
		# my $tree = HTML::TreeBuilder::XPath -> new ();
		# $tree -> parse_content ($content1);
		# my $content2 = $tree -> findnodes_as_string ('//div[@class="VacancyDetails_section"]'); 
		# my $content3 = $tree -> findnodes_as_string ('//div[@class="VacancySendResumeContacts_wr"]'); 
		# # my $content4 = $tree -> findnodes_as_string ('//div[@data-qa="resume-block-additional-education"]'); 
		# # my $content5 = $tree -> findnodes_as_string ('//div[@data-qa="resume-block-languages"]'); 
		# # my $content6 = $tree -> findnodes_as_string ('//div[@class="resume-block-container"]'); 
		
		# $tree->delete;
		# $tree = undef;
		
		# my @content2 = split ("\n", $content2);
		# if (scalar (@content2) > 0) {
			# foreach (@content2) {
				# my $clear_str = clear_str -> new ($_); 
				# $_ = $clear_str -> delete_4 ();
				# $clear_str = undef;			
				
				
		
		
		# my $url = undef;
		# my $referer = undef;
		# my $str_for_content = undef;
		# {
			# #URL
			# my $file2 = $file1;
			# $file2 =~ s/^.+\///;
			# my $sql = 'select * from '.$mysql_table.' where `file` = "'.$file2.'"';
			# $work_mysql	-> run_query ($sql); 
			# my @row = $work_mysql -> get_row ();
			# if (scalar (@row) > 0) {
				# foreach (@row) {
					# $url =  $_ -> [3];
					# $referer =  $_ -> [4];
					# $str_for_content = $_ -> [8];
					# $write_to_txt1 -> put ($url);
				# }
			# } else {
				# $write_to_txt1 -> put ('-');
			# }
			# # $write_to_txt1 -> put ($file2);
		# }		
		my $event_count = 0;
		my $pattern1 = '(<tblPossessionSegment>.+?</tblPossessionSegment>)';
		my $work_for_content = work_for_content -> new ($content1); 
		my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
		if (defined $work_for_content_result -> [0]) {
			foreach (@$work_for_content_result) {		
				my $clear_str = clear_str -> new ($_);
				$_ = $clear_str -> delete_4 ();
				$clear_str = undef;		
				$event_count++;
				
				my $write_to_txt1 = write_to_txt1 -> new ();			

				#gameid
				my $id = '';
				my @array = ();
				my $pattern1 = '(<iSegmentEventID>\d+</iSegmentEventID>)';
				my $work_for_content = work_for_content -> new ($_); 
				my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
				if (defined $work_for_content_result -> [0]) {
					foreach (@$work_for_content_result) {		
						my $clear_str = clear_str -> new ($_);
						$_ = $clear_str -> delete_3_s ();
						$_ = $clear_str -> delete_4 ();
						$clear_str = undef;		
						$_ = entities_decode ($_);	
						
						$_ =~ s/^\s+//;
						$_ =~ s/\s+$//;
						$_ =~ s/^\s+$//;
								
						if ($_ ne '') {
							push (@array , $_);
						}
					}
				} 
				
				if (scalar (@array) > 0) {
					my $str = join ('||', @array);
					$write_to_txt1 -> put ($array[0]);
					$id = $array [0];
				} else {
					$write_to_txt1 -> put ('-');
				}
				
				
				
				 # <iEndTime>
				my $iEndTime = undef;
				my $iStartTime = undef;
				
				@array = ();
				$pattern1 = '(<iEndTime>.+?</iEndTime>)';
				$work_for_content = work_for_content -> new ($_); 
				$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
				if (defined $work_for_content_result -> [0]) {
					foreach (@$work_for_content_result) {		
						my $clear_str = clear_str -> new ($_);
						$_ = $clear_str -> delete_3_s ();
						$_ = $clear_str -> delete_4 ();
						$clear_str = undef;		
						$_ = entities_decode ($_);	
						
						$_ =~ s/^\s+//;
						$_ =~ s/\s+$//;
						$_ =~ s/^\s+$//;
						$iEndTime = $_;
								
						# if ($_ ne '') {
							# push (@array , $_);
						# }
					}
				} 
				
				$pattern1 = '(<iStartTime>.+?</iStartTime>)';
				$work_for_content = work_for_content -> new ($_); 
				$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
				if (defined $work_for_content_result -> [0]) {
					foreach (@$work_for_content_result) {		
						my $clear_str = clear_str -> new ($_);
						$_ = $clear_str -> delete_3_s ();
						$_ = $clear_str -> delete_4 ();
						$clear_str = undef;		
						$_ = entities_decode ($_);	
						
						$_ =~ s/^\s+//;
						$_ =~ s/\s+$//;
						$_ =~ s/^\s+$//;
						$iStartTime = $_;
								
						# if ($_ ne '') {
							# push (@array , $_);
						# }
					}
				} 
				
				if (defined ($iEndTime) and defined ($iStartTime)) {
					push (@array, ($iEndTime - $iStartTime)/1000);
				}
				
				if (scalar (@array) > 0) {
					my $str = join ('||', @array);
					$write_to_txt1 -> put ($array[0]);
				} else {
					$write_to_txt1 -> put ('-');
				}
				 
				
				

				 
					
				my $str = $write_to_txt1 -> get ();
				$write_text_file_mode_rewrite1 -> put_str ($str."\n");														
				$write_to_txt1 = undef;								

					
			}
		} 
		
	}						
	
} #������ ����� �� ��������
$write_text_file_mode_rewrite1 = undef;


sub utf8_to_win1251 {
	use Encode qw (encode decode); 
	my $str = shift;
	$str = encode ('cp1251', decode ('utf8', $str)); 
	return $str;
}

sub entities_decode {
	use HTML::Entities;
	my $str = shift;
	#����� ������� ������ ����� ������� decode � ����� ���������
	$str = decode ('cp1251', $str);
	$str = decode_entities ($str);
	$str = encode ('cp1251', $str);
	return $str;
}

sub entities_decode1 {
	use HTML::Entities;
	my $str = shift;
	#����� ������� ������ ����� ������� decode � ����� ���������
	$str = decode ('utf8', $str);
	$str = decode_entities ($str);
	$str = encode ('utf8', $str);
	return $str;
}

sub get_date {
	my $time = shift;
	use Date::Calc qw (Time_to_Date Date_to_Time);
	my ($year,$month,$day, $hour,$min,$sec) = Time_to_Date ($time);
	# my $str = $year .'.'.$month .'.'. $day;
	# my $str = $year .'-'.$month ;
	
	# my @date = split ('\.', $str);
	my @date = ();
	push (@date, $year);
	push (@date, $month);
	push (@date, $day);
	
	if (scalar (@date) > 0) {
		foreach (@date) {
			while (length ($_) < 2) {
				$_ = '0'.$_;
			}
		}
	}
	my $str = $date[0] .'-'.$date[1];
	return $str;
}	

sub json_str {
	my $str = shift;
	$str =~ s/\n+/ /g;
	$str =~ s/\r+/ /g;
	$str = encode ('cp1251', $str);
	return $str;
}
