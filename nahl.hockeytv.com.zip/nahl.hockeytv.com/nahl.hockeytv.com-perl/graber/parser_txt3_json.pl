#!/usr/bin/env perl
use strict;
use warnings;
use locale;
use dir_scan_recurce;
use read_text_file; 
use write_text_file_mode_rewrite; 
use clear_str;
use delete_duplicate_from_array; 
use read_inifile;
use url_to_file;
use Encode qw (encode decode);
use Tie::IxHash;
use work_for_content;
use File::Path;
use File::Copy;
use Cwd;
use work_mysql_agregator;
use Data::Dumper;
use LWP::UserAgent;
use HTTP::Request;
use HTTP::Response;
use HTTP::Cookies;
use URI::Escape;
use HTML::TreeBuilder::XPath;
use URI::URL;
use JSON::XS;
use HTTP::Request::Common qw{ POST };

sub get_base_path {
	use Cwd; 
	my $cwd = getcwd ();
	return $cwd;
}

#Читаю установки из ини файла
my $read_inifile = read_inifile -> new ('graber.ini'); 
my $mysql_dbdriver = $read_inifile -> get ('mysql_dbdriver');
my $mysql_host = $read_inifile -> get ('mysql_host');
my $mysql_port = $read_inifile -> get ('mysql_port');
my $mysql_user = $read_inifile -> get ('mysql_user');
my $mysql_user_password = $read_inifile -> get ('mysql_user_password');
if ($mysql_user_password eq ' ') {$mysql_user_password = '';}
my $mysql_base = $read_inifile -> get ('mysql_base');
my $mysql_table = $read_inifile -> get ('mysql_table');

my $threads_all = $read_inifile -> get ('threads_all'); 
my $sleep1 = $read_inifile -> get ('sleep1'); 
my $sleep2 = $read_inifile -> get ('sleep2'); 
my $sleep3 = $read_inifile -> get ('sleep3'); 

my $host = $read_inifile -> get ('host');	
my $set_proxy = $read_inifile -> get ('set_proxy');
my $count_all = $read_inifile -> get ('count_all');	
my $workdir1 = get_base_path.'/txt'; 
my $workdir2 = get_base_path.'/picture'; 
my $workdir3 = get_base_path.'/media'; 

my $file1 = $workdir1.'/write_text_file_mode_rewrite33.xls'; 
my $file2 = $workdir1.'/write_text_file_mode_rewrite333.xls'; 
my $file3 = $workdir1.'/write_text_file_mode_rewrite33s.xls'; 
my $file4 = $workdir1.'/write_text_file_mode_rewrite333s.xls'; 



# #Создаем дескриптор на mysql соединение
# my $work_mysql_agregator = work_mysql_agregator -> new (
	# $mysql_dbdriver,
	# $mysql_host,
	# $mysql_port,
	# $mysql_user,
	# $mysql_user_password,
	# $mysql_base,
	# $read_inifile -> {agregator}
# ); 

# # $work_mysql_agregator -> drop ();		
# $work_mysql_agregator -> create ();		

# #устанавливаем всем паблиш в 0.
# $work_mysql_agregator -> set_publish_0 ();
# $work_mysql_agregator -> clear ($read_inifile -> {clear_agregator});		


my $lwp = undef;
$lwp = LWP::UserAgent -> new ();
$lwp -> cookie_jar (HTTP::Cookies->new ());
$lwp -> agent ('Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.2.16) Gecko/20110319 Firefox/3.6.16');
$lwp -> timeout (60);
# $lwp -> proxy ('http', 'http://127.0.0.1:8080');


my $count = 0;
my @read_text_file1 = ();
my %header = (); 
tie (%header, 'Tie::IxHash'); #чтобы было по мере добавления

my %file1 = ();
tie (%file1, 'Tie::IxHash'); #чтобы было по мере добавления

my %file2 = ();
tie (%file2, 'Tie::IxHash'); #чтобы было по мере добавления


my $read_text_file1 = read_text_file -> new ($file1); 
while (my $str1 = $read_text_file1 -> get_str ()) {
	# print ++$count."\n";
	
	if ($str1 =~ /\t/) {
		my $temp1 = []; my $pattern1 = "\t"; @$temp1 = split ($pattern1, $str1); 
		
		# print '*'.scalar (@$temp1)."\n";
		if (scalar (@$temp1) > 1) {			
			foreach (@$temp1) {
				my $clear_str = clear_str -> new ($_); 
				$_ = $clear_str -> delete_4 ();
				$clear_str = undef;
				if ($_ eq '-') {$_ = '';}
				# $_ = encode ('utf8', decode ('cp1251', $_));
			}
			
			# my $str = join ("\t", @$temp1); 
			# push (@read_text_file1, $str);

			# my $md5 = MD5 -> new ();
			# my $hash = $md5 -> hexhash ($temp1 -> [3]);
			# $md5 = undef;

			if ($temp1 -> [0] ne 'player_id') {
				
				my $insert2 = [];
				my $insert = {};
				tie (%$insert, 'Tie::IxHash');
				
				$insert -> {id} = $temp1 -> [0]; 
				$insert -> {player_first_name}= $temp1 -> [1]; 
				$insert -> {player_last_name}= $temp1 -> [2]; 
				$insert -> {player_number}= $temp1 -> [3]; 
				$insert -> {team_id}= $temp1 -> [4]; 
				$insert -> {match_date}= $temp1 -> [5]; 
				$insert -> {league} = $temp1 -> [6]; 
				$insert -> {gender} = $temp1 -> [7]; 
				$insert -> {match_id} = $temp1 -> [8]; 

				# push (@{$insert2 -> {json}}, $insert);
				push (@{$insert2}, $insert);

				my $encode_json = encode_json ($insert2);
				post_players ($encode_json);				
				
				
				my $get_instat_id_players = get_instat_id_players ($temp1 -> [0]);
				if (scalar (@$get_instat_id_players) > 0) {
					foreach (@$get_instat_id_players) {
						if (defined ($_ -> {instat_id})) {
							push (@$temp1, $_ -> {instat_id});
						}
					}
				}
				
				# print $encode_json ."\n";
				$file1 {$temp1 -> [0]} = join ("\t", @$temp1);
			}
			
		}
	}
}
$read_text_file1 = undef;

{
	my $read_text_file1 = read_text_file -> new ($file2); 
	while (my $str1 = $read_text_file1 -> get_str ()) {
		# print ++$count."\n";
		
		if ($str1 =~ /\t/) {
			my $temp1 = []; my $pattern1 = "\t"; @$temp1 = split ($pattern1, $str1); 
			
			# print '*'.scalar (@$temp1)."\n";
			if (scalar (@$temp1) > 1) {			
				foreach (@$temp1) {
					my $clear_str = clear_str -> new ($_); 
					$_ = $clear_str -> delete_4 ();
					$clear_str = undef;
					if ($_ eq '-') {$_ = '';}
					# $_ = encode ('utf8', decode ('cp1251', $_));
				}
				
				# my $str = join ("\t", @$temp1); 
				# push (@read_text_file1, $str);

				# my $md5 = MD5 -> new ();
				# my $hash = $md5 -> hexhash ($temp1 -> [3]);
				# $md5 = undef;

				if ($temp1 -> [0] ne 'team_id') {
					
					my $insert2 = [];
					my $insert = {};
					tie (%$insert, 'Tie::IxHash');
					
					$insert -> {id} = $temp1 -> [0]; 
					$insert -> {team_name} = $temp1 -> [1]; 
					$insert -> {team_short_name} = $temp1 -> [2]; 
					$insert -> {match_date} = $temp1 -> [3]; 
					$insert -> {league} = $temp1 -> [4]; 
					$insert -> {gender} = $temp1 -> [5]; 

					
					# push (@{$insert2 -> {json}}, $insert);
					push (@{$insert2}, $insert);
					
					my $encode_json = encode_json ($insert2);
					post_teams ($encode_json);	
					
					
					my $get_instat_id_teams = get_instat_id_teams ($temp1 -> [0]);
					if (scalar (@$get_instat_id_teams) > 0) {
						foreach (@$get_instat_id_teams) {
							if (defined ($_ -> {instat_id})) {
								push (@$temp1, $_ -> {instat_id});
							}
						}
					}
					
					# print $encode_json ."\n";
					$file2 {$temp1 -> [0]} = join ("\t", @$temp1);
				}
			}
		}
	}
	$read_text_file1 = undef;

}


# my $delete_duplicate_from_array = delete_duplicate_from_array -> new (@read_text_file1);
# @read_text_file1 = $delete_duplicate_from_array -> do ();
# $delete_duplicate_from_array = undef;
# @read_text_file1 = sort (@read_text_file1);

# my $write_text_file_mode_rewrite = write_text_file_mode_rewrite -> new ($file2);
# my @headers = (
	# 'URL',
	
	# 'НАИМЕНОВАНИЕ',
	# 'КАТЕГОРИЯ',
	# 'ПРОИЗВОДИТЕЛЬ',
	# 'ЦЕНА',
	# 'КАРТИНКА',
	# 'ТЕХНИЧЕСКИЕ ХАРАКТЕРИСТИКИ',
	
# ); 

# # my $h = 'ID товара	Название товара	Название товара в URL	URL	Краткое описание	Полное описание	Видимость на витрине	Тег title	Мета-тег keywords	Мета-тег description	Размещение на сайте	Изображения	Свойство: Размер	Свойство: Цвет	ID модификации	Артикул	Цена продажи	Старая цена	Цена закупки	Остаток	Вес	Параметр: Размер	Параметр: Цвет';
# # $write_text_file_mode_rewrite -> put_str (join ("\t", @headers)."\n");
# # $write_text_file_mode_rewrite -> put_str ($h."\n");


# foreach (@read_text_file1) {
	# print ++$count."\n";
	# $write_text_file_mode_rewrite -> put_str ($_."\n");
# }
# $write_text_file_mode_rewrite = undef;


# # copy ($file3, getcwd () .'/txt/1.csv');

if (scalar (keys (%file1)) > 0) {
	my $write_text_file_mode_rewrite = write_text_file_mode_rewrite -> new ($file3);
		
	my @headers = (
		'player_id',
		'player_FN',
		'player_LN',
		'player_number',
		
		'team_id',
		'date',
		'league',
		'gender',
		'game_id',
		'instat_id',
	);	
	
	$write_text_file_mode_rewrite -> put_str (join ("\t", @headers)."\n");
	foreach (keys (%file1)) {
		$write_text_file_mode_rewrite -> put_str ($file1 {$_}."\n");
	}
	$write_text_file_mode_rewrite = undef;
}

if (scalar (keys (%file2)) > 0) {
	my $write_text_file_mode_rewrite = write_text_file_mode_rewrite -> new ($file4);
	my @headers = (
		'team_id',
		'team_name',
		'team_short_name',
		'date',
		'league',
		'gender',
		'instat_id',
	);	
	
	$write_text_file_mode_rewrite -> put_str (join ("\t", @headers)."\n");
	foreach (keys (%file2)) {
		$write_text_file_mode_rewrite -> put_str ($file2 {$_}."\n");
	}
	$write_text_file_mode_rewrite = undef;
}









sub post_teams {
	my $postdata = shift;
	
	
	my $key_import2 = '22812357092873478234729374';
        my $url = 'http://data.instatfootball.tv/api/import2?key='.$key_import2.'&method=UpdateBasketballSynergyTeams';	
	# my $postdata = 'firstsec=1&email=is.fin.dept%40gmail.com&pwd=basket55&women=0&B1=Login';

	push (@{ $lwp->requests_redirectable }, 'POST');
	my $req = HTTP::Request -> new (
	'POST' => $url,
		[
			# 'User-Agent' => 'Mozilla/5.0 (Windows NT 5.1; rv:11.0) Gecko/20100101 Firefox/11.0',
			# 'Accept-Language' => 'ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
			# 'Referer' => 'http://basketball.eurobasket.com/player/Andrey-Vorontsevich/Russia/CSKA-Moscow/71366',
			# 'Content-Type' => 'application/json',
			
			'Accept' => '*/*',
			'Content-Type' => 'multipart/form-data; boundary=----------------------------4b5789fa8d3f',
			
		]
	);
	
	
	my $str = 
'------------------------------4b5789fa8d3f
Content-Disposition: form-data; name="json"

'.$postdata.'
------------------------------4b5789fa8d3f--';
	

	$req -> content ($str);
	
	my $file = getcwd () .'/txt/teams.html';
	my $res = $lwp -> request ($req, $file); 
	print $res -> code ."\t" . $url ."\n";
	
	# my $sleep = Random ($sleep2, $sleep3); 
	# sleep $sleep;		
}
		
sub post_players {
	my $postdata = shift;
	
	
	my $key_import2 = '22812357092873478234729374';
        my $url = 'http://data.instatfootball.tv/api/import2?key='.$key_import2.'&method=UpdateBasketballSynergyPlayers';	
	# my $postdata = 'firstsec=1&email=is.fin.dept%40gmail.com&pwd=basket55&women=0&B1=Login';

	push (@{ $lwp->requests_redirectable }, 'POST');
	my $req = HTTP::Request -> new (
	'POST' => $url,
		[
			# 'User-Agent' => 'Mozilla/5.0 (Windows NT 5.1; rv:11.0) Gecko/20100101 Firefox/11.0',
			# 'Accept-Language' => 'ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
			# 'Referer' => 'http://basketball.eurobasket.com/player/Andrey-Vorontsevich/Russia/CSKA-Moscow/71366',
			# 'Content-Type' => 'application/json',
			
			'Accept' => '*/*',
			'Content-Type' => 'multipart/form-data; boundary=----------------------------4b5789fa8d3f',
			
		]
	);
	
	
	my $str = 
'------------------------------4b5789fa8d3f
Content-Disposition: form-data; name="json"

'.$postdata.'
------------------------------4b5789fa8d3f--';
	

	$req -> content ($str);
	
	my $file = getcwd () .'/txt/players.html';
	my $res = $lwp -> request ($req, $file); 
	print $res -> code ."\t" . $url ."\n";
	
	# my $sleep = Random ($sleep2, $sleep3); 
	# sleep $sleep;		
}


sub get_instat_id_matches {
	my $match_id = shift;
	
	# https://data.instatfootball.tv/api/Getinstatid?key=22812357092873478234729374&method=UpdateBasketballSynergyMatches&id=414219,414525,414357
	my $url = 'https://data.instatfootball.tv/api/Getinstatid?key=22812357092873478234729374&method=UpdateBasketballSynergyMatches&id='.$match_id;
	my $method = 'GET';
	my $useragent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0';
	my $request = HTTP::Request -> new (
		$method => $url,
		[
			'User-Agent' => 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0',
			'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Accept-Language' => 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
			'Accept-Charset' => 'windows-1251,utf-8;q=0.7,*;q=0.7',

		]
	);

	my $file = getcwd () .'/txt/instat_id_matches.html';
	# my $response = $lwp -> request ($request, $file);
	my $response = $lwp -> request ($request);
	print $response -> code  ."\t". $url ."\n";
	print $response -> content ."\n";
	
	my $json_decode = decode_json ($response -> content);
	return $json_decode;
}

sub get_instat_id_players {
	my $match_id = shift;
	
	my $response_code = 0;
	my $json_decode = '[{}]';
	my $content_ok = 'nok';

	do {
		# https://data.instatfootball.tv/api/Getinstatid?key=22812357092873478234729374&method=UpdateBasketballSynergyMatches&id=414219,414525,414357
		my $url = 'https://data.instatfootball.tv/api/Getinstatid?key=22812357092873478234729374&method=UpdateBasketballSynergyPlayers&id='.$match_id;
		my $method = 'GET';
		my $useragent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0';
		my $request = HTTP::Request -> new (
			$method => $url,
			[
				'User-Agent' => 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0',
				'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
				'Accept-Language' => 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
				'Accept-Charset' => 'windows-1251,utf-8;q=0.7,*;q=0.7',
			]
		);

		my $file = getcwd () .'/txt/instat_id_players.html';
		# my $response = $lwp -> request ($request, $file);
		my $response = $lwp -> request ($request);
		print $response -> code  ."\t". $url ."\n";
		print $response -> content ."\n";
		
		my $content = $response -> content;
		$content =~ s/\n+//g;
		$content =~ s/\r+//g;
		$content =~ s/\t+//g;
		
		if ($content =~ /^\[\{"id":"\d+",/) {
			$content_ok = 'ok';
			$json_decode = decode_json ($response -> content);
		}	
		
		#sleep 1;
		
	} while ($response_code != 200 and $content_ok ne 'ok');
	
	return $json_decode;
}

sub get_instat_id_teams {
	my $match_id = shift;
	
	my $response_code = 0;
	my $json_decode = '[{}]';
	my $content_ok = 'nok';
	
	do {
	
		# https://data.instatfootball.tv/api/Getinstatid?key=22812357092873478234729374&method=UpdateBasketballSynergyMatches&id=414219,414525,414357
		my $url = 'https://data.instatfootball.tv/api/Getinstatid?key=22812357092873478234729374&method=UpdateBasketballSynergyTeams&id='.$match_id;
		my $method = 'GET';
		my $useragent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0';
		my $request = HTTP::Request -> new (
			$method => $url,
			[
				'User-Agent' => 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0',
				'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
				'Accept-Language' => 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
				'Accept-Charset' => 'windows-1251,utf-8;q=0.7,*;q=0.7',

			]
		);

		my $file = getcwd () .'/txt/instat_id_teams.html';
		# my $response = $lwp -> request ($request, $file);
		my $response = $lwp -> request ($request);
		print $response -> code  ."\t". $url ."\n";
		print $response -> content ."\n";
		
		my $content = $response -> content;
		$content =~ s/\n+//g;
		$content =~ s/\r+//g;
		$content =~ s/\t+//g;
		
		if ($content =~ /^\[\{"id":"\d+",/) {
			$content_ok = 'ok';
			$json_decode = decode_json ($response -> content);
		}	
		
		#задержкв
		#sleep 1;
		
	} while ($response_code != 200 and $content_ok ne 'ok');
		
	return $json_decode;
}

sub get_instat_id {
	my $match_id = shift;
	
	my $response_code = 0;
	my $json_decode = '[{}]';
	my $content_ok = 'nok';
	
	do {
	
		# https://data.instatfootball.tv/api/Getinstatid?key=22812357092873478234729374&method=UpdateBasketballSynergyMatches&id=414219,414525,414357
		my $url = 'https://data.instatfootball.tv/api/Getinstatid?key=22812357092873478234729374&method=UpdateBasketballSynergyMatches&id='.$match_id;
		my $method = 'GET';
		my $useragent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0';
		my $request = HTTP::Request -> new (
			$method => $url,
			[
				'User-Agent' => 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0',
				'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
				'Accept-Language' => 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
				'Accept-Charset' => 'windows-1251,utf-8;q=0.7,*;q=0.7',
			]
		);

		my $file = getcwd () .'/txt/get_1.html';
		# my $response = $lwp -> request ($request, $file);
		my $response = $lwp -> request ($request);
		print $response -> code  ."\t". $url ."\n";
		print $response -> content ."\n";
		
		my $content = $response -> content;
		$content =~ s/\n+//g;
		$content =~ s/\r+//g;
		$content =~ s/\t+//g;
		
		if ($content =~ /^\[\{"id":"\d+",/) {
			$content_ok = 'ok';
			$json_decode = decode_json ($response -> content);	
		}
		
		#задержкв
		#sleep 1;
		
	} while ($response_code != 200 and $content_ok ne 'ok');
	
	return $json_decode;
}
