#!/usr/bin/env perl
use strict;
use warnings;
use File::Path;
use Encode qw (decode encode);
use locale;
use List::Util qw (shuffle);
use dir_scan_recurce;
use File::Copy;
use File::Path;

use threads;
use threads::shared;
use Thread::Queue;

use read_inifile;
use read_select1;
use read_select2;
use clear_str;
use create_type_workdir;
use url_to_file;
use read_xml;

use work_mysql_proxy;
use work_mysql_graber;
use work_for_content;
use URI::URL;
use JSON::XS;

use write_text_file_mode_add;
use write_text_file_mode_rewrite; 
use read_text_file;

use LWP::UserAgent;
use HTTP::Request;
use HTTP::Response;
use HTTP::Cookies;
use URI::Escape;
use HTML::TreeBuilder::XPath;
use LWP::Protocol::http;
use work_mysql_agregator;
use work_mysql_agregator2;

# system 'clear_table.pl'; 
# system 'clear_dir.pl';

#Читаю установки из ини файла
my $read_inifile = read_inifile -> new ('graber.ini'); 
my $mysql_dbdriver = $read_inifile -> get ('mysql_dbdriver');
my $mysql_host = $read_inifile -> get ('mysql_host');
my $mysql_port = $read_inifile -> get ('mysql_port');
my $mysql_user = $read_inifile -> get ('mysql_user');
my $mysql_user_password = $read_inifile -> get ('mysql_user_password');
if ($mysql_user_password eq ' ') {$mysql_user_password = '';}
my $mysql_base = $read_inifile -> get ('mysql_base');
my $mysql_table = $read_inifile -> get ('mysql_table');

my $threads_all = $read_inifile -> get ('threads_all'); 
my $sleep1 = $read_inifile -> get ('sleep1'); 
my $sleep2 = $read_inifile -> get ('sleep2'); 
my $sleep3 = $read_inifile -> get ('sleep3'); 
my $host = $read_inifile -> get ('host');	
my $count_all = $read_inifile -> get ('count_all');	

#Создаем дескриптор на mysql соединение
my  $work_mysql_graber = work_mysql_graber -> new (
	$mysql_dbdriver,
	$mysql_host,
	$mysql_port,
	$mysql_user,
	$mysql_user_password,
	$mysql_base,
	$mysql_table
); 

#соединяемся с прокси таблицей
my  $work_mysql_proxy = work_mysql_proxy -> new (
	$mysql_dbdriver,
	$mysql_host,
	$mysql_port,
	$mysql_user,
	$mysql_user_password,
	$mysql_base,
	$mysql_table. '_proxy',	
); 

# ситуация с прокси
my $queue_job_proxy = Thread::Queue->new ();
my $lwp_proxy = undef; #глобальная переменная, содержащая данные о прокси
if ($read_inifile -> {proxy_set} == 1) {
	
	$work_mysql_proxy -> drop_table (); 
	$work_mysql_proxy -> create_table (); 
	$work_mysql_proxy -> clear_proxy ($read_inifile -> {proxy_clear}, $read_inifile -> {proxy_try_max});
	$work_mysql_proxy -> get_proxy_from_service (); 
}	


# #Создаем дескриптор на mysql соединение
# my $work_mysql_agregator = work_mysql_agregator -> new (
	# $mysql_dbdriver,
	# $mysql_host,
	# $mysql_port,
	# $mysql_user,
	# $mysql_user_password,
	# $mysql_base,
	# $read_inifile -> {agregator}
# ); 

# if ($read_inifile -> {clear_agregator} == 1) {
	# $work_mysql_agregator -> drop ();
# }
# $work_mysql_agregator -> create ();		
# # $work_mysql_agregator2 -> clear ($read_inifile -> {clear_agregator_time});

# #Создаем дескриптор на mysql соединение
# my $work_mysql_agregator2 = work_mysql_agregator2 -> new (
	# $mysql_dbdriver,
	# $mysql_host,
	# $mysql_port,
	# $mysql_user,
	# $mysql_user_password,
	# $mysql_base,
	# $read_inifile -> {agregator2}
# ); 

# if ($read_inifile -> {clear_agregator} == 1) {
	# $work_mysql_agregator2 -> drop ();
# }
# $work_mysql_agregator2 -> create ();		
# # $work_mysql_agregator2 -> clear ($read_inifile -> {clear_agregator_time});	

my @global = ();
my @proxy = (); 
my @useragent = (); 

# читаем шаблоны (ссылок и прочее)
my $read_select2 = read_select2 -> new ('select2.txt'); 
my @read_select2 = $read_select2 -> get ();
$read_select2 = undef;

my $read_select3 = read_select2 -> new ('select3.txt'); 
my @read_select3 = $read_select3 -> get ();
$read_select3 = undef;

my $read_select4 = read_select2 -> new ('select4.txt'); 
my @read_select4 = $read_select4 -> get ();
$read_select4 = undef;	


#создаю экземпляр броузера
my $lwp = undef;
$lwp = LWP::UserAgent -> new ();
$lwp -> cookie_jar (HTTP::Cookies->new ());
$lwp -> agent ('Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; .NET4.0C; .NET4.0E; rv:11.0) like Gecko');
$lwp -> timeout (60);

if (!-d 'c:/windows') {
	my $ppp = get_ppp ();
	$lwp -> proxy (['http', 'https'], 'http://'.$ppp);
}


my $insert = {};

# $insert = get_1 ($insert);
# sleep 2;

$insert = login ($insert);

# $insert = get_2 ($insert);
# sleep 2;


{
	my $count = 0;
	my $workdir1 = getcwd () .'/xls';
	my $dir_scan_recurce = dir_scan_recurce -> new ($workdir1);
	while (my $file1 = $dir_scan_recurce -> get_file ()) {
		print ++$count."\n";
		
		my $pattern = 'xls$';
		if ($file1 =~ /$pattern/) {	
			
			my @file1 = ();	
			my $read_text_file = read_text_file -> new ($file1); 
			while (my $str1 = $read_text_file -> get_str ()) {
			
				if ($str1 =~ /\t/) {
					my $temp1 = []; my $pattern1 = "\t"; @$temp1 = split ($pattern1, $str1); 
					
					# print '*'.scalar (@$temp1)."\n";
					if (scalar (@$temp1) > 1) {			
						print ++$count."\n";	
						
						foreach (@$temp1) {
							my $clear_str = clear_str -> new ($_); 
							$_ = $clear_str -> delete_4 ();
							$clear_str = undef;
						}
						
						if ($temp1 -> [1] =~ /\d+/) {
							$insert -> {post_url} = $temp1 -> [0];
							
							my $md5 = MD5 -> new ();
							my $hash = $md5 -> hexhash ($insert -> {post_url});
							$md5 = undef;
							
							
							my $file = getcwd () .'/html/'.$hash.'.xml';
							if (!-f $file) {
								
								post_get_xml ($insert);
								
								
								my @file1 = ();	
								my $read_text_file = read_text_file -> new ($file); 
								while (my $str1 = $read_text_file -> get_str ()) {
									my $clear_str = clear_str -> new ($str1); 
									$str1 = $clear_str -> delete_4 ();
									$clear_str = undef;			
									push (@file1, $str1); 
								}
								$read_text_file = undef;
								
								my $content1 = join (' ', @file1); 
								
								my $gameid = undef;
								my $pattern1 = '(<iGameID>\d+</iGameID>)';
								my $work_for_content = work_for_content -> new ($content1); 
								my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
								if (defined $work_for_content_result -> [0]) {
									foreach (@$work_for_content_result) {		
										my $clear_str = clear_str -> new ($_);
										$_ = $clear_str -> delete_3_s ();
										$_ = $clear_str -> delete_4 ();
										$clear_str = undef;		
										
										$_ =~ s/^\s+//;
										$_ =~ s/\s+$//;
										$_ =~ s/^\s+$//;

										$insert -> {gameid} = $_;
										$gameid = $_;
									}
								}
								
								if (defined ($gameid)) {
									
									my $file2 = $file1;
									$file2 =~ s/^.+\///;
									$file2 = getcwd () .'/picture/'.$insert -> {gameid} .'.xml';
									
									copy ($file, $file2) or die;
									
									
									post_get_xml2 ($insert);
									
								} else {
									
									
									unlink ($file); 
									$insert = login ($insert);
									sleep 15;
									
								}
							}
						}
					}
				}
			}
		}
	}
}



exit;



# {
	# my $sleep = Random ($sleep2, $sleep3); 
	# sleep $sleep;		
# }




# $insert -> {access_token} = 'MjI2ODg5NTUxOmVjOGYxNmVmOTBkYjYxYjdjYjQ5OTRhNGEyYzY3ODNk';


# {
	# my $sleep = Random ($sleep2, $sleep3); 
	# sleep $sleep;		
# }

my $count_page = 0;
# start_first ();

work_thread3 (); #делает NEW из WORK
work_thread1 (); #забираю првичные ссылки из массива

while (scalar (@global) > 0) {
	my $str = shift (@global); 
	work_thread2 ($str); 
	work_thread1 (); #добавляю ссылки в глобальный массив из БД
}



sub start_first {
	
	my $read_xml = read_xml -> new ('select1.xml');
	my $xml = $read_xml -> get ();
	
	foreach (@$xml) {
		
		my $method = 'GET'; 
		my $url = $_->{url}; 
		my $referer = $_->{referer}; 
			
		my $type = 'html';
		my $str_for_content = $_->{str_for_content}; 
		
		$work_mysql_graber -> insert_ignore (
			$method, 
			$url,
			$referer,
			$type, 
			$str_for_content
		); 						
		
		# Не делаю ссылки new при апе
		# $work_mysql_graber -> update_set_new ($url);
	}
}

sub work_thread1 {
	my $array = $work_mysql_graber -> select_all_update_work ($threads_all);
	if (scalar (@$array) > 0) {
		foreach (@$array) {
			push (@global,$_)
		}
	}
}


sub work_thread2 {
	my $job = shift;
	
	my $hash = $job -> {hash};	
	my $method = $job -> {method};	
	my $url = $job -> {url};	
	my $referer = $job -> {referer};	
	my $file = $job -> {file};	
	my $type = $job -> {type};	
	my $str_for_content = $job -> {str_for_content};	
	
	my $create_type_workdir = create_type_workdir -> new ($type);
	my $type_workdir = $create_type_workdir -> do ();
	$file = $type_workdir.'/'.$file;
	
	my $content1 = get_content_from_url ($job);
	if (defined $content1) {
		my $content2 = $content1; 
	
		if (-f $file) {
			
			if ($type eq 'html') {
				
				my $content2 = get_content_from_file ($file); 
				# $content2 = utf8_to_win1251 ($content2);
				
				my $clear_str = clear_str -> new ($content2); 
				$content2 = $clear_str -> delete_4 ();
				$clear_str = undef;	
				# $content2 =~ s/>\s+</></g;
				# $content2 =~ s/\'/"/g;
				
				# my $tree = HTML::TreeBuilder::XPath -> new ();
				# $tree -> parse_content ($content2);
				# my $content3 = $tree -> findnodes_as_string ('//div[@class="VacancyListElement_item_wr"]'); 
				# $tree->delete;
				# $tree = undef;						
				
				# # #объявления
				# my @content3 = split ("\n", $content3); 
				# if (scalar (@content3) > 0) {
					# foreach (@content3) {
						# my $clear_str = clear_str -> new ($_);
						# $_ = $clear_str -> delete_4 ();
						# $clear_str = undef;						
						
				
				my $pattern1 = '(<div class="item-card__info".+?</a>)';
				my $work_for_content = work_for_content -> new ($content2); 
				my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
				if (defined $work_for_content_result -> [0]) {
					foreach (@$work_for_content_result) {		
						my $clear_str = clear_str -> new ($_);
						$_ = $clear_str -> delete_4 ();
						$clear_str = undef;		
						$_ = entities_decode ($_);	
						
						my $pattern1 = 'href="(.+?)"';
						my $work_for_content = work_for_content -> new ($_); 
						my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
						
								my $uri = URI::URL-> new( $_, $job -> {url});
								my $url = $uri->abs;
								
								my $method = 'GET';
								my $type = 'media';
								my $referer = $job -> {referer};
								my $str_for_content = $job -> {str_for_content};
								
								$work_mysql_graber -> insert_ignore (
									$method, 
									$url,
									$referer,
									$type, 
									$str_for_content
								); 
							}
						}
					}
				}
						

						
				# my $json_decode = decode_json ($job -> {str_for_content});
				# my $name = encode ('utf8',  $json_decode -> {name});
						
				# my $pattern1 = '(<div class="item-card__info".+?</a>)';
				# my $work_for_content = work_for_content -> new ($content2); 
				# my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
				# if (defined $work_for_content_result -> [0]) {
					# foreach (@$work_for_content_result) {		
						# my $clear_str = clear_str -> new ($_);
						# $_ = $clear_str -> delete_4 ();
						# $clear_str = undef;		
						# $_ = entities_decode ($_);	
						
						# my $a = undef;
						# my $pattern1 = '(<a.+?</a>)';
						# my $work_for_content = work_for_content -> new ($_); 
						# my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						# if (defined $work_for_content_result -> [0]) {
							# foreach (@$work_for_content_result) {		
								# my $clear_str = clear_str -> new ($_);
								# $_ = $clear_str -> delete_3_s ();
								# $_ = $clear_str -> delete_4 ();
								# $clear_str = undef;		
								# $_ =~ s/^\s+//;
								# $_ =~ s/\s+$//;
								# $_ =~ s/^\s+$//;
								
								# $a = $_;
							# }
						# }
						
						
						# if ($a eq $name) {

							# my $pattern1 = 'href="(.+?)"';
							# my $work_for_content = work_for_content -> new ($_); 
							# my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
							# if (defined $work_for_content_result -> [0]) {
								# foreach (@$work_for_content_result) {		
									# my $clear_str = clear_str -> new ($_);
									# $_ = $clear_str -> delete_4 ();
									# $clear_str = undef;		
							
									# my $uri = URI::URL-> new( $_, $job -> {url});
									# my $url = $uri->abs;
									
									# my $method = 'GET';
									# my $type = 'media';
									# my $referer = $job -> {referer};
									# my $str_for_content = $job -> {str_for_content};
									
									# $work_mysql_graber -> insert_ignore (
										# $method, 
										# $url,
										# $referer,
										# $type, 
										# $str_for_content
									# ); 
								# }
							# }
							
						# }
					# }
				# }



				
				# if ($job -> {url} =~ /offset=0/ and $job -> {url} !~ /rubric_id/) {
				
					# # 400*25
					# # 9975 (последняя доступная страничка)
					# # +25
						
					# my $decode_json = decode_json ($content2);
					
					# my $rubrics_all = $job -> {str_for_content};
					# my $rubrics =  $rubrics_all;
					
					# my $page_full = $decode_json -> {metadata} -> {resultset} -> {count};
					
					# if ($page_full > 9975) {
						# $page_full = 9975;
						# # $page_full = 200;
					# }
						
					# my $page_one = 0;
					# while ($page_full > $page_one) {
					
						# my $url = $job -> {url};
						
						# my $pattern1 = 'offset=\d+';
						# my $pattern2 = 'offset='.$page_one;
						# $url =~ s/$pattern1/$pattern2/;
						
						# my $method = 'GET';
						# my $type = 'html';
						
						# my $referer = $url;
						# my $str_for_content = $job -> {str_for_content};
						
						# $work_mysql_graber -> insert_ignore (
							# $method, 
							# $url,
							# $referer,
							# $type, 
							# $str_for_content
						# ); 
						# $page_one = $page_one + 25;
					# }
				# }

				
					
				# my $pattern1 = '(<table class="l-table">.+?</table>)';
				# my $work_for_content = work_for_content -> new ($content2); 
				# my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
				# if (defined $work_for_content_result -> [0]) {
					# foreach (@$work_for_content_result) {		
						# my $clear_str = clear_str -> new ($_);
						# $_ = $clear_str -> delete_4 ();
						# $clear_str = undef;										
				
						# my $pattern1 = '(<td class="l-table-td b-vacancy.+?</a>)';
						# my $work_for_content = work_for_content -> new ($_); 
						# my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						# if (defined $work_for_content_result -> [0]) {
							# foreach (@$work_for_content_result) {		
								# my $clear_str = clear_str -> new ($_);
								# $_ = $clear_str -> delete_4 ();
								# $clear_str = undef;										
								
								# my $pattern1 = 'href="(.+?)"';
								# my $work_for_content = work_for_content -> new ($_); 
								# my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
								# if (defined $work_for_content_result -> [0]) {
									# foreach (@$work_for_content_result) {		
										# my $clear_str = clear_str -> new ($_);
										# $_ = $clear_str -> delete_4 ();
										# $clear_str = undef;															
										# $_ = entities_decode ($_);	

										# my $uri = URI::URL-> new( $_, $job -> {url});
										# my $url = $uri->abs;
										
										# my $md5 = MD5 -> new ();
										# my $hash = $md5 -> hexhash ($url);
										# $md5 = undef;
										
										# my $insert = {};
										# $insert -> {hash} = $hash;

										# my $result = $work_mysql_agregator2 -> select ($insert);
										# if (scalar (@$result) > 0) {
											# #если урл уже есть, то ничего не делаем.
										
										# } else {									
										
											# $count_page++;
											# if ($read_inifile -> {count_page_limit} > $count_page) {
												
												# my $method = 'GET';
												# my $type = 'media';
												# my $str_for_content = 'href';
												# my $referer = $job -> {referer};
												
												# $work_mysql_graber -> insert_ignore (
													# $method, 
													# $url,
													# $referer,
													# $type, 
													# $str_for_content
												# ); 						
											# }
										# }
									# }
								# }
							# }
						# }
					# }
				# }
					
				
				# #паджинация
				# $pattern1 = '(<li data-qa="pager-page">.+?</li>)';
				# $work_for_content = work_for_content -> new ($content2); 
				# $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
				# if (defined $work_for_content_result -> [0]) {
					# foreach (@$work_for_content_result) {		
						# my $clear_str = clear_str -> new ($_);
						# $_ = $clear_str -> delete_4 ();
						# $clear_str = undef;					
						
						# my $pattern1 = '(<a.+?</a>)';
						# my $work_for_content = work_for_content -> new ($_); 
						# my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						# if (defined $work_for_content_result -> [0]) {
							# foreach (@$work_for_content_result) {		
								# my $clear_str = clear_str -> new ($_);
								# $_ = $clear_str -> delete_4 ();
								# $clear_str = undef;			
								# $_ = entities_decode ($_);
								
								# my $pattern1 = 'href="(.+?)"';
								# my $work_for_content = work_for_content -> new ($_); 
								# my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
								# if (defined $work_for_content_result -> [0]) {
									# foreach (@$work_for_content_result) {		
										# my $clear_str = clear_str -> new ($_);
										# $_ = $clear_str -> delete_4 ();
										# $clear_str = undef;					
										
										# my $uri = URI::URL-> new( $_, $job -> {url});
										# my $url = $uri->abs;
										
										# my $page = 0;
										# my $pattern1 = 'page=(\d+)$';
										# my $work_for_content = work_for_content -> new ($_); 
										# my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
										# if (defined $work_for_content_result -> [0]) {
											# foreach (@$work_for_content_result) {		
												# my $clear_str = clear_str -> new ($_);
												# $_ = $clear_str -> delete_4 ();
												# $clear_str = undef;					
												# $page = $_;
											# }
										# }
										
										# if ($page < $read_inifile -> {pagination_depth}) {
										
											# my $method = 'GET';
											# my $type = 'html';
											# my $str_for_content = 'href';
											# my $referer = $job -> {referer};
											
											# $work_mysql_graber -> insert_ignore (
												# $method, 
												# $url,
												# $referer,
												# $type, 
												# $str_for_content
											# ); 
										# }
									# }
								# }
							# }
						# }
					# }
				# }						
				
				
			} #if html
			
			
			
		} else {
			#если файла нету
			$work_mysql_graber -> update_set_fail ();
		}
	}

}

sub work_thread3 {
	$work_mysql_graber -> update_set_new_if_work ();
}


sub get_content_from_url {
	my $job = shift;
	
	my $method = $job -> {method};
	my $url = $job -> {url};;
	my $referer = $job -> {referer};;
	my $file = $job->{type}.'/'.$job -> {file};
	
	my $content = undef;	
	my $useragent = 'Mozilla/5.0 (Windows NT 6.1; rv:43.0) Gecko/20100101 Firefox/43.0';
	
	if ($read_inifile -> {proxy_set} == 1) {
		
		if ($lwp_proxy = $queue_job_proxy -> dequeue_nb ())  {
			print '$lwp_proxy -> {address} = '. $lwp_proxy -> {address} ."\n";
			
			# #прокси
			# $lwp -> proxy ('http', 'http://'.$lwp_proxy -> {address});
			
			# доп IP
			@LWP::Protocol::http::EXTRA_SOCK_OPTS = (LocalAddr => $lwp_proxy -> {address});
			
		} else {
			my $get_proxy_from_table = $work_mysql_proxy -> get_proxy_from_table ($read_inifile -> {proxy_select}, $read_inifile -> {proxy_try_max});
			if (scalar (@$get_proxy_from_table) > 0) {
				foreach (@$get_proxy_from_table) {
					$queue_job_proxy -> enqueue ($_); 
				}
				
				$lwp_proxy = $queue_job_proxy -> dequeue_nb ();
				print '$lwp_proxy -> {address} = '. $lwp_proxy -> {address} ."\n";
				
				# прокси
				# $lwp -> proxy ('http', 'http://'.$lwp_proxy -> {address});

				# доп IP
				@LWP::Protocol::http::EXTRA_SOCK_OPTS = (LocalAddr => $lwp_proxy -> {address});
				
			} else {
				print 'proxy!!!!! net' ."\n";
				exit;				
			}
		}
	}

	my $req = HTTP::Request -> new (
		$method => $url,
		[	
			# 'Host' => 'api.zp.ru',
			'User-Agent' => $useragent,
			'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Accept-Language' => 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
			'Accept-Charset' => 'windows-1251,utf-8;q=0.7,*;q=0.7',
			'Referer' => $referer, 
			
			#тут используется токен от логина (он какой то короткий)
			# 'Authorization' =>	'token '.$insert -> {access_token},
			# 'Authorization' => 'token MjI2ODg5NTUxOmVjOGYxNmVmOTBkYjYxYjdjYjQ5OTRhNGEyYzY3ODNk',
			# 'Authorization' => $read_inifile -> {Authorization},
			# 'Referer' => 'https://hr.zarplata.ru/resumes/?geo_id=787&is_hide_foreigner=0&is_new_only=0&is_notempty_salary=0&is_photo=0&search_type=fullThrottle',
			# 'Origin' => 'https://hr.zarplata.ru',
			
		]
	);


	my $response = $lwp -> request ($req, $file);
	print $response -> code ."\t". $url. "\n";
	
	if ($response -> code == 200) {
		$work_mysql_graber -> update_set_pass ($url); 
	} else {
		
		if ($read_inifile -> {proxy_set} == 1) {
			
			$lwp_proxy -> {try}++; #ставлю прокси попытку неудачную
			$work_mysql_proxy -> set_proxy_try ($lwp_proxy -> {hash}, $lwp_proxy -> {try});
			$work_mysql_graber -> update_set_new ($url); 
			
		} else {
			$work_mysql_graber -> update_set_fail ($url);
		}		
	}
	
	my $sleep = Random ($sleep2, $sleep3); 
	sleep $sleep;	
}


sub get_content_from_file {
	my $file = shift;
	my @file = ();
	open (my $fh, $file) or die;
	while (<$fh>) {push (@file, $_);}
	close ($fh); 
	my $pattern = ''; my $str = join ($pattern, @file); 
	return $str;
}

sub get_base_path {
	use Cwd; 
	my $cwd = getcwd ();
	return $cwd;
}

sub put_content_to_file {
	my $content = shift;
	my $file = shift;
	open (my $fh, '>'.$file) or die;
	print $fh $content; 
	close ($fh);
}

sub utf8_to_win1251 {
	use Encode qw (encode decode); 
	my $str = shift;
	$str = encode ('cp1251', decode ('utf8', $str)); 
	return $str;
}

sub entities_decode {
	use HTML::Entities;
	my $str = shift;
	#перед отдачей модулю нужно сделать decode с любой кодировки
	$str = decode ('cp1251', $str);
	$str = decode_entities ($str);
	$str = encode ('cp1251', $str);
	return $str;
}


sub Random {
	my $from = shift;
	my $to = shift;
	my $random = $from + rand(($to - $from));
	return $random;
}


# POST https://hh.ru/account/login HTTP/1.1
# Host: hh.ru
# User-Agent: Mozilla/5.0 (Windows NT 5.1; rv:29.0) Gecko/20100101 Firefox/29.0
# Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
# Accept-Language: ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3
# Referer: http://hh.ru/vacancy/13463864
# Cookie: regions=1; __utma=1.1781838226.1432019885.1432019885.1432116504.2; __utmz=1.1432019885.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); __gfp_64b=SDbVPQDmFLStSRDDJcBa5pyOFbecUhtlxyHNXXgXZcz.A7; hhtoken=3N1DH!7IjCpV1kfAVnK44NIWnC1U; hhuid=KZ4VxD6C7x3vM1Va8gor3g--; _xsrf=6a661b24999e1db7246a8ccaefbd0b21; _xsrf=6a661b24999e1db7246a8ccaefbd0b21; hhrole=anonymous; unique_banner_user=1432120182.463679676916510; GMT=4; __utmc=1; display=desktop
# Connection: keep-alive
# Content-Type: application/x-www-form-urlencoded
# Content-Length: 252


# backUrl=http%3A%2F%2Fhh.ru%2Fvacancy%2F13463864&failUrl=%2Faccount%2Flogin%3Fbackurl%3D%252Fvacancy%252F13463864&username=b.businka2016%40yandex.ru&password=10041998&backUrl=http%3A%2F%2Fhh.ru%2Fvacancy%2F13463864&_xsrf=6a661b24999e1db7246a8ccaefbd0b21

sub get_1 {
	my $return  = shift;
	
	my $url = 'https://www.synergysportstech.com/Synergy/Default.aspx';
	my $req = HTTP::Request -> new (
		'GET' => $url,
		[	
			'User-Agent' => 'Mozilla/5.0 (Windows NT 6.1; rv:43.0) Gecko/20100101 Firefox/43.0',
			'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Accept-Language' => 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
			'Accept-Charset' => 'windows-1251,utf-8;q=0.7,*;q=0.7',
		]
	);

	my $file = getcwd () .'/txt/001.html';
	# my $response = $lwp -> request ($req, $file);	
	my $response = $lwp -> request ($req);	
	print $response -> code ."\t".$url."\n";
	
	
	my $content2 = $response -> content;
	$content2 =~ s/\n+//g;
	
	my $pattern1 = '<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="(.+?)"';
	my $work_for_content = work_for_content -> new ($content2); 
	my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
	if (defined $work_for_content_result -> [0]) {
		foreach (@$work_for_content_result) {		
			my $clear_str = clear_str -> new ($_);
			$_ = $clear_str -> delete_4 ();
			$clear_str = undef;					
			$return -> {VIEWSTATE} = $_;
			print '$return -> {VIEWSTATE} = '. $return -> {VIEWSTATE} ."\n";
		}
	}
	
	$pattern1 = '<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="(.+?)"';
	$work_for_content = work_for_content -> new ($content2); 
	$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
	if (defined $work_for_content_result -> [0]) {
		foreach (@$work_for_content_result) {		
			my $clear_str = clear_str -> new ($_);
			$_ = $clear_str -> delete_4 ();
			$clear_str = undef;					
			$return -> {VIEWSTATEGENERATOR} = $_;
			print '$return -> {VIEWSTATEGENERATOR} = '. $return -> {VIEWSTATEGENERATOR} ."\n";
		}
	}
	
	$pattern1 = '<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="(.+?)"';
	$work_for_content = work_for_content -> new ($content2); 
	$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
	if (defined $work_for_content_result -> [0]) {
		foreach (@$work_for_content_result) {		
			my $clear_str = clear_str -> new ($_);
			$_ = $clear_str -> delete_4 ();
			$clear_str = undef;					
			$return -> {EVENTVALIDATION} = $_;
			print '$return -> {EVENTVALIDATION} = '. $return -> {EVENTVALIDATION} ."\n";
		}
	}
	
	my $sleep = Random ($sleep2, $sleep3); 
	sleep $sleep;	
	
	
	return $return;
}

sub login2 {
	my $insert = shift;
	my $url = 'https://www.synergysportstech.com/synergy/';
	
	$insert -> {VIEWSTATE} = uri_escape ($insert -> {VIEWSTATE});
	$insert -> {VIEWSTATEGENERATOR} = uri_escape ($insert -> {VIEWSTATEGENERATOR});
	$insert -> {EVENTVALIDATION} = uri_escape ($insert -> {EVENTVALIDATION});

	
	my $postdata = undef;
	if (defined ($read_inifile -> {login}) and defined ($read_inifile -> {password})) {
		$postdata = '__VIEWSTATE='.$insert -> {VIEWSTATE}.'&__VIEWSTATEGENERATOR='.$insert -> {VIEWSTATEGENERATOR}.'&__EVENTVALIDATION='.$insert -> {EVENTVALIDATION}.'&txtUserName='.uri_escape ($read_inifile -> {login}).'&txtPassword='.uri_escape ($read_inifile -> {password}).'&lstClientType=Default&btnLogin=Login';
	} else {
		$postdata = '__VIEWSTATE='.$insert -> {VIEWSTATE}.'&__VIEWSTATEGENERATOR='.$insert -> {VIEWSTATEGENERATOR}.'&__EVENTVALIDATION='.$insert -> {EVENTVALIDATION}.'&txtUserName=tmijato%40yahoo.com&txtPassword=Efes2012&lstClientType=Default&btnLogin=Login';
	}
	
	
	push (@{ $lwp->requests_redirectable }, 'POST');
	my $req = HTTP::Request -> new (
	'POST' => $url,
		[
			'Host' => 'www.synergysportstech.com',
			'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; .NET4.0C; .NET4.0E; rv:11.0) like Gecko',
			'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Accept-Language' => 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
			'Referer' => 'https://www.synergysportstech.com/synergy/',
			'Content-Type' => 'application/x-www-form-urlencoded',
		]
	);
	$req -> content ($postdata);
	my $file = getcwd () .'/txt/login.html';
	my $res = $lwp -> request ($req, $file); 
	# print $res -> code ."\t".$url."\n";
	
	# my $content = get_content_from_file ($file);
	# my $decode_json = decode_json ($content);
	# $insert -> {access_token} = $decode_json -> {access_token};
	# print '$insert -> {access_token} = ' . $insert -> {access_token} ."\n";
	
	my $sleep = Random ($sleep2, $sleep3); 
	sleep $sleep;	
	
	return $insert;
}


sub login {
	my $insert = shift;
	my $url = 'https://api.synergysportstech.com/core/api/session/login';
	# my $postdata = '{"UserName":"tmijato@yahoo.com","Password":"RWZlczIwMTI=","Site":4}';
	my $postdata = '{"UserName":"'.$read_inifile -> {login}.'","Password":"'.$read_inifile -> {password}.'","Site":4}';
	# print $postdata ."\n";
	
	push (@{ $lwp->requests_redirectable }, 'POST');
	my $req = HTTP::Request -> new (
	'POST' => $url,
		[
			'Host' => 'api.synergysportstech.com',
			'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; .NET4.0C; .NET4.0E; rv:11.0) like Gecko',
			'Accept-Encoding' => 'identity',
			'Accept-Language' => 'en-US',
			'Accept' => 'application/json',
			'Referer' => 'http://www.synergysportstech.com/EditorPlugin/ClientBin/SynergyEditor.Plugin.xap',
			'Content-Type' => 'application/json; charset=utf-8',
		]
	);
	$req -> content ($postdata);
	my $file = getcwd () .'/txt/login.html';
	my $res = $lwp -> request ($req, $file); 
	print $res -> code ."\t".$url."\n";
	
	# my $content = get_content_from_file ($file);
	# my $decode_json = decode_json ($content);
	# $insert -> {access_token} = $decode_json -> {access_token};
	# print '$insert -> {access_token} = ' . $insert -> {access_token} ."\n";
	
	my $content2 = get_content_from_file ($file);
	$content2 =~ s/\n+//g;
	
	my $pattern1 = '"token":"(.+?)"';
	my $work_for_content = work_for_content -> new ($content2); 
	my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
	if (defined $work_for_content_result -> [0]) {
		foreach (@$work_for_content_result) {		
			my $clear_str = clear_str -> new ($_);
			$_ = $clear_str -> delete_4 ();
			$clear_str = undef;					
			$insert -> {token} = $_;
			print '$return -> {token} = '. $insert -> {token} ."\n";
		}
	}	
	
	my $sleep = Random ($sleep2, $sleep3); 
	sleep $sleep;	
	
	return $insert;
}


sub get_2 {
	my $return  = shift;
	
	my $url = 'https://www.synergysportstech.com/Synergy/Sport/Basketball/web/teamsst/Video/SelectGame2.aspx';
	my $req = HTTP::Request -> new (
		'GET' => $url,
		[	
			'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; .NET4.0C; .NET4.0E; rv:11.0) like Gecko',
			'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Accept-Language' => 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
			'Accept-Charset' => 'windows-1251,utf-8;q=0.7,*;q=0.7',
		]
	);

	my $file = getcwd () .'/txt/get_2.html';
	my $response = $lwp -> request ($req, $file);	
	# my $response = $lwp -> request ($req);	
	print $response -> code ."\t".$url."\n";
	
	
	my $content2 = get_content_from_file ($file);
	$content2 =~ s/\n+//g;
	$content2 =~ s/""/" "/g;
	
	my $pattern1 = '<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="(.+?)"';
	my $work_for_content = work_for_content -> new ($content2); 
	my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
	if (defined $work_for_content_result -> [0]) {
		foreach (@$work_for_content_result) {		
			my $clear_str = clear_str -> new ($_);
			$_ = $clear_str -> delete_4 ();
			$clear_str = undef;					
			$_ =~ s/^\s+//;
			$_ =~ s/\s+$//;
			$_ =~ s/^\s+$//;
			
			$return -> {EVENTTARGET} = $_;
			print '$return -> {EVENTTARGET} = '. $return -> {EVENTTARGET} ."\n";
		}
	}
	
	$pattern1 = '<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value=(.+?)"';
	$work_for_content = work_for_content -> new ($content2); 
	$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
	if (defined $work_for_content_result -> [0]) {
		foreach (@$work_for_content_result) {		
			my $clear_str = clear_str -> new ($_);
			$_ = $clear_str -> delete_4 ();
			$clear_str = undef;				
			$_ =~ s/^\s+//;
			$_ =~ s/\s+$//;
			$_ =~ s/^\s+$//;

			$return -> {EVENTARGUMENT} = $_;
			print '$return -> {EVENTARGUMENT} = '. $return -> {EVENTARGUMENT} ."\n";
		}
	}
	
	
	$pattern1 = '<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="(.+?)"';
	$work_for_content = work_for_content -> new ($content2); 
	$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
	if (defined $work_for_content_result -> [0]) {
		foreach (@$work_for_content_result) {		
			my $clear_str = clear_str -> new ($_);
			$_ = $clear_str -> delete_4 ();
			$clear_str = undef;					
			$_ =~ s/^\s+//;
			$_ =~ s/\s+$//;
			$_ =~ s/^\s+$//;
			
			$return -> {VIEWSTATE} = $_;
			print '$return -> {VIEWSTATE} = '. $return -> {VIEWSTATE} ."\n";
		}
	}
	
	$pattern1 = '<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="(.+?)"';
	$work_for_content = work_for_content -> new ($content2); 
	$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
	if (defined $work_for_content_result -> [0]) {
		foreach (@$work_for_content_result) {		
			my $clear_str = clear_str -> new ($_);
			$_ = $clear_str -> delete_4 ();
			$clear_str = undef;					
			$_ =~ s/^\s+//;
			$_ =~ s/\s+$//;
			$_ =~ s/^\s+$//;
			
			$return -> {VIEWSTATEGENERATOR} = $_;
			print '$return -> {VIEWSTATEGENERATOR} = '. $return -> {VIEWSTATEGENERATOR} ."\n";
		}
	}
	
	$pattern1 = '<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="(.+?)"';
	$work_for_content = work_for_content -> new ($content2); 
	$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
	if (defined $work_for_content_result -> [0]) {
		foreach (@$work_for_content_result) {		
			my $clear_str = clear_str -> new ($_);
			$_ = $clear_str -> delete_4 ();
			$clear_str = undef;					
			$_ =~ s/^\s+//;
			$_ =~ s/\s+$//;
			$_ =~ s/^\s+$//;
			
			$return -> {EVENTVALIDATION} = $_;
			print '$return -> {EVENTVALIDATION} = '. $return -> {EVENTVALIDATION} ."\n";
		}
	}
	
	$pattern1 = '<input type="hidden" name="__LASTFOCUS" id="__LASTFOCUS" value="(.+?)"';
	$work_for_content = work_for_content -> new ($content2); 
	$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
	if (defined $work_for_content_result -> [0]) {
		foreach (@$work_for_content_result) {		
			my $clear_str = clear_str -> new ($_);
			$_ = $clear_str -> delete_4 ();
			$clear_str = undef;					
			$_ =~ s/^\s+//;
			$_ =~ s/\s+$//;
			$_ =~ s/^\s+$//;
			
			$return -> {LASTFOCUS} = $_;
			print '$return -> {LASTFOCUS} = '. $return -> {LASTFOCUS} ."\n";
		}
	}
	
	$pattern1 = '<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="(.+?)"';
	$work_for_content = work_for_content -> new ($content2); 
	$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
	if (defined $work_for_content_result -> [0]) {
		foreach (@$work_for_content_result) {		
			my $clear_str = clear_str -> new ($_);
			$_ = $clear_str -> delete_4 ();
			$clear_str = undef;					
			$_ =~ s/^\s+//;
			$_ =~ s/\s+$//;
			$_ =~ s/^\s+$//;
			
			$return -> {VIEWSTATEGENERATOR} = $_;
			print '$return -> {VIEWSTATEGENERATOR} = '. $return -> {VIEWSTATEGENERATOR} ."\n";
		}
	}
	
	
	$pattern1 = '<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="(.+?)"';
	$work_for_content = work_for_content -> new ($content2); 
	$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
	if (defined $work_for_content_result -> [0]) {
		foreach (@$work_for_content_result) {		
			my $clear_str = clear_str -> new ($_);
			$_ = $clear_str -> delete_4 ();
			$clear_str = undef;					
			$_ =~ s/^\s+//;
			$_ =~ s/\s+$//;
			$_ =~ s/^\s+$//;
			
			$return -> {EVENTVALIDATION} = $_;
			print '$return -> {EVENTVALIDATION} = '. $return -> {EVENTVALIDATION} ."\n";
		}
	}
	
	my $sleep = Random ($sleep2, $sleep3); 
	sleep $sleep;	
	
	
	return $return;
}


sub post_get_xml {

	#достает XML на матч
	
	my $insert = shift;
	my $url = 'https://api.synergysportstech.com/EditorAPI5/EditorAPI.asmx/GetPlaylist2';

	my $postdata =	
	'clientclips=%3cArrayOfTblClipEdits+xmlns%3ai%3d%22http%3a%2f%2fwww.w3.org%2f2001%2fXMLSchema-instance%22+xmlns%3d%22http%3a%2f%2ftempuri.org%2f%22+%2f%3e'.'&'.
	'clipmax=500'.'&'.
	'profile=500'.'&'.
	'removeslop=True'.'&'.
	'token='.uri_escape($insert -> {token}).'&'.
	# 'url=vType%3dViewVideo%26iDataViewID%3d67%26strSQL%3dZS5pR2FtZUlEPTQyMjI5Nw%3d%3d%26strCol%3diAllClips';
	'url='.$insert -> {post_url};
     
	
	push (@{ $lwp->requests_redirectable }, 'POST');
	my $req = HTTP::Request -> new (
	'POST' => $url,
		[
			'Host' => 'api.synergysportstech.com',
			'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; .NET4.0C; .NET4.0E; rv:11.0) like Gecko',
			'Accept' => '*/*',
			'Accept-Encoding' =>  'identity',
			'Accept-Language' => 'en-US',
			'Referer' => 'http://www.synergysportstech.com/EditorPlugin/ClientBin/SynergyEditor.Plugin.xap',
			'Content-Type' => 'application/x-www-form-urlencoded',
		]
	);
	$req -> content ($postdata);
	# my $file = getcwd () .'/txt/post_1.html';
	
	my $md5 = MD5 -> new ();
	my $hash = $md5 -> hexhash ($insert -> {post_url});
	$md5 = undef;
	
	my $file = getcwd () .'/html/'.$hash.'.xml';
	
	my $res = $lwp -> request ($req, $file); 
	print $res -> code ."\t".$url."\n";
	
	# my $content = get_content_from_file ($file);
	# my $decode_json = decode_json ($content);
	# $insert -> {access_token} = $decode_json -> {access_token};
	# print '$insert -> {access_token} = ' . $insert -> {access_token} ."\n";
	
	my $sleep = Random ($sleep2, $sleep3); 
	sleep $sleep;	
	
	return $insert;

}

sub post_get_xml2 {

	#достает XML на видео
	
	my $insert = shift;
	my $url = 'https://api.synergysportstech.com/EditorAPI5/EditorAPI.asmx/GetPossessionSegments3';

	my $postdata =	
	'gameid='.$insert -> {gameid}.'&'.
	'profile=500'.'&'.
	'removeslop=True'.'&'.
	'token='.uri_escape($insert -> {token});
     
	
	push (@{ $lwp->requests_redirectable }, 'POST');
	my $req = HTTP::Request -> new (
	'POST' => $url,
		[
			'Host' => 'api.synergysportstech.com',
			'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; .NET4.0C; .NET4.0E; rv:11.0) like Gecko',
			'Accept' => '*/*',
			'Accept-Encoding' =>  'identity',
			'Accept-Language' => 'en-US',
			'Referer' => 'http://www.synergysportstech.com/EditorPlugin/ClientBin/SynergyEditor.Plugin.xap',
			'Content-Type' => 'application/x-www-form-urlencoded',
		]
	);
	$req -> content ($postdata);
	# my $file = getcwd () .'/txt/post_1.html';
	
	# my $md5 = MD5 -> new ();
	# my $hash = $md5 -> hexhash ($insert -> {post_url});
	# $md5 = undef;
	
	my $file = getcwd () .'/media/'.$insert -> {gameid}.'.xml';
	
	my $res = $lwp -> request ($req, $file); 
	print $res -> code ."\t".$url."\n";
	
	# my $content = get_content_from_file ($file);
	# my $decode_json = decode_json ($content);
	# $insert -> {access_token} = $decode_json -> {access_token};
	# print '$insert -> {access_token} = ' . $insert -> {access_token} ."\n";
	
	my $sleep = Random ($sleep2, $sleep3); 
	sleep $sleep;	
	
	return $insert;

}



# sub get_3 {
	# my $return  = shift;
	
	# # my $url = 'http://www.synergysportstech.com/EditorPlugin/?profile=profile1&url=vType%3dViewVideo%26iDataViewID%3d15%26strSQL%3dZy5pR2FtZUlEPTQyMzEzMg%3d%3d%26strCol%3d0%26ClipMax%3d500';
	# my $url = 'http://www.synergysportstech.com/EditorPlugin/?profile=profile1&url=vType%3dViewVideo%26iDataViewID%3d15%26strSQL%3dZy5pR2FtZUlEPTQyMzEzMg%3d%3d%26strCol%3d0%26ClipMax%3d500';
	
	

	# my $req = HTTP::Request -> new (
		# 'GET' => $url,
		# [	
			# 'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; .NET4.0C; .NET4.0E; rv:11.0) like Gecko',
			# 'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			# 'Accept-Language' => 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
			# 'Accept-Charset' => 'windows-1251,utf-8;q=0.7,*;q=0.7',
			# 'Cookie' => 'synergy=setup=y&strloginfrom=The+Internet&runmode=connected&useragent=Mozilla%2f5.0+(Windows+NT+6.1%3b+rv%3a43.0)+Gecko%2f20100101+Firefox%2f40.0&iiptypeid=NA&clienttype=Default&videoplayer=Silverlight&accesstoken=niG%2fHnfK6nF99N23qu3YLXTh%2fKCMZp6Aak3rxiiNpa0n2Ti6bIkVqvVcwyZg9wfYgkqO0TPZw6wYkjCzI9%2f0hM7TEyRjlmWaiQQTdVpYSOzQqV%2fe06IRhAmN0%2ftd8DVDC%2fl%2frXHTZLF%2fsG8N1dUqBLk3hckL2uioOiPh7kFHx0I%3d&webroot=%2fSynergy%2fSport%2fBasketball%2fweb%2fteamsst%2f&theme=BasketballSST&clipmax=500&videoprofile=profile1;',
		# ]
	# );

	# my $file = getcwd () .'/txt/http_get_3.html';
	# my $response = $lwp -> request ($req, $file);	
	# # my $response = $lwp -> request ($req);	
	# print $response -> code ."\t".$url."\n";
	
	
	# my $content2 = get_content_from_file ($file);
	# $content2 =~ s/\n+//g;
	
	# my $pattern1 = '"token":"(.+?)"';
	# my $work_for_content = work_for_content -> new ($content2); 
	# my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
	# if (defined $work_for_content_result -> [0]) {
		# foreach (@$work_for_content_result) {		
			# my $clear_str = clear_str -> new ($_);
			# $_ = $clear_str -> delete_4 ();
			# $clear_str = undef;					
			# $return -> {token} = $_;
			# print '$return -> {token} = '. $return -> {token} ."\n";
		# }
	# }
	
	# return $return;
# }
# URL=http://akadatstorage03.aware.net/AwareNetWMS1/2/423132/189353354.mp4
# URL=http://www.synergysportstech.com/EditorPlugin/?profile=profile1&url=vType%3dViewVideo%26iDataViewID%3d15%26strSQL%3dZy5pR2FtZUlEPTQyMzEzMg%3d%3d%26strCol%3d0%26ClipMax%3d500


sub get_4 {
	my $return  = shift;
	
	my $url = 'http://akadatstorage03.aware.net/AwareNetWMS1/2/423132/189353354.mp4';
	my $req = HTTP::Request -> new (
		'GET' => $url,
		[	
			'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; .NET4.0C; .NET4.0E; rv:11.0) like Gecko',
			'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Accept-Language' => 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
			'Accept-Charset' => 'windows-1251,utf-8;q=0.7,*;q=0.7',
		]
	);

	my $file = getcwd () .'/txt/001.mp4';
	my $response = $lwp -> request ($req, $file);	
	# my $response = $lwp -> request ($req);	
	print $response -> code ."\t".$url."\n";
	
	
	# my $content2 = $response -> content;
	# $content2 =~ s/\n+//g;
	
	# my $pattern1 = '<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="(.+?)"';
	# my $work_for_content = work_for_content -> new ($content2); 
	# my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
	# if (defined $work_for_content_result -> [0]) {
		# foreach (@$work_for_content_result) {		
			# my $clear_str = clear_str -> new ($_);
			# $_ = $clear_str -> delete_4 ();
			# $clear_str = undef;					
			# $return -> {VIEWSTATE} = $_;
			# print '$return -> {VIEWSTATE} = '. $return -> {VIEWSTATE} ."\n";
		# }
	# }
	
	return $return;
}


sub get_ppp {
	my $file = getcwd (). '/ip.txt';
	my @file = ();
	open (FILE, $file) or die (print $!);
	while (<FILE>) {
		$_ =~ s/\n+//g;
		$_ =~ s/\t+//g;
		$_ =~ s/\r+//g;
		if ($_ =~ /:\d+/) {
			push (@file, $_);
		}
	}
	close (FILE);
	return shift (@file);
}