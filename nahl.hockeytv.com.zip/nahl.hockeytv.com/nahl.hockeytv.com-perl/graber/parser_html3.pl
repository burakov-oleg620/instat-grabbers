#!/usr/bin/env perl
use strict;
use warnings;
use locale;
use dir_scan_recurce;
use read_text_file; 
use write_text_file_mode_rewrite; 
use Encode qw (encode decode);
use clear_str;
use read_inifile;

use work_mysql_graber;
use work_for_content;
use write_to_txt1;
use write_to_txt2;

use Date::Calc;
use HTML::TreeBuilder::XPath;
use MD5;

use LWP::UserAgent;
use HTTP::Request;
use HTTP::Response;
use HTTP::Cookies;
use URI::Escape;
use HTML::TreeBuilder::XPath;
use LWP::Protocol::http;
use Data::Dumper;
use JSON::XS;

sub get_base_path {
	use Cwd; 
	my $cwd = getcwd ();
	return $cwd;
}


my $read_inifile = read_inifile -> new ('graber.ini'); 
my $host = $read_inifile -> get ('host');	

#����� ��������� �� ��� �����
my $mysql_dbdriver = $read_inifile -> get ('mysql_dbdriver');
my $mysql_host = $read_inifile -> get ('mysql_host');
my $mysql_port = $read_inifile -> get ('mysql_port');
my $mysql_user = $read_inifile -> get ('mysql_user');
my $mysql_user_password = $read_inifile -> get ('mysql_user_password');
if ($mysql_user_password eq ' ') {$mysql_user_password = '';}
my $mysql_base = $read_inifile -> get ('mysql_base');
my $mysql_table = $read_inifile -> get ('mysql_table');


my $lwp = undef;
$lwp = LWP::UserAgent -> new ();
$lwp -> cookie_jar (HTTP::Cookies->new ());
$lwp -> agent ('Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.2.16) Gecko/20110319 Firefox/3.6.16');
$lwp -> timeout (60);
# $lwp -> proxy ('http', 'http://127.0.0.1:8080');


# #������� ���������� �� mysql ����������
# my $work_mysql_graber = work_mysql_graber -> new (
	# $mysql_dbdriver,
	# $mysql_host,
	# $mysql_port,
	# $mysql_user,
	# $mysql_user_password,
	# $mysql_base,
	# $mysql_table
# ); 

# my 	$work_mysql = work_mysql -> new (
		# $mysql_dbdriver,
		# $mysql_host,
		# $mysql_port,
		# $mysql_user,
		# $mysql_user_password,
		# $mysql_base
	# ); 	
	
# my $sql = 'set names utf8';
# $work_mysql -> run_query ($sql);

	

my $workdir1 = get_base_path.'/picture'; 
my $workdir2 = get_base_path.'/txt'; 

my $write_text_file_mode_rewrite1 = undef;
my $write_file1 = $workdir2.'/write_text_file_mode_rewrite3.xls'; 
$write_text_file_mode_rewrite1 = write_text_file_mode_rewrite -> new ($write_file1);

my $count = 0 ;

my $dir_scan_recurce = dir_scan_recurce -> new ($workdir1);
while (my $file1 = $dir_scan_recurce -> get_file ()) {
	my $pattern = 'xml$';
	if ($file1 =~ /$pattern/) {
	
		print ++$count."\n";
		
		my @file1 = ();	
		my $read_text_file = read_text_file -> new ($file1); 
		while (my $str1 = $read_text_file -> get_str ()) {
			my $clear_str = clear_str -> new ($str1); 
			$str1 = $clear_str -> delete_4 ();
			$clear_str = undef;			
			push (@file1, $str1); 
		}
		$read_text_file = undef;
		
		my $content1 = join (' ', @file1); 
		$content1 = entities_decode1 ($content1);
		# $content1 = utf8_to_win1251 ($content1);
		
		# $content1 =~ s/\'/"/g;

		# $content1 =~ s/>\s+</> </g;
		# $content1 =~ s/></> </g;
		# $content1 =~ s/\?//g;
		
		# my $tree = HTML::TreeBuilder::XPath -> new ();
		# $tree -> parse_content ($content1);
		# my $content2 = $tree -> findnodes_as_string ('//div[@class="VacancyDetails_section"]'); 
		# my $content3 = $tree -> findnodes_as_string ('//div[@class="VacancySendResumeContacts_wr"]'); 
		# # my $content4 = $tree -> findnodes_as_string ('//div[@data-qa="resume-block-additional-education"]'); 
		# # my $content5 = $tree -> findnodes_as_string ('//div[@data-qa="resume-block-languages"]'); 
		# # my $content6 = $tree -> findnodes_as_string ('//div[@class="resume-block-container"]'); 
		
		# $tree->delete;
		# $tree = undef;
		
		# my @content2 = split ("\n", $content2);
		# if (scalar (@content2) > 0) {
			# foreach (@content2) {
				# my $clear_str = clear_str -> new ($_); 
				# $_ = $clear_str -> delete_4 ();
				# $clear_str = undef;			
				
				
		
		
		# my $url = undef;
		# my $referer = undef;
		# my $str_for_content = undef;
		# {
			# #URL
			# my $file2 = $file1;
			# $file2 =~ s/^.+\///;
			# my $sql = 'select * from '.$mysql_table.' where `file` = "'.$file2.'"';
			# $work_mysql	-> run_query ($sql); 
			# my @row = $work_mysql -> get_row ();
			# if (scalar (@row) > 0) {
				# foreach (@row) {
					# $url =  $_ -> [3];
					# $referer =  $_ -> [4];
					# $str_for_content = $_ -> [8];
					# $write_to_txt1 -> put ($url);
				# }
			# } else {
				# $write_to_txt1 -> put ('-');
			# }
			# # $write_to_txt1 -> put ($file2);
		# }		
		
		my $pattern1 = '(<tblPossessions>.+?</tblPossessions>)';
		my $work_for_content = work_for_content -> new ($content1); 
		my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
		if (defined $work_for_content_result -> [0]) {
			foreach (@$work_for_content_result) {		
				my $clear_str = clear_str -> new ($_);
				$_ = $clear_str -> delete_4 ();
				$clear_str = undef;		
				my $tbl = $_;
				
				my $pattern1 = '(<tblPlayByPlay>.+?</tblPlayByPlay>)';
				my $work_for_content = work_for_content -> new ($_); 
				my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
				if (defined $work_for_content_result -> [0]) {
					foreach (@$work_for_content_result) {		
						my $clear_str = clear_str -> new ($_);
						$_ = $clear_str -> delete_4 ();
						$clear_str = undef;		
						
						my $write_to_txt1 = write_to_txt1 -> new ();			

						#gameid
						my $id = '';
						my @array = ();
						my $pattern1 = '(<iGameID>\d+</iGameID>)';
						my $work_for_content = work_for_content -> new ($tbl); 
						my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
							$id = $array [0];
						} else {
							$write_to_txt1 -> put ('-');
						}
						
						
						#���� ����
						@array = ();
						$pattern1 = '(<dtGameDate>.+?</dtGameDate>)';
						$work_for_content = work_for_content -> new ($tbl); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}
						
						
						#<strHomeName>
						@array = ();
						$pattern1 = '(<strHomeName>.+?</strHomeName>)';
						$work_for_content = work_for_content -> new ($tbl); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}
						
						#<strAwayName>
						@array = ();
						$pattern1 = '(<strAwayName>.+?</strAwayName>)';
						$work_for_content = work_for_content -> new ($tbl); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}
						
						#<iPrimaryPlayerID>
						@array = ();
						$pattern1 = '(<iPrimaryPlayerID>.+?</iPrimaryPlayerID>)';
						$work_for_content = work_for_content -> new ($_); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}
						
						# <strPrimaryPlayerFName>
						@array = ();
						$pattern1 = '(<strPrimaryPlayerFName>.+?</strPrimaryPlayerFName>)';
						$work_for_content = work_for_content -> new ($_); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}
						
						# <strPrimaryPlayerLName>
						@array = ();
						$pattern1 = '(<strPrimaryPlayerLName>.+?</strPrimaryPlayerLName>)';
						$work_for_content = work_for_content -> new ($_); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}
						
						# <iPrimaryPlayerNumber>
						@array = ();
						$pattern1 = '(<iPrimaryPlayerNumber>.+?</iPrimaryPlayerNumber>)';
						$work_for_content = work_for_content -> new ($_); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}
						
						
						#<iSecondaryPlayerID>
						@array = ();
						$pattern1 = '(<iSecondaryPlayerID>.+?</iSecondaryPlayerID>)';
						$work_for_content = work_for_content -> new ($_); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}
						
						# <strSecondaryPlayerFName>
						@array = ();
						$pattern1 = '(<strSecondaryPlayerFName>.+?</strSecondaryPlayerFName>)';
						$work_for_content = work_for_content -> new ($_); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}
						
						# <strSecondaryPlayerLName>
						@array = ();
						$pattern1 = '(<strSecondaryPlayerLName>.+?</strSecondaryPlayerLName>)';
						$work_for_content = work_for_content -> new ($_); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}

						# <iSecondaryPlayerNumber>
						@array = ();
						$pattern1 = '(<iSecondaryPlayerNumber>.+?</iSecondaryPlayerNumber>)';
						$work_for_content = work_for_content -> new ($_); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}
						
						#<bHome>
						@array = ();
						$pattern1 = '(<bHomeEvent>.+?</bHomeEvent>)';
						$pattern1 = '(<bHome>.+?</bHome>)';
						$work_for_content = work_for_content -> new ($_); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									if ($_ == 0) {
										$_ = 'false';
									} else {
										$_ = 'true';
									}
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}

						
						# <iTeamIDA>
						@array = ();
						$pattern1 = '(<iTeamIDA>.+?</iTeamIDA>)';
						$work_for_content = work_for_content -> new ($tbl); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}
						
						
						#<iTeamIDB>
						@array = ();
						$pattern1 = '(<iTeamIDB>.+?</iTeamIDB>)';
						$work_for_content = work_for_content -> new ($tbl); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}

						#<strHomeShort>
						@array = ();
						$pattern1 = '(<strHomeShort>.+?</strHomeShort>)';
						$work_for_content = work_for_content -> new ($tbl); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}

						#<strAwayShort>
						@array = ();
						$pattern1 = '(<strAwayShort>.+?</strAwayShort>)';
						$work_for_content = work_for_content -> new ($tbl); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}
							

						#<strString>
						@array = ();
						$pattern1 = '(<strString>.+?</strString>)';
						$work_for_content = work_for_content -> new ($_); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}
						
						my %league = (
							1 => 'NBA', 
							2 => 'WNBA', 
							5 => 'College Men', 
							6 => 'College Women',
							7 => 'FIBA - National Teams',
							8 => 'Summer League',
							9 => 'NBA Pre-Draft Camp',
							10 => 'NBA D-League', 
							28 => 'International', 
							30 => 'All-Star', 
						);
						
						
						#<iLeagueID>
						my $league = '';
						@array = ();
						$pattern1 = '(<iLeagueID>.+?</iLeagueID>)';
						$work_for_content = work_for_content -> new ($content1); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
								
									if (exists ($league {$_})) {
										push (@array , $league {$_});
									}
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
							$league = $array[0];
						} else {
							$write_to_txt1 -> put ('-');
						}
						
						
						#gender
						@array = ();
						if ($league eq 'WNBA') {
							push (@array, 2);
						}
							
						if ($league eq 'College Women') {
							push (@array, 2);
						}

						if ($league eq 'College Men') {
							push (@array, 1);
						}
						
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
							$league = $array[0];
						} else {
							$write_to_txt1 -> put ('0');
						}
						
						
						#<arrString>
						@array = ();
						$pattern1 = '(<arrString>.+?</arrString>)';
						$work_for_content = work_for_content -> new ($_); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}
						
						
						############�������������� ������
						#$tbl
						# <arrPlayString>
						@array = ();
						$pattern1 = '(<arrPlayString>.+?</arrPlayString>)'; 
						$work_for_content = work_for_content -> new ($tbl); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
								
								my @temp = split (',',$_);
								if (scalar (@temp) > 0) {
									foreach (@temp) {
										my $clear_str = clear_str -> new ($_);
										$_ = $clear_str -> delete_3_s ();
										$_ = $clear_str -> delete_4 ();
										$clear_str = undef;		
									}
									push (@array , $temp[0]);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}
						
						
						#<strPlayerFName>
						@array = ();
						$pattern1 = '(<strPlayerFName>.+?</strPlayerFName>)';
						$work_for_content = work_for_content -> new ($tbl); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}
						
						#<strPlayerLName>
						@array = ();
						$pattern1 = '(<strPlayerLName>.+?</strPlayerLName>)'; 
						$work_for_content = work_for_content -> new ($tbl); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}
						
						
						#<iPlayerNumber>
						@array = ();
						$pattern1 = '(<iPlayerNumber>.+?</iPlayerNumber>)';
						$work_for_content = work_for_content -> new ($tbl); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}
						
						# <strPlayString>
						@array = ();
						$pattern1 = '(<strPlayString>.+?</strPlayString>)';
						$work_for_content = work_for_content -> new ($tbl); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}
						

						# <arrPlayString>
						@array = ();
						$pattern1 = '(<arrPlayString>.+?</arrPlayString>)'; 
						$work_for_content = work_for_content -> new ($tbl); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}
						
						#<bHomeEvent>
						@array = ();
						$pattern1 = '(<bHomeEvent>.+?</bHomeEvent>)';
						$work_for_content = work_for_content -> new ($tbl); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}
							
						
						@array = ();
						$pattern1 = '(<iSynergyPlayByPlayID>.+?</iSynergyPlayByPlayID>)';
						$work_for_content = work_for_content -> new ($tbl); 
						$work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
						if (defined $work_for_content_result -> [0]) {
							foreach (@$work_for_content_result) {		
								my $clear_str = clear_str -> new ($_);
								$_ = $clear_str -> delete_3_s ();
								$_ = $clear_str -> delete_4 ();
								$clear_str = undef;		
								$_ = entities_decode ($_);	
								
								$_ =~ s/^\s+//;
								$_ =~ s/\s+$//;
								$_ =~ s/^\s+$//;
										
								if ($_ ne '') {
									push (@array , $_);
								}
							}
						} 
						
						if (scalar (@array) > 0) {
							my $str = join ('||', @array);
							$write_to_txt1 -> put ($array[0]);
						} else {
							$write_to_txt1 -> put ('-');
						}
							
						my $str = $write_to_txt1 -> get ();
						$write_text_file_mode_rewrite1 -> put_str ($str."\n");														
						$write_to_txt1 = undef;								
						
					}
				}
			}
		} 
		
	
		
		# my $str = $write_to_txt1 -> get ();
		# $write_text_file_mode_rewrite1 -> put_str ($str."\n");														
		# $write_to_txt1 = undef;								
	}						
	
} #������ ����� �� ��������
$write_text_file_mode_rewrite1 = undef;


sub utf8_to_win1251 {
	use Encode qw (encode decode); 
	my $str = shift;
	$str = encode ('cp1251', decode ('utf8', $str)); 
	return $str;
}

sub entities_decode {
	use HTML::Entities;
	my $str = shift;
	#����� ������� ������ ����� ������� decode � ����� ���������
	$str = decode ('cp1251', $str);
	$str = decode_entities ($str);
	$str = encode ('cp1251', $str);
	return $str;
}

sub entities_decode1 {
	use HTML::Entities;
	my $str = shift;
	#����� ������� ������ ����� ������� decode � ����� ���������
	$str = decode ('utf8', $str);
	$str = decode_entities ($str);
	$str = encode ('utf8', $str);
	return $str;
}

sub get_date {
	my $time = shift;
	use Date::Calc qw (Time_to_Date Date_to_Time);
	my ($year,$month,$day, $hour,$min,$sec) = Time_to_Date ($time);
	# my $str = $year .'.'.$month .'.'. $day;
	# my $str = $year .'-'.$month ;
	
	# my @date = split ('\.', $str);
	my @date = ();
	push (@date, $year);
	push (@date, $month);
	push (@date, $day);
	
	if (scalar (@date) > 0) {
		foreach (@date) {
			while (length ($_) < 2) {
				$_ = '0'.$_;
			}
		}
	}
	my $str = $date[0] .'-'.$date[1];
	return $str;
}	

sub json_str {
	my $str = shift;
	$str =~ s/\n+/ /g;
	$str =~ s/\r+/ /g;
	$str = encode ('cp1251', $str);
	return $str;
}
