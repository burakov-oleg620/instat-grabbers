#!/usr/bin/env perl
#��������� � XLS
use strict;
use warnings;
use locale;
use dir_scan_recurce;
use read_text_file; 
use write_text_file_mode_rewrite; 
use clear_str;
use delete_duplicate_from_array; 
use read_inifile;
use work_mysql;
use date_time;
use File::Path;
use File::Copy;
use Cwd qw (realpath);

use Encode qw (encode decode);
use Spreadsheet::WriteExcel;
use Date::Calc qw (Time_to_Date Date_to_Time);


my $read_inifile = read_inifile -> new ('graber.ini'); 
my $host = $read_inifile -> get ('host');

#����� ��������� �� ��� �����
my $workdir1 = get_base_path ().'/txt'; 
my $workdir2 = get_base_path ().'/out'; 
my $workdir3 = get_base_path ().'/out_xls'; 

my $file1 = $workdir1.'/write_text_file_mode_rewrite4.xls'; 
my $file2 = $workdir1.'/write_text_file_mode_rewrite5.xls'; 

my $count = 0 ;
my $dir_scan_recurce = dir_scan_recurce -> new ($workdir2);
while (my $file1 = $dir_scan_recurce -> get_file ()) {
	my $pattern = 'xls$';
	if ($file1 =~ /$pattern/) {
	
		print ++$count."\n";
		
		my $file2 = $file1;
		$file2 =~ s/^.+\///;
		$file2 = $workdir3 .'/'.$file2;

		#�������� XLS �����  
		my $workbook = Spreadsheet::WriteExcel->new($file2);
		my $worksheet = $workbook->add_worksheet();

		if (-f $file1) {

			my $count = 0; 
			my $row = 0;
			my $read_text_file1 = read_text_file -> new ($file1); 
			while (my $str1 = $read_text_file1 -> get_str ()) {
				print ++$count."\n";
				
				my $col = 0; 
				if ($str1 =~ /\t/) {
					my $temp1 = []; my $pattern1 = "\t"; @$temp1 = split ($pattern1, $str1); 
					
					my $temp1_count = 0;
					foreach (@$temp1) {
						my $clear_str = clear_str -> new ($_); 
						$_ = $clear_str -> delete_4 ();
						$clear_str = undef;
						$_ =~ s/^\=+//;
						$_ =~ s/\=+$//;
						
						if ($temp1_count == 14) {
							$_ =~ s/=/\n/g;
						}
						
						if ($temp1_count == 16) {
							$_ =~ s/=/\n/g;
						}
						
						if ($temp1_count == 17) {
							$_ =~ s/=/\n/g;
						}
						
						if ($temp1_count == 18) {
							$_ =~ s/=/\n/g;
						}
						
						$_ = decode ('cp1251', $_);
						$worksheet->write($row, $col, $_);
						
						$col++;				
						
						$temp1_count++;
					}
					$row++;
					
				}
			}
			$read_text_file1 = undef;
			
		}
		$workbook = undef;
	}
}

$dir_scan_recurce = undef;

# if (-f $file2 and -f $file1) {
	# # my $date = date_time -> date ();
	# # my $time = date_time -> time ();
	# # my @date = split ('\.', $date); @date = reverse (@date); 
	# # my @time = split ('\.', $time); $time = join ('-', @time);
	# # $date = join ('-', @date) .'_'.$time;

	# my $workdir_archive = getcwd () .'/../archive';
	# $workdir_archive = realpath ($workdir_archive);

	# my $file3 = $file2;
	# $file3 =~ s/^.+\///;
	# $file3  = $workdir_archive .'/'. $file3 ;

	# # my ($year,$month,$day, $hour,$min,$sec) = Time_to_Date (time () + 4*3600);	
	# # my $file3 = $year.'-'.$month.'-'.$day.'-'. $hour.'-'.$min.'-'.$sec.'-'.$host.'.xls'; 
	# # $file3 = $workdir_archive .'/'.$file3;
		
	# print $file2 ."\n";
	# print $file3 ."\n";
	# copy ($file2, $file3) or die;
# }


sub get_base_path {
	use Cwd; 
	my $cwd = getcwd ();
	return $cwd;
}



  


