#!/usr/bin/perl
use strict;
use warnings;
use locale;
use dir_scan_recurce;
use read_text_file; 
use write_text_file_mode_rewrite; 
use clear_str;
use delete_duplicate_from_array; 
use read_inifile;
use url_to_file;
use Encode qw (encode decode);
use Tie::IxHash;
use work_for_content;
use File::Path;
use File::Copy;
use Cwd;

use LWP::UserAgent;
use HTTP::Request;
use HTTP::Response;
use HTTP::Cookies;
use URI::Escape;
use HTML::TreeBuilder::XPath;
use URI::URL;
use URI::Escape;
use JSON::XS;
use IO::Socket::SSL qw();
use Mozilla::CA;


#Читаю установки из ини файла
my $read_inifile = read_inifile -> new ('graber.ini'); 
my $mysql_dbdriver = $read_inifile -> get ('mysql_dbdriver');
my $mysql_host = $read_inifile -> get ('mysql_host');
my $mysql_port = $read_inifile -> get ('mysql_port');
my $mysql_user = $read_inifile -> get ('mysql_user');
my $mysql_user_password = $read_inifile -> get ('mysql_user_password');
if ($mysql_user_password eq ' ') {$mysql_user_password = '';}
my $mysql_base = $read_inifile -> get ('mysql_base');
my $mysql_table = $read_inifile -> get ('mysql_table');

my $threads_all = $read_inifile -> get ('threads_all'); 
my $sleep1 = $read_inifile -> get ('sleep1'); 
my $sleep2 = $read_inifile -> get ('sleep2'); 
my $sleep3 = $read_inifile -> get ('sleep3'); 

my $host = $read_inifile -> get ('host');	
my $set_proxy = $read_inifile -> get ('set_proxy');
my $count_all = $read_inifile -> get ('count_all');	


#создаю экземпляр броузера
my $lwp = undef;
$lwp = LWP::UserAgent -> new ();
$lwp -> cookie_jar (HTTP::Cookies->new ());
$lwp -> agent ('Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.2.16) Gecko/20110319 Firefox/3.6.16');
$lwp -> timeout (180);
# $lwp->ssl_opts( verify_hostnames => 0 ,SSL_verify_mode => 0x00);
$lwp ->ssl_opts( SSL_ca_file => Mozilla::CA::SSL_ca_file() );

# $lwp -> proxy ('http', 'http://127.0.0.1:8080');



sub get_base_path {
	use Cwd; 
	my $cwd = getcwd ();
	return $cwd;
}

my $workdir1 = get_base_path.'/txt'; 
my $workdir2 = get_base_path.'/picture'; 
my $workdir3 = get_base_path.'/media'; 

my $file1 = $workdir1.'/1.csv'; 

my $count = 0;
my @read_text_file1 = ();
my %header = (); 
tie (%header, 'Tie::IxHash'); #чтобы было по мере добавления
my %file1 = ();

# my $result_get_1 = get_1 ();
get_1 ();
# post ();

# get_2 ();

sub get_1  {
	my $url = ' http://synergygrid.smartarrow.aware.net/wms/2/484055/gameon/224196185.mp4';
	my $request = HTTP::Request -> new (
		'GET' => $url,
		[
			#'Host' => 'video.phoenixcontact.com',
			'User-Agent' => 'Mozilla/5.0 (Windows NT 6.1; rv:47.0) Gecko/20100101 Firefox/47.0',
			'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Accept-Language' => 'ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
			# 'Accept-Charset' => 'windows-1251,utf-8;q=0.7,*;q=0.7',
		]
	);

	my $file = getcwd () .'/picture/1.mp4';
	my $response = $lwp -> request ($request, $file);
	
	print $response -> code ."\t". $url."\n";
	my $content1 = $response -> content;
	$content1 =~ s/\n+//g;
	
	return 1;
}


# Host=video.phoenixcontact.com
# User-Agent=Mozilla/5.0 (Windows NT 6.1; rv:47.0) Gecko/20100101 Firefox/47.0
# Accept=text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
# Accept-Language=ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3
# Accept-Encoding=gzip, deflate, br
# Connection=keep-alive

sub get_2  {
	my $url = 'http://dl.drivemax.me/q.php?file=0BNzSa-XZ1qrd5hWiaU1iY-J440lFMtV7YY5ec9KHH5b-ZxtHN_KE_yOpUeB0KSJCGSOXH6X5ADFmVGg4aHErFDK_C55evEq52DHR6z8v2cuK2swsDQ-niixbDPKGZbZczfkuwlm4yRLKLC8Ft8iYJK4GMWv8cmugZmVYwmjLDWUf67zUQumy1Jjrd3pndwyadtBuN7KsGr5tMH84UPGcxzzfWo9hqNP5WIE-wx1sv289VAAwYrTlKxI1rCguKkN';
	my $useragent = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.2.16) Gecko/20110319 Firefox/3.6.16';
	my $request = HTTP::Request -> new (
		'GET' => $url,
		[
			'User-Agent' => 'Mozilla/5.0 (Windows NT 6.1; rv:47.0) Gecko/20100101 Firefox/47.0',
			'Accept' => 'audio/webm,audio/ogg,audio/wav,audio/*;q=0.9,application/ogg;q=0.7,video/*;q=0.6,*/*;q=0.5',
			'Accept-Language' => 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
			# 'Range' => 'bytes=0-',
			'Referer' => 'http://drivemax.me/',
		]
	);

	my $file = getcwd () .'/picture/1.mp3';
	my $response = $lwp -> request ($request, $file);
	
	print $response -> code ."\t". $url."\n";
	my $content1 = $response -> content;
	$content1 =~ s/\n+//g;
	
	return 1;
}


sub post {
	# my $url = 'https://www.phoenixcontact.com/online/portal/ru/pxc/product_detail_page/!ut/p/z1/tZTdbpswAIWfhkvHBmwDlymJwrK0I0kpgRtksKm8hZ8QKN3bj3STql4E5EVBSMboO8cHi2MYwwOMS_YmX1krq5Idh3kU08Q2vrveCuuPaOUv0RbZ27WzXHjUo_AFRg8w0pBz3rpzGI7imMJ43O2vHl255mhKHw166yrgY7iHkfsZdwKnajhRwy0lnKhlJ2rZiVp2opZ9o5Z9oxZmo_apC6SGGxd88YmvYSzTYtZnxQzN6vdsVjcV77I24aJl8pjU7FVcaiN_nk7xHMZZVbbivYWHpms6DfUi1VDBZKmhf8Kzho7y3H4Ih-dt8O3pOfF_hMtd4gPDAMgESB9uDeXUTEnKTECN4SUWJgcOIxjoPOfYpJZNMnOoUDzakksJP4CRlu2bLtkFiX9wd8HE_jxaMHyToodBWTXFcGLsL_Z1JjmMODUFT3MOMhtzgJGTgzRzdICpxR1hYp7ZOvTQxApLfOMKE_b0rvbBfe31-26OTu5q792afj36q1PzliKeOlkOk6oXTVL_RxHrovwtAcuLktRXhxD8yhcPT2Dlpnb_nBdfh_APGbf3gw!!/p0/IZ7_82KCHG41M0GPE0Q08QJ9EDH657=CZ6_82KCHG41M0GPE0Q08QJ9EDH6H6=LA0=EdownloadId!3974722=action!downloadFile==/#Z7_82KCHG41M0GPE0Q08QJ9EDH657';
	my $url = 'https://www.phoenixcontact.com/online/portal/ru/pxc/product_detail_page/!ut/p/z1/5VfNbptAEH6VXDiud4EFw9HCVhzHSUlsN4YLAnaxNuXHwWCS3NJLj732MXqMKrV9BfxGXbAjxVFjR43cC2gEu7Pzzew3u4M00IZTaMfuks3cjCWxG_K5ZauOJp0a_WMsnqFjs4cukHYx0HvdvtpX4UdoQ3tBQ-pnlBhuRmdJegetznBYLWSuBy2xGs19_xO0TCBJAMkAiVwqdci81K0AaZ7mtR0j0JJ0hBW9Xc2TwDSM078gM5aFFFrlt9XD6nP5a_Wl_Fk-lj_Kx6Pyd_nIVd8rxerrETi6mJycjzEwRwISO4aAJNzlb7ElC2hk8PWncFc7yWIV2rtzscajV54O2oe3OL79qoGJ4ajOEAlCN57l7ozTrxXJglXHtZ6l1KdsSdPN2lvTniYk9ysvY3qbrbFvOVUSRAl52seLo9v47NLMZeHiJKPRyTODPWTVJpFVmkS23SCySpNqVmlSzSpNqlmlSTU7bFLNDpt0jYdN-kF1UZPISpys1YOWgOLcKjpwAG3mRa3Cj1qoNb_1WxvvDqndO_MqHby5Ydc3N3YH2n4SZxWTacVQQAX1BBS5LBbQBrgQUMgWWQ3k47qlcMwPV71LZytdAgpU2VM8VwaqxJWYygToroKBSAKCZbWtKb7MWwV7ZzdQNRu1wY5uYpTmzuXEMafG5WRPfs54c7NktICTOEkj3tetr4ZfHQFRZUq8gABfwwRgpAfA83URYLVNdCpj4msi7KM9EXr4nRH2uFcP6n5yWPfiYZMjKgd133_v7gc7r7oqv6cQb3IW80lS0NSZ_0MhzqNIkzcCJtP7MfXun0vwbH0tzvm5stwS4G5jqKch-QVMmS9fwP5rKO1ORtfYGiyLYhxEhqdtf-6KP-ccPsc!/p0/IZ7_82KCHG41M0GPE0Q08QJ9EDH657=CZ6_82KCHG41M0GPE0Q08QJ9EDH6H6=LA0=EdownloadId!3974722=action!downloadFile==/#Z7_82KCHG41M0GPE0Q08QJ9EDH657';
	
	my $postdata = 'category=0&language=0';

	push (@{ $lwp->requests_redirectable }, 'POST');
	my $req = HTTP::Request -> new (
	'POST' => $url,
		[
			'User-Agent' => 'User-Agent=Mozilla/5.0 (Windows NT 6.1; rv:47.0) Gecko/20100101 Firefox/47.0',
			'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Accept-Language' => 'ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
			'Referer' => 'https://www.phoenixcontact.com/online/portal/ru/?uri=pxc-oc-itemdetail:pid=2904597&library=ruru&pcck=P-22-03-01-01&tab=1&selectedCategory=ALLp0/IZ7_82KCHG41M0GPE0Q08QJ9EDH657=CZ6_82KCHG41M0GPE0Q08QJ9EDH6H6=LA0=EdownloadId!3974722=action!downloadFile==/',
			'X-Requested-With' => 'XMLHttpRequest',
			'Content-Type' => 'application/x-www-form-urlencoded',
		]
	);

	$req -> content ($postdata);
	my $file = getcwd () .'/picture/1.pdf';
	my $res = $lwp -> request ($req, $file); 
	# my $res = $lwp -> request ($req); 
	print $res -> code ."\t" . $url ."\n";
	
	# my $json = decode_json ($res -> content);

	my $sleep = Random ($sleep2, $sleep3); 
	sleep $sleep;		
	
	return 1;
}

sub Random {
	my $from = shift;
	my $to = shift;
	my $random = $from + rand(($to - $from));
	return $random;
}
