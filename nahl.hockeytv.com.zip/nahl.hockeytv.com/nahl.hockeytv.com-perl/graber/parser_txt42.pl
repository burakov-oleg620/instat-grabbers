#!/usr/bin/env perl
use strict;
use warnings;
use dir_scan_recurce;
use read_text_file; 
use write_text_file_mode_rewrite; 
use clear_str;
use delete_duplicate_from_array; 
use read_inifile;
use url_to_file;
use Encode qw (encode decode);
use date_time;
use MD5;
use File::Copy;
use File::Path;

use work_mysql;
use Date::Calc qw (Time_to_Date Date_to_Time);
use work_mysql_agregator;
use work_mysql_agregator2;
use MD5;
use Cwd qw (realpath);
use work_for_content;
use write_to_txt1;
use write_to_txt2;
use JSON::XS;
use Data::Dumper;
use locale;
use Tie::IxHash;
use LWP::UserAgent;
use HTTP::Request;
use HTTP::Response;
use HTTP::Cookies;


sub get_base_path {
	use Cwd; 
	my $cwd = getcwd ();
	return $cwd;
}

my $read_inifile = read_inifile -> new ('graber.ini'); 
my $host = $read_inifile -> get ('host');	
#����� ��������� �� ��� �����
my $mysql_dbdriver = $read_inifile -> get ('mysql_dbdriver');
my $mysql_host = $read_inifile -> get ('mysql_host');
my $mysql_port = $read_inifile -> get ('mysql_port');
my $mysql_user = $read_inifile -> get ('mysql_user');
my $mysql_user_password = $read_inifile -> get ('mysql_user_password');
if ($mysql_user_password eq ' ') {$mysql_user_password = '';}
my $mysql_base = $read_inifile -> get ('mysql_base');
my $mysql_table = $read_inifile -> get ('mysql_table');
my $content_table = $read_inifile -> get ('content_table');

my $lwp = undef;
$lwp = LWP::UserAgent -> new ();
$lwp -> cookie_jar (HTTP::Cookies->new ());
$lwp -> agent ('Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.2.16) Gecko/20110319 Firefox/3.6.16');
$lwp -> timeout (60);
# $lwp -> proxy ('http', 'http://127.0.0.1:8080');


my $workdir1 = get_base_path.'/txt'; 
my $workdir2 = get_base_path.'/picture'; 

my $file1 = $workdir1.'/write_text_file_mode_rewrite1.xls'; 
my $file2 = $workdir1.'/write_text_file_mode_rewrite44.xls'; 
my $file3 = $workdir1.'/write_text_file_mode_rewrite444.xls'; 


# my ($year,$month,$day, $hour,$min,$sec) = Time_to_Date (time () + 4*3600);
# my $file2 = $workdir1.'/write_text_file_mode_rewrite2.xls'; 
# my $file2 = $workdir1.'/'.$year.'-'.$month.'-'.$day.'-'. $hour.'-'.$min.'-'.$sec.'-'.$host.'.xls'; 


# my 	$work_mysql = work_mysql -> new (
		# $mysql_dbdriver,
		# $mysql_host,
		# $mysql_port,
		# $mysql_user,
		# $mysql_user_password,
		# $mysql_base
	# ); 	

# my $sql = 'SET NAMES CP1251';
# $work_mysql -> run_query ($sql); 


# #������� ���������� �� mysql ����������
# my $work_mysql_agregator = work_mysql_agregator -> new (
	# $mysql_dbdriver,
	# $mysql_host,
	# $mysql_port,
	# $mysql_user,
	# $mysql_user_password,
	# $mysql_base,
	# $read_inifile -> {agregator}
# ); 

# if ($read_inifile -> {clear_agregator} == 1) {
	# $work_mysql_agregator -> drop ();
# }
# $work_mysql_agregator -> create ();		
# # $work_mysql_agregator2 -> clear ($read_inifile -> {clear_agregator_time});

# #������� ���������� �� mysql ����������
# my $work_mysql_agregator2 = work_mysql_agregator2 -> new (
	# $mysql_dbdriver,
	# $mysql_host,
	# $mysql_port,
	# $mysql_user,
	# $mysql_user_password,
	# $mysql_base,
	# $read_inifile -> {agregator2}
# ); 

# if ($read_inifile -> {clear_agregator} == 1) {
	# $work_mysql_agregator2 -> drop ();
# }
# $work_mysql_agregator2 -> create ();		
# # $work_mysql_agregator2 -> clear ($read_inifile -> {clear_agregator_time});	


my $count = 0;
my @read_text_file1 = ();
my %file1 = ();
my %file2 = ();

# {
	# my $workdir1 = getcwd () .'/xls';
	# my $dir_scan_recurce = dir_scan_recurce -> new ($workdir1);
	# while (my $file1 = $dir_scan_recurce -> get_file ()) {
		# print ++$count."\n";
		
		# my $pattern = 'xls$';
		# if ($file1 =~ /$pattern/) {	

			# my $read_text_file1 = read_text_file -> new ($file1); 
			# while (my $str1 = $read_text_file1 -> get_str ()) {
				# print ++$count."\n";
				
				# if ($str1 =~ /\t/) {
					# my $temp1 = []; my $pattern1 = "\t"; @$temp1 = split ($pattern1, $str1); 
					
					# # print '*' . scalar (@$temp1) ."\n";
					# if (scalar (@$temp1) > 1) {
						# foreach (@$temp1) {
							# my $clear_str = clear_str -> new ($_);
							# $_ = $clear_str -> delete_4 ();
							# $clear_str = undef;											
						# }
						
						# my @temp = split (/\s+/, $temp1 -> [1]);
						# foreach (@temp) {
							# my $clear_str = clear_str -> new ($_);
							# $_ = $clear_str -> delete_4 ();
							# $clear_str = undef;											
						# }
						# $temp1 -> [1] = join (' ', @temp);
						
						# $file1 {$temp1 -> [1]} = $temp1;
					# }
				# }
			# }
			
			# $read_text_file1 = undef;
		# }
	# }
# }


my $score_home = 0;
my $score_away = 0;


my $read_text_file2 = read_text_file -> new ($file2); 
while (my $str1 = $read_text_file2 -> get_str ()) {
	print ++$count."\n";
	
	if ($str1 =~ /\t/) {
		my $temp1 = []; my $pattern1 = "\t"; @$temp1 = split ($pattern1, $str1); 
		
		# print '*' . scalar (@$temp1) ."\n";
		if (scalar (@$temp1) > 1) {
			
			#����������� ��� ����, ����� ������ ������ ������
			foreach (@$temp1) {
				my $clear_str = clear_str -> new ($_);
				$_ = $clear_str -> delete_4 ();
				$clear_str = undef;											
			}
			
			
			if ($temp1 -> [0] ne 'game_id') {
			
				my $str = join ("\t", @$temp1);
				# push (@read_text_file1, $str);
				
				my $get_instat_id_result = get_instat_id ($temp1 -> [0]);
				foreach (@$get_instat_id_result) {
					push (@$temp1,  $_ -> {instat_id});
				}
				
				#��� ����������� � #41
				# my $file = getcwd () .'/pictura/'. $temp1 -> [0] .'.xml';
				
				# if (-f $file) {
				
					# my @file = ();
					# my $read_text_file3 = read_text_file -> new ($file); 
					# while (my $str1 = $read_text_file3 -> get_str ()) {
						# my $clear_str = clear_str -> new ($str1);
						# $str1 = $clear_str -> delete_4 ();
						# $clear_str = undef;											
						# push (@file, $str1);
					# }
					# my $content1 = join ('', @file);
					
					# my $AwayScore = undef;
					# my $HomeScore = undef;
					
					# my $pattern1 = '(<AwayScore>.+?</AwayScore>)';
					# my $work_for_content = work_for_content -> new ($content1); 
					# my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
					# if (defined $work_for_content_result -> [0]) {
						# foreach (@$work_for_content_result) {		
							# my $clear_str = clear_str -> new ($_);
							# $_ = $clear_str -> delete_3_s ();
							# $_ = $clear_str -> delete_4 ();
							# $clear_str = undef;		
							# $_ =~ s/^\s+//;
							# $_ =~ s/\s+$//;
							# $AwayScore = $_;
						# }
					# }
					
					# $pattern1 = '(<HomeScore>.+?</HomeScore>)';
					# $work_for_content = work_for_content -> new ($content1); 
					# $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
					# if (defined $work_for_content_result -> [0]) {
						# foreach (@$work_for_content_result) {		
							# my $clear_str = clear_str -> new ($_);
							# $_ = $clear_str -> delete_3_s ();
							# $_ = $clear_str -> delete_4 ();
							# $clear_str = undef;		
							# $_ =~ s/^\s+//;
							# $_ =~ s/\s+$//;
							# $HomeScore = $_;
						# }
					# }
					
					# if (defined ($AwayScore) and defined ($HomeScore)) {

						# $temp1 -> [13] = $AwayScore;
						# $temp1 -> [12] = $HomeScore;
					# }
					
					# $read_text_file3 = undef;
				# }
				
				$file2 {$temp1 -> [0]} = $temp1;
				
			}
		}
	}
}
$read_text_file2 = undef;

#������� ����, ������ ����� ��� �� ���� � �������.
if (scalar (keys(%file2)) > 0) {

	# my $delete_duplicate_from_array = delete_duplicate_from_array -> new (@read_text_file1);
	# @read_text_file1 = $delete_duplicate_from_array -> do ();
	# $delete_duplicate_from_array = undef;
	# @read_text_file1 = sort (@read_text_file1);
	
	my @headers = (
		'game_id',
		'date',
		'team_a_name',
		'team_a_short_name',
		'team_a_abbr',
		'team_a_id',
		'team_b_name',
		'team_b_short_name',
		'team_b_abbr',
		'team_b_id',
		'season',
		'league',
		'score_home',
		'score_away',
		'game_instat_id',
	);	
	
	# my $write_text_file_mode_rewrite = write_text_file_mode_rewrite -> new ($file2);
	# $write_text_file_mode_rewrite -> put_str (join ("\t", @headers)."\n");
	
	# foreach (@read_text_file1) {
		# print ++$count."\n";
		# $write_text_file_mode_rewrite -> put_str ($_."\n");
	# }
	
	
	#������� ����� �� ��������.
	if (scalar (keys (%file2) > 0)) {
		my $write_text_file_mode_rewrite = write_text_file_mode_rewrite -> new ($file3);
		$write_text_file_mode_rewrite -> put_str (join ("\t", @headers)."\n");
		
		foreach (keys (%file2)) {
			my $str = join ("\t", @{$file2 {$_}});
			$write_text_file_mode_rewrite -> put_str ($str."\n");
			
			my $insert2 = [];
			my $insert = {};
			tie (%$insert, 'Tie::IxHash');
			
			$insert -> {id} = $file2 {$_} -> [0];
			$insert -> {match_date} = $file2 {$_} -> [1];
			
			$insert -> {team_a_name} = $file2 {$_} -> [2];
			$insert -> {team_a_short_name} = $file2 {$_} -> [3];
			$insert -> {team_a_abbr} = $file2 {$_} -> [4];
			$insert -> {team_a_id} = $file2 {$_} -> [5];
			
			$insert -> {team_b_name} = $file2 {$_} -> [6];
			$insert -> {team_b_short_name} = $file2 {$_} -> [7];
			$insert -> {team_b_abbr} = $file2 {$_} -> [8];
			$insert -> {team_b_id} = $file2 {$_} -> [9];
			
			$insert -> {season} = $file2 {$_} -> [10];
			$insert -> {league} = $file2 {$_} -> [11];
			my %league = (
				# 1 => 'NBA', 
				# 2 => 'WNBA', 
				# 5 => 'College Men', 
				# 6 => 'College Women',
				# 7 => 'FIBA - National Teams',
				# 8 => 'Summer League',
				# 9 => 'NBA Pre-Draft Camp',
				# 10 => 'NBA D-League', 
				# 28 => 'International', 
				# 30 => 'All-Star', 
				
				'NBA' => 1, 
				'WNBA' => 2, 
				'College Men' => 5,  
				'College Women' => 6,
				'FIBA - National Teams' => 7,
				'Summer League' => 8, 
				'NBA Pre-Draft Camp' => 9,
				'NBA D-League' => 10, 
				'International' => 28,
				'All-Star' => 30, 
			);
			if (exists ($league {$insert -> {league}})) {
				$insert -> {league_id} = $league {$insert -> {league}};
			}
			
			$insert -> {score_home} = $file2 {$_} -> [12];
			$insert -> {score_away} = $file2 {$_} -> [13];
			
			push (@{$insert2}, $insert);
			my $encode_json = encode_json ($insert2);
			
			# print $encode_json ."\n";
			# foreach (keys (%$insert)) {
				# print $_. "\t". $insert -> {$_} ."\n";
			# }

			print $encode_json ."\n";
			post ($encode_json);
			
			
		}
		$write_text_file_mode_rewrite = undef;
	}
	
	# $write_text_file_mode_rewrite = undef;
}


sub entities_decode {
	use HTML::Entities;
	my $str = shift;
	#����� ������� ������ ����� ������� decode � ����� ���������
	$str = decode ('cp1251', $str);
	$str = decode_entities ($str);
	$str = encode ('cp1251', $str);
	return $str;
}

sub get_file_type_2 {
	my $file = shift;
	my %file = ();
	open (FILE, $file) or die;
	while (<FILE>) {
		chomp;
		$_ = encode ('cp1251', decode ('utf8', $_));
		if ($_ =~ /;/) {
			my $str = [];
			@$str = split (";",$_); 
			if (scalar (@$str) == 2) {
				$file{$str -> [1]} = $str -> [0];
			}
		}
	}
	return %file;
}


sub get_file_type_3 {
	my $file = shift;
	my %file = ();
	open (FILE, $file) or die;
	while (<FILE>) {
		chomp;
		$_ = encode ('cp1251', decode ('utf8', $_));
		if ($_ =~ /;/) {
			my $str = [];
			@$str = split (";",$_); 
			if (scalar (@$str) == 3) {

				$str->[2] =~ s/\"//g; 
				$str->[2] = lc ($str->[2]); 
				# print $str->[2] ."\n";
				# print $str->[0] ."\n";				
				$file{$str -> [2]} = $str -> [0];
			}
		}
	}
	return %file;
}


sub post {
	my $postdata = shift;
	
	my $res = 0;	
	do {
	
		my $key_import2 = '22812357092873478234729374';
		my $url = 'http://data.instatfootball.tv/api/import2?key='.$key_import2.'&method=UpdateBasketballSynergyMatches';	
		# my $postdata = 'firstsec=1&email=is.fin.dept%40gmail.com&pwd=basket55&women=0&B1=Login';

		push (@{ $lwp->requests_redirectable }, 'POST');
		my $req = HTTP::Request -> new (
		'POST' => $url,
			[
				# 'User-Agent' => 'Mozilla/5.0 (Windows NT 5.1; rv:11.0) Gecko/20100101 Firefox/11.0',
				# 'Accept-Language' => 'ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
				# 'Referer' => 'http://basketball.eurobasket.com/player/Andrey-Vorontsevich/Russia/CSKA-Moscow/71366',
				# 'Content-Type' => 'application/json',
				
				'Accept' => '*/*',
				'Content-Type' => 'multipart/form-data; boundary=----------------------------4b5789fa8d3f',
				
			]
		);
		
		
		my $str = 
'------------------------------4b5789fa8d3f
Content-Disposition: form-data; name="json"

'.$postdata.'
------------------------------4b5789fa8d3f--';

		$req -> content ($str);
		
		my $file = getcwd () .'/txt/matches.html';
		$res = $lwp -> request ($req, $file); 
		print $res -> code ."\t" . $url ."\n";
		$res = $res -> code;
		
		#sleep 1;
		
	} while ($res != 200);
	
	# my $sleep = Random ($sleep2, $sleep3); 
	# sleep $sleep;		
	
	return 1;
}

sub get_instat_id {
	my $match_id = shift;
	
	my $response_code = 0;
	my $json_decode = '[{}]';
	my $content_ok = 'nok';
	
	do {
	
		# https://data.instatfootball.tv/api/Getinstatid?key=22812357092873478234729374&method=UpdateBasketballSynergyMatches&id=414219,414525,414357
		my $url = 'https://data.instatfootball.tv/api/Getinstatid?key=22812357092873478234729374&method=UpdateBasketballSynergyMatches&id='.$match_id;
		my $method = 'GET';
		my $useragent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0';
		my $request = HTTP::Request -> new (
			$method => $url,
			[
				'User-Agent' => 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0',
				'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
				'Accept-Language' => 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
				'Accept-Charset' => 'windows-1251,utf-8;q=0.7,*;q=0.7',
			]
		);

		my $file = getcwd () .'/txt/get_1.html';
		# my $response = $lwp -> request ($request, $file);
		my $response = $lwp -> request ($request);
		print $response -> code  ."\t". $url ."\n";
		print $response -> content ."\n";
		
		my $content = $response -> content;
		$content =~ s/\n+//g;
		$content =~ s/\r+//g;
		$content =~ s/\t+//g;
		
		if ($content =~ /^\[\{"id":"\d+",/) {
			$content_ok = 'ok';
			$json_decode = decode_json ($response -> content);	
		}
		
		#��������
		#sleep 1;
		
	} while ($response_code != 200 and $content_ok ne 'ok');
	
	return $json_decode;
}

