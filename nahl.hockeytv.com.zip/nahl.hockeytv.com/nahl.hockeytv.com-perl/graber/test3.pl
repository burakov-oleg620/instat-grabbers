#!/usr/bin/env perl
use strict;
use warnings;

my $count = 0;
print $count++."\n";
sleep 3;

system ('./test3.pl');

