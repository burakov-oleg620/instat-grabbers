#!/usr/bin/env perl
use strict;
use warnings;
use dir_scan_recurce;
use read_text_file; 
use write_text_file_mode_rewrite; 
use clear_str;
use delete_duplicate_from_array; 
use read_inifile;
use url_to_file;
use Encode qw (encode decode);
use date_time;
use MD5;
use File::Copy;
use File::Path;

use work_mysql;
use Date::Calc qw (Time_to_Date Date_to_Time);
use work_mysql_agregator;
use work_mysql_agregator2;
use MD5;
use Cwd qw (realpath);
use work_for_content;
use write_to_txt1;
use write_to_txt2;
use JSON::XS;
use Data::Dumper;
use locale;
use Tie::IxHash;
use LWP::UserAgent;
use HTTP::Request;
use HTTP::Response;
use HTTP::Cookies;


sub get_base_path {
	use Cwd; 
	my $cwd = getcwd ();
	return $cwd;
}

my $read_inifile = read_inifile -> new ('graber.ini'); 
my $host = $read_inifile -> get ('host');	
#����� ��������� �� ��� �����
my $mysql_dbdriver = $read_inifile -> get ('mysql_dbdriver');
my $mysql_host = $read_inifile -> get ('mysql_host');
my $mysql_port = $read_inifile -> get ('mysql_port');
my $mysql_user = $read_inifile -> get ('mysql_user');
my $mysql_user_password = $read_inifile -> get ('mysql_user_password');
if ($mysql_user_password eq ' ') {$mysql_user_password = '';}
my $mysql_base = $read_inifile -> get ('mysql_base');
my $mysql_table = $read_inifile -> get ('mysql_table');
my $content_table = $read_inifile -> get ('content_table');

my $lwp = undef;
$lwp = LWP::UserAgent -> new ();
$lwp -> cookie_jar (HTTP::Cookies->new ());
$lwp -> agent ('Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.2.16) Gecko/20110319 Firefox/3.6.16');
$lwp -> timeout (60);
# $lwp -> proxy ('http', 'http://127.0.0.1:8080');


my $workdir1 = get_base_path.'/txt'; 
my $workdir2 = get_base_path.'/picture'; 

my $file1 = $workdir1.'/write_text_file_mode_rewrite33s.xls'; 
my $file5 = $workdir1.'/write_text_file_mode_rewrite333s.xls'; 
my $file2 = $workdir1.'/write_text_file_mode_rewrite444.xls'; 


my $file3 = $workdir1.'/write_text_file_mode_rewrite5333.xls'; 
my $file4 = $workdir1.'/write_text_file_mode_rewrite55.xls'; 



# my ($year,$month,$day, $hour,$min,$sec) = Time_to_Date (time () + 4*3600);
# my $file2 = $workdir1.'/write_text_file_mode_rewrite2.xls'; 
# my $file2 = $workdir1.'/'.$year.'-'.$month.'-'.$day.'-'. $hour.'-'.$min.'-'.$sec.'-'.$host.'.xls'; 


# my 	$work_mysql = work_mysql -> new (
		# $mysql_dbdriver,
		# $mysql_host,
		# $mysql_port,
		# $mysql_user,
		# $mysql_user_password,
		# $mysql_base
	# ); 	

# my $sql = 'SET NAMES CP1251';
# $work_mysql -> run_query ($sql); 


# #������� ���������� �� mysql ����������
# my $work_mysql_agregator = work_mysql_agregator -> new (
	# $mysql_dbdriver,
	# $mysql_host,
	# $mysql_port,
	# $mysql_user,
	# $mysql_user_password,
	# $mysql_base,
	# $read_inifile -> {agregator}
# ); 

# if ($read_inifile -> {clear_agregator} == 1) {
	# $work_mysql_agregator -> drop ();
# }
# $work_mysql_agregator -> create ();		
# # $work_mysql_agregator2 -> clear ($read_inifile -> {clear_agregator_time});

# #������� ���������� �� mysql ����������
# my $work_mysql_agregator2 = work_mysql_agregator2 -> new (
	# $mysql_dbdriver,
	# $mysql_host,
	# $mysql_port,
	# $mysql_user,
	# $mysql_user_password,
	# $mysql_base,
	# $read_inifile -> {agregator2}
# ); 

# if ($read_inifile -> {clear_agregator} == 1) {
	# $work_mysql_agregator2 -> drop ();
# }
# $work_mysql_agregator2 -> create ();		
# # $work_mysql_agregator2 -> clear ($read_inifile -> {clear_agregator_time});	


my $count = 0;
my @read_text_file1 = ();
my %file1 = ();
tie (%file1, 'Tie::IxHash');
my %file2 = ();
tie (%file2, 'Tie::IxHash');

my %file3 = ();
tie (%file3, 'Tie::IxHash');

my %file4 = ();
tie (%file4, 'Tie::IxHash');


#�������
my %file5 = ();
tie (%file5, 'Tie::IxHash');
{
	my $read_text_file2 = read_text_file -> new ($file5); 
	while (my $str1 = $read_text_file2 -> get_str ()) {
		print ++$count."\n";
		
		if ($str1 =~ /\t/) {
			my $temp1 = []; my $pattern1 = "\t"; @$temp1 = split ($pattern1, $str1); 
			
			# print '*' . scalar (@$temp1) ."\n";
			if (scalar (@$temp1) > 1) {
				
				#����������� ��� ����, ����� ������ ������ ������
				foreach (@$temp1) {
					my $clear_str = clear_str -> new ($_);
					$_ = $clear_str -> delete_4 ();
					$clear_str = undef;											
				}
				
				$file5 {$temp1 -> [0]} = $temp1;
			}			
		}
	}
}

{
	#������� ������� �� ����� ������� ��������� (��� �������)
	my $read_text_file2 = read_text_file -> new ($file1); 
	while (my $str1 = $read_text_file2 -> get_str ()) {
		print ++$count."\n";
		
		if ($str1 =~ /\t/) {
			my $temp1 = []; my $pattern1 = "\t"; @$temp1 = split ($pattern1, $str1); 
			
			# print '*' . scalar (@$temp1) ."\n";
			if (scalar (@$temp1) > 1) {
				
				#����������� ��� ����, ����� ������ ������ ������
				foreach (@$temp1) {
					my $clear_str = clear_str -> new ($_);
					$_ = $clear_str -> delete_4 ();
					$clear_str = undef;											
				}
				
				$file4 {$temp1 -> [0]} = $temp1;
				
			}
		}
	}
	
	$read_text_file2 = undef;
}


{
	#������� ������� �� ����� �������
	my $read_text_file2 = read_text_file -> new ($file1); 
	while (my $str1 = $read_text_file2 -> get_str ()) {
		print ++$count."\n";
		
		if ($str1 =~ /\t/) {
			my $temp1 = []; my $pattern1 = "\t"; @$temp1 = split ($pattern1, $str1); 
			
			# print '*' . scalar (@$temp1) ."\n";
			if (scalar (@$temp1) > 1) {
				
				#����������� ��� ����, ����� ������ ������ ������
				foreach (@$temp1) {
					my $clear_str = clear_str -> new ($_);
					$_ = $clear_str -> delete_4 ();
					$clear_str = undef;											
				}
				
				if ($temp1 -> [scalar (@$temp1) - 2] =~ /^\d+$/) {
					
					if (exists ($file1 {$temp1 -> [scalar (@$temp1) -2]})) {
						push (@{$file1 {$temp1 -> [scalar (@$temp1) -2]}}, $temp1);
					} else {
						$file1 {$temp1 -> [scalar (@$temp1) -2]} = [];
						push (@{$file1 {$temp1 -> [scalar (@$temp1) -2]}}, $temp1);
					}
				}

			}
		}
	}
	
	$read_text_file2 = undef;
}


{
	#������� ����� ��������� ���� �� �����
	my $read_text_file2 = read_text_file -> new ($file2); 
	while (my $str1 = $read_text_file2 -> get_str ()) {
		print ++$count."\n";
		
		if ($str1 =~ /\t/) {
			my $temp1 = []; my $pattern1 = "\t"; @$temp1 = split ($pattern1, $str1); 
			
			# print '*' . scalar (@$temp1) ."\n";
			if (scalar (@$temp1) > 1) {
				
				#����������� ��� ����, ����� ������ ������ ������
				foreach (@$temp1) {
					my $clear_str = clear_str -> new ($_);
					$_ = $clear_str -> delete_4 ();
					$clear_str = undef;											
				}
				
				if ($temp1 -> [0] =~ /^\d+$/) {
					$file2 {$temp1 -> [0]} = $temp1;
				}
			}
		}
	}
	$read_text_file2 = undef;
}


my $read_text_file2 = read_text_file -> new ($file3); 
while (my $str1 = $read_text_file2 -> get_str ()) {
	print ++$count."\n";
	
	if ($str1 =~ /\t/) {
		my $temp1 = []; my $pattern1 = "\t"; @$temp1 = split ($pattern1, $str1); 
		
		# print '*' . scalar (@$temp1) ."\n";
		if (scalar (@$temp1) > 1) {
			
			#����������� ��� ����, ����� ������ ������ ������
			foreach (@$temp1) {
				my $clear_str = clear_str -> new ($_);
				$_ = $clear_str -> delete_4 ();
				$clear_str = undef;											
			}
			
			if ($temp1 -> [0] =~ /^\d+$/) {
				
				if (exists ($file3 {$temp1 -> [0]})) {
					push (@{$file3 {$temp1 -> [0]}}, $temp1);
				} else {
					$file3 {$temp1 -> [0]} = [];
					push (@{$file3 {$temp1 -> [0]}}, $temp1);
				}
			}
			
		}
	}
}
$read_text_file2 = undef;


#������� ����, ������ ����� ��� �� ���� � �������.
if (scalar (keys(%file2)) > 0) {
	
	my $write_text_file_mode_rewrite = write_text_file_mode_rewrite -> new ($file4);
	foreach (keys (%file2)) {
		
		my $temp2 = [];
		push (@$temp2, join ("\t", @{$file2{$_}}));
		
		#��� ������
		if (exists ($file1 {$file2{$_} -> [0]})) {
		
			my @array1 = ();
			
			foreach (@{$file1 {$file2{$_} -> [0]}}) {
				my @array2 = ();
				
				my $str = undef;
				
				$str = '<player_id>'.$_  -> [0].'</player_id>';
				push (@array2, $str);
				
				$str = '<player_instat_id>'.$_  -> [9].'</player_instat_id>';
				push (@array2, $str);
				
				$str = '<first_name>'.$_  -> [1].'</first_name>';
				push (@array2, $str);
				
				$str = '<last_name>'.$_  -> [2].'</last_name>';
				push (@array2, $str);
				
				$str = '<player_number>'.$_  -> [3].'</player_number>';
				push (@array2, $str);
				
				$str = '<team_id>'.$_  -> [4].'</team_id>';
				push (@array2, $str);
				
				if (exists ($file5 {$_  -> [4]})) {
					$str = '<team_instat_id>'.$file5 {$_  -> [4]} -> [6].'</team_instat_id>';
					push (@array2, $str);
				}
				
				$str = '<match_date>'.$_  -> [5].'</match_date>';
				push (@array2, $str);
				
				$str = '<league>'.$_  -> [6].'</league>';
				push (@array2, $str);
				
				my %league = (
					# 1 => 'NBA', 
					# 2 => 'WNBA', 
					# 5 => 'College Men', 
					# 6 => 'College Women',
					# 7 => 'FIBA - National Teams',
					# 8 => 'Summer League',
					# 9 => 'NBA Pre-Draft Camp',
					# 10 => 'NBA D-League', 
					# 28 => 'International', 
					# 30 => 'All-Star', 
					
					'NBA' => 1, 
					'WNBA' => 2, 
					'College Men' => 5,  
					'College Women' => 6,
					'FIBA - National Teams' => 7,
					'Summer League' => 8, 
					'NBA Pre-Draft Camp' => 9,
					'NBA D-League' => 10, 
					'International' => 28,
					'All-Star' => 30, 
				);
				
				if (exists ($league {$_ -> [6]})) {
					$str = '<league_id>'.$league {$_ -> [6]}.'</league_id>';
					push (@array2, $str);
					
				}
				
				$str = '<gender>'.$_  -> [7].'</gender>';
				push (@array2, $str);
				
				if (scalar (@array2) > 0) {
					my $str = join ('', @array2);
					push (@array1, $str);
				}
			}
			
			if (scalar (@array1) > 0) {
				my $str = join ('||', @array1);
				push (@$temp2, $str);
			}
		}
		
		
		
		#��� �������
		if (exists ($file3 {$file2{$_} -> [0]})) {
			my @array1 = ();
			
			foreach (@{$file3 {$file2{$_} -> [0]}}) {
				my @array2 = ();
				
				my $str = undef;
				
				
				$str = '<event_count>'.$_  -> [17].'</event_count>';
				push (@array2, $str);

				$str = '<gameClockMin>'.$_  -> [14].'</gameClockMin>';
				push (@array2, $str);
				
				$str = '<gameClock>'.$_  -> [19].'</gameClock>';
				push (@array2, $str);

				$str = '<homeScore>'.$_  -> [12].'</homeScore>';
				push (@array2, $str);
				
				$str = '<awayScore>'.$_  -> [13].'</awayScore>';
				push (@array2, $str);
				
				$str = '<period>'.$_  -> [16].'</period>';
				push (@array2, $str);
				
				# $str = '<bHomeEvent>'.$_  -> [18].'</bHomeEvent>';
				$str = '<bHome>'.$_  -> [18].'</bHome>';
				push (@array2, $str);
				
				$str = '<Description>'.$_  -> [20].'</Description>';
				push (@array2, $str);
				
				$str = '<DescriptionText>'.$_  -> [15].'</DescriptionText>';
				push (@array2, $str);
				
				$str = '<DescriptionPlayType>'.$_  -> [21].'</DescriptionPlayType>';
				push (@array2, $str);
				
				$str = '<DescriptionPlayTypeText>'.$_  -> [22].'</DescriptionPlayTypeText>';
				push (@array2, $str);
				
				$str = '<PlayerID>'.$_ -> [23].'</PlayerID>';
				push (@array2, $str);
				

				if (exists ($file4 {$_ -> [23]})) {
					if (not defined ($file4 {$_ -> [23]} -> [9])) {$file4 {$_ -> [23]} -> [9] = 0;}
					$str = '<PlayerInstatID>'.$file4 {$_ -> [23]} -> [9].'</PlayerInstatID>';
					push (@array2, $str);
				}
				
				$str = '<PlayerOpponentID>'.$_  -> [24].'</PlayerOpponentID>';
				push (@array2, $str);
				
				if (exists ($file4 {$_  -> [24]})) {
					if (not defined ($file4 {$_ -> [24]} -> [9])) {$file4 {$_ -> [24]} -> [9] = 0;}
					$str = '<PlayerOpponentInstatID>'.$file4 {$_  -> [24]} -> [9].'</PlayerOpponentInstatID>';
					push (@array2, $str);
				}
				
				
				$str = '<TeamID>'.$_  -> [25].'</TeamID>';
				push (@array2, $str);
				
				
				$str = '<DirtyTime>'.$_  -> [27].'</DirtyTime>';
				push (@array2, $str);
				
				
				$str = '<PosX>'.$_  -> [28].'</PosX>';
				push (@array2, $str);
				
				$str = '<PosY>'.$_  -> [29].'</PosY>';
				push (@array2, $str);
				
				
				if (exists ($file5 {$_  -> [25]})) {
					$str = '<TeamInstatID>'.$file5 {$_  -> [25]} -> [6].'</TeamInstatID>';
					push (@array2, $str);
				}
				
				
				if (scalar (@array2) > 0) {
					my $str = join ('', @array2);
					push (@array1, $str);
				}
				
			}
			
			if (scalar (@array1) > 0) {
				my $str = join ('||', @array1);
				push (@$temp2, $str);
			
			}
		}
		
		
		
		
		$write_text_file_mode_rewrite -> put_str (join ("\t", @$temp2)."\n");
		
	}
	
	$write_text_file_mode_rewrite = undef;
}






	


sub entities_decode {
	use HTML::Entities;
	my $str = shift;
	#����� ������� ������ ����� ������� decode � ����� ���������
	$str = decode ('cp1251', $str);
	$str = decode_entities ($str);
	$str = encode ('cp1251', $str);
	return $str;
}

sub get_file_type_2 {
	my $file = shift;
	my %file = ();
	open (FILE, $file) or die;
	while (<FILE>) {
		chomp;
		$_ = encode ('cp1251', decode ('utf8', $_));
		if ($_ =~ /;/) {
			my $str = [];
			@$str = split (";",$_); 
			if (scalar (@$str) == 2) {
				$file{$str -> [1]} = $str -> [0];
			}
		}
	}
	return %file;
}


sub get_file_type_3 {
	my $file = shift;
	my %file = ();
	open (FILE, $file) or die;
	while (<FILE>) {
		chomp;
		$_ = encode ('cp1251', decode ('utf8', $_));
		if ($_ =~ /;/) {
			my $str = [];
			@$str = split (";",$_); 
			if (scalar (@$str) == 3) {

				$str->[2] =~ s/\"//g; 
				$str->[2] = lc ($str->[2]); 
				# print $str->[2] ."\n";
				# print $str->[0] ."\n";				
				$file{$str -> [2]} = $str -> [0];
			}
		}
	}
	return %file;
}


sub post {
	my $postdata = shift;
	
	
	my $key_import2 = '22812357092873478234729374';
        my $url = 'http://data.instatfootball.tv/api/import2?key='.$key_import2.'&method=UpdateBasketballSynergyMatches';	
	# my $postdata = 'firstsec=1&email=is.fin.dept%40gmail.com&pwd=basket55&women=0&B1=Login';

	push (@{ $lwp->requests_redirectable }, 'POST');
	my $req = HTTP::Request -> new (
	'POST' => $url,
		[
			# 'User-Agent' => 'Mozilla/5.0 (Windows NT 5.1; rv:11.0) Gecko/20100101 Firefox/11.0',
			# 'Accept-Language' => 'ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
			# 'Referer' => 'http://basketball.eurobasket.com/player/Andrey-Vorontsevich/Russia/CSKA-Moscow/71366',
			# 'Content-Type' => 'application/json',
			
			'Accept' => '*/*',
			'Content-Type' => 'multipart/form-data; boundary=----------------------------4b5789fa8d3f',
			
		]
	);
	
	
	my $str = 
'------------------------------4b5789fa8d3f
Content-Disposition: form-data; name="json"

'.$postdata.'
------------------------------4b5789fa8d3f--';
	

	$req -> content ($str);
	
	my $file = getcwd () .'/txt/matches.html';
	my $res = $lwp -> request ($req, $file); 
	print $res -> code ."\t" . $url ."\n";
	
	# my $sleep = Random ($sleep2, $sleep3); 
	# sleep $sleep;		
}

	
	
	
	