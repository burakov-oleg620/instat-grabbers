<?php
ini_set('date.timezone', 'Europe/Moscow');

$file = getcwd () .'/xls/001.xls';
if (is_file ($file)) {
	$content = file_get_contents ($file);
	$fc = preg_split ('/\n+/ui', $content);
	foreach ($fc as $fc_value) {
		if (preg_match ('/https/ui', $fc_value)) {
			print $fc_value ."\n";
			
			$fs = preg_split ('/\t+/ui', $fc_value);
			foreach ($fs as &$fs_value) {
				$fs_value = trim ($fs_value);
			}
			
			if (count ($fs) == 2) {
				
				$id = $fs[1];
				$url =  $fs[0];

				
				//отправляю в ДЕ что пытаюсь скачать матч
				$insert = array ();
				$insert['id'] = $id;
				$insert['video_try_download_date'] = date('Y-m-d H:i:s', time());
				$a = array ();
				array_push ($a, $insert);
				$json_str = json_encode ($a);
				print_r ($insert) ."\n";
				print $json_str. "\n";
				post ($json_str);
				
				
			
				//$proxy_ip = '85.208.86.236:8085';
				$ch = curl_init();

				//$url = 'https://embedded.sportlevel.com/translations/MGI3YjkzYjdlNzRlZTdjYTNiYmE0NzI0NzI0N2RjZDQ6MzQzMDg2OjQ6Og/embed2';
				
				$headers = array (
					'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0',
					'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
					'Accept-Language: ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
				);
				
				
				// установка URL и других необходимых параметров
				curl_setopt($ch, CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_HEADER, false);
				curl_setopt($ch, CURLOPT_HTTPHEADER, $headers); //установка хттп заголовков		
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); //редирект включен
				// curl_setopt($ch, CURLOPT_COOKIEJAR,  $cookies); 
				// curl_setopt($ch, CURLOPT_COOKIEFILE, $cookies);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
				//curl_setopt($ch, CURLOPT_NOBODY, false);
				//curl_setopt($ch, CURLOPT_NOBODY, true);
				//curl_setopt($ch, CURLOPT_CONNECT_ONLY, true);


				if (isset ($proxy_ip)) {
					curl_setopt($ch, CURLOPT_PROXY, $proxy_ip);
				}
				
				$content = curl_exec($ch);		
				$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
				
				print $httpcode."\t".$url. "\n";
				//print $content ."\n";
				
				$file = getcwd () .'/html/playlist2.m3u8';
				file_put_contents ($file, $content);
				//$content = str_replace (array ("\n", "\r", "\t"), ' ', $content);
				
				
				
				/* для скачивания только большого разрешения
				// $c = preg_split ('/\n/ui', $content);
				// $cf = array ();
				// array_push ($cf, array_shift ($c));
				// array_push ($cf, array_shift ($c));
				// array_pop ($c);
				// array_push ($cf, $c[count ($c) -2]);
				// array_push ($cf, $c[count ($c) -1]);
				// $content = join ("\n", $cf);
				//file_put_contents ($file, $content);
				*/
				
				
			
				$in = $url;
				
				$dir = getcwd (). '/out/'.$id;
				if (!is_dir ($dir)) {
					mkdir ($dir,  0777, true); 
				}
				
				if (is_dir ($dir)) {
					$out = getcwd (). '/out/'.$id.'/0_'.$id.'_0.mp4';
					shell_exec('ffmpeg -protocol_whitelist file,http,https,tcp,tls,crypto -i ' . $in  . ' -acodec copy -vcodec copy ' . $out);
				}	
				
				if (is_file ($out)) {
					
					//отправляю в ДЕ что пытаюсь скачать матч
					$insert = array ();
					$insert['id'] = $id;
					$insert['video_download_date'] = date('Y-m-d H:i:s', time());
					$a = array ();
					array_push ($a, $insert);
					$json_str = json_encode ($a);
					print_r ($insert) ."\n";
					print $json_str. "\n";
					post ($json_str);
					
				} else {
					
					//отправляю в ДЕ что пытаюсь скачать матч
					$insert = array ();
					$insert['id'] = $id;
					$insert['video_fail_download_date'] = date('Y-m-d H:i:s', time());
					$a = array ();
					array_push ($a, $insert);
					$json_str = json_encode ($a);
					print_r ($insert) ."\n";
					print $json_str. "\n";
					post ($json_str);
					
				}
			}
		}
	}
}




function post ($postdata) {
	$return = array ();	

	// UpdateBasketballScoreswayTeams,
	// UpdateBasketballScoreswayPlayers
	// UpdateHockeyScoreswayTeams,
	// UpdateHockeyScoreswayPlayers
	
	$key_import2 = '22812357092873478234729374';
	// $url = 'http://data.instatfootball.tv/api/import2?key='.$key_import2.'&method=InsertBasketballTeams';
	$url = 'http://data.instatfootball.tv/api/import2?key='.$key_import2.'&method=UpdateHockeyNahlHockeyTvMatches';
	
	$post_array = [
		'json' => $postdata,
	];
	
	$ch = curl_init($url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    // curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
	curl_setopt($ch, CURLOPT_POSTFIELDS, $post_array);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);	
	
	$content = curl_exec($ch);		
	$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	
	print $httpcode."\t".$url. "\n";
	if ($httpcode == 200) {
	
		// $get_base_path = new get_base_path;
		// $workdir = $get_base_path -> get ();
		// unset ($get_base_path);
		
		$workdir = getcwd ();
		$file = $workdir .'/txt/post_json_teams.html';
		
		// $put_content_to_file = new put_content_to_file ($content, $file);
		// $put_content_to_file -> put ();
		// unset ($put_content_to_file);
	}
	
	return $return;
}
	
	
			

?>