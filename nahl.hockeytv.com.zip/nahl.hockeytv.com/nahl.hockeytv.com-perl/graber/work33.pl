#!/usr/bin/env perl
use strict;
use warnings;
use File::Path;
use Encode qw (decode encode);
use locale;
use List::Util qw (shuffle);
use Cwd;
use dir_scan_recurce;

use threads;
use threads::shared;
use Thread::Queue;

use read_inifile;
use read_select1;
use read_select2;
use clear_str;
use create_type_workdir;
use url_to_file;
use read_xml;

use work_mysql_graber;
use work_mysql_proxy;
use work_for_content;

use write_text_file_mode_add;
use write_text_file_mode_rewrite; 
use read_text_file;

use LWP::UserAgent;
use HTTP::Request;
use HTTP::Response;
use HTTP::Cookies;
use URI::Escape;
use JSON::XS;
use Data::Dumper;
use URI::URL;
use File::Copy;
use File::Path;
use File::Copy::Recursive qw(fcopy rcopy dircopy fmove rmove dirmove);
use Tie::IxHash;

#system 'clear_table.pl'; 
#system 'clear_dir.pl';

#Читаю установки из ини файла
my $read_inifile = read_inifile -> new ('graber.ini'); 
my $mysql_dbdriver = $read_inifile -> get ('mysql_dbdriver');
my $mysql_host = $read_inifile -> get ('mysql_host');
my $mysql_port = $read_inifile -> get ('mysql_port');
my $mysql_user = $read_inifile -> get ('mysql_user');
my $mysql_user_password = $read_inifile -> get ('mysql_user_password');
if ($mysql_user_password eq ' ') {$mysql_user_password = '';}
my $mysql_base = $read_inifile -> get ('mysql_base');
my $mysql_table = $read_inifile -> get ('mysql_table');

my $threads_all = $read_inifile -> get ('threads_all'); 
my $sleep1 = $read_inifile -> get ('sleep1'); 
my $sleep2 = $read_inifile -> get ('sleep2'); 
my $sleep3 = $read_inifile -> get ('sleep3'); 

my $host = $read_inifile -> get ('host');	
my $set_proxy = $read_inifile -> get ('set_proxy');
my $count_all = $read_inifile -> get ('count_all');	

# читаем шаблоны (ссылок и прочее)
my $read_select2 = read_select2 -> new ('select2.txt'); 
my @read_select2 = $read_select2 -> get ();
$read_select2 = undef;

my $read_select3 = read_select2 -> new ('select3.txt'); 
my @read_select3 = $read_select3 -> get ();
$read_select3 = undef;

my $read_select4 = read_select2 -> new ('select4.txt'); 
my @read_select4 = $read_select4 -> get ();
$read_select4 = undef;	

my @proxy = (); #массив с прокси
my @useragent = (); 


#создаю экземпляр броузера
my $lwp = undef;
$lwp = LWP::UserAgent -> new ();
$lwp -> cookie_jar (HTTP::Cookies->new ());
$lwp -> agent ('Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.2.16) Gecko/20110319 Firefox/3.6.16');
$lwp -> timeout (5);
$lwp -> proxy ('http', 'http://127.0.0.1:8080');

#очередь работы, куда добавляются задания
# my $queue_job = Thread::Queue->new ();
# my $queue_job_proxy = Thread::Queue->new ();

#гобальные переменные
# my @start_second = (); my $start_second = 0; #переменные для отслеживания запуска start_second ();
# my @pattern_from_select = (); my $pattern_from_select = undef; #проверка контента на наличие указанного шаблона текста

# my %tid_hash :shared; 
# %tid_hash = (); #глобальный хеш - работают потоки или нет.


#устанавливаем соединение с базой данных
#соединение для тела программы
our $work_mysql_graber = work_mysql_graber -> new (
	$mysql_dbdriver,
	$mysql_host,
	$mysql_port,
	$mysql_user,
	$mysql_user_password,
	$mysql_base,
	$mysql_table
); 

start_first (); #добавляеет входящую ссылку из XML файла

sub start_first {

	my $count = 0;
	
	my $workdir1 = getcwd () .'/xls2';
	my $dir_scan_recurce = dir_scan_recurce -> new ($workdir1);
	while (my $file1 = $dir_scan_recurce -> get_file ()) {
		print ++$count."\n";
		
		my $pattern = 'xls$';
		if ($file1 =~ /$pattern/) {	
		
			my %file1 = ();
			tie (%file1, 'Tie::IxHash');

			my @file1 = ();	
			my $read_text_file = read_text_file -> new ($file1); 
			while (my $str1 = $read_text_file -> get_str ()) {
			
				if ($str1 =~ /\t/) {
					my $temp1 = []; my $pattern1 = "\t"; @$temp1 = split ($pattern1, $str1); 
					
					# print '*'.scalar (@$temp1)."\n";
					if (scalar (@$temp1) > 1) {			
						print ++$count."\n";	
						
						foreach (@$temp1) {
							my $clear_str = clear_str -> new ($_); 
							$_ = $clear_str -> delete_4 ();
							$clear_str = undef;
						}
						
						
						if ($temp1 -> [0] =~ /\d+/) {
							my $match_id = $temp1 -> [1];
							
							my $get_instat_id_result = get_instat_id  ($match_id);
							if (scalar (@{$get_instat_id_result}) > 0) {
								foreach (@{$get_instat_id_result}) {
									my $get_instat_id_result_local = $_;
							
									# #заремарить!!!!!!!!!
									# $get_instat_id_result_local -> {instat_id} = 1334;
									
									if (
											
											defined ($get_instat_id_result_local -> {instat_id}) and 
											$get_instat_id_result_local -> {instat_id} != 0 and 
											$get_instat_id_result_local -> {match_status} != 4 and 
											$get_instat_id_result_local -> {match_status} != 5 and 
											$get_instat_id_result_local -> {match_status} != 8
											
									) {
									
									
										my $str = join ("\t", @$temp1);
										# push (@read_text_file1, $str);
										$file1 {$temp1 -> [0]} = $str;
								
									}									
								}
							}
						}


					}
					}
			}
			
			if (scalar (keys (%file1)) > 0) {
				my $file3 = $file1;
				$file3 =~ s/^.+\///;
				$file3 = getcwd .'/out/'.$file3;
				
				my $write_text_file_mode_rewrite = write_text_file_mode_rewrite -> new ($file3);
				foreach (keys (%file1)) {
					$write_text_file_mode_rewrite -> put_str ($file1 {$_}."\n");
				}
				$write_text_file_mode_rewrite = undef;
				
			}
			
			
		
		}
	}
}




sub get_instat_id {
	my $match_id = shift;
	
	
	# https://data.instatfootball.tv/api/Getinstatid?key=22812357092873478234729374&method=UpdateBasketballSynergyMatches&id=414219,414525,414357
	my $url = 'https://data.instatfootball.tv/api/Getinstatid?key=22812357092873478234729374&method=UpdateBasketballSynergyMatches&id='.$match_id;
	my $method = 'GET';
	my $useragent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0';
	my $request = HTTP::Request -> new (
		$method => $url,
		[
			'User-Agent' => 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0',
			'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Accept-Language' => 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
			'Accept-Charset' => 'windows-1251,utf-8;q=0.7,*;q=0.7',

		]
	);

	my $file = getcwd () .'/txt/get_1.html';
	# my $response = $lwp -> request ($request, $file);
	my $response = $lwp -> request ($request);
	print $response -> code  ."\t". $url ."\n";
	print $response -> content ."\n";
	
	my $json_decode = decode_json ($response -> content);
	return $json_decode;
}
