#!/usr/bin/env perl
use strict;
use warnings;
use locale;
use dir_scan_recurce;
use read_text_file; 
use write_text_file_mode_rewrite; 
use Encode qw (encode decode);
use clear_str;
use read_inifile;

use work_mysql_graber;
use work_for_content;
use write_to_txt1;
use write_to_txt2;

use Date::Calc;
use HTML::TreeBuilder::XPath;
use MD5;

use LWP::UserAgent;
use HTTP::Request;
use HTTP::Response;
use HTTP::Cookies;
use URI::Escape;
use HTML::TreeBuilder::XPath;
use LWP::Protocol::http;
use Data::Dumper;
use JSON::XS;
use File::Copy;
use File::Path;


sub get_base_path {
	use Cwd; 
	my $cwd = getcwd ();
	return $cwd;
}


my $read_inifile = read_inifile -> new ('graber.ini'); 
my $host = $read_inifile -> get ('host');	

#����� ��������� �� ��� �����
my $mysql_dbdriver = $read_inifile -> get ('mysql_dbdriver');
my $mysql_host = $read_inifile -> get ('mysql_host');
my $mysql_port = $read_inifile -> get ('mysql_port');
my $mysql_user = $read_inifile -> get ('mysql_user');
my $mysql_user_password = $read_inifile -> get ('mysql_user_password');
if ($mysql_user_password eq ' ') {$mysql_user_password = '';}
my $mysql_base = $read_inifile -> get ('mysql_base');
my $mysql_table = $read_inifile -> get ('mysql_table');


my $lwp = undef;
$lwp = LWP::UserAgent -> new ();
$lwp -> cookie_jar (HTTP::Cookies->new ());
$lwp -> agent ('Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.2.16) Gecko/20110319 Firefox/3.6.16');
$lwp -> timeout (60);
# $lwp -> proxy ('http', 'http://127.0.0.1:8080');


#������� ���������� �� mysql ����������
my $work_mysql_graber = work_mysql_graber -> new (
	$mysql_dbdriver,
	$mysql_host,
	$mysql_port,
	$mysql_user,
	$mysql_user_password,
	$mysql_base,
	$mysql_table
); 

# my 	$work_mysql = work_mysql -> new (
		# $mysql_dbdriver,
		# $mysql_host,
		# $mysql_port,
		# $mysql_user,
		# $mysql_user_password,
		# $mysql_base
	# ); 	
	
# my $sql = 'set names utf8';
# $work_mysql -> run_query ($sql);

	

my $workdir0 = get_base_path.'/out'; 
my $workdir1 = get_base_path.'/txt'; 
my $workdir2 = get_base_path.'/media'; 
my $workdir3 = get_base_path.'/picture'; 

my $write_text_file_mode_rewrite1 = undef;
my $write_file1 = $workdir1.'/write_text_file_mode_rewrite00.xls'; 
$write_text_file_mode_rewrite1 = write_text_file_mode_rewrite -> new ($write_file1);

my $count = 0 ;

my $workdir4 = getcwd () .'/xls';
my $dir_scan_recurce = dir_scan_recurce -> new ($workdir4);
while (my $file1 = $dir_scan_recurce -> get_file ()) {
	print ++$count."\n";
	
	my $pattern = 'xls$';
	if ($file1 =~ /$pattern/) {	
		
		my @file1 = ();	
		my $read_text_file = read_text_file -> new ($file1); 
		while (my $str1 = $read_text_file -> get_str ()) {
		
			if ($str1 =~ /\t/) {
				my $temp1 = []; my $pattern1 = "\t"; @$temp1 = split ($pattern1, $str1); 
				
				# print '*'.scalar (@$temp1)."\n";
				if (scalar (@$temp1) > 1) {			
					print ++$count."\n";	
					
					foreach (@$temp1) {
						my $clear_str = clear_str -> new ($_); 
						$_ = $clear_str -> delete_4 ();
						$clear_str = undef;
					}
					
					if ($temp1 -> [1] == 1) {
						
						my $insert = {};
						$insert -> {post_url} = $temp1 -> [0];
						my $post_str = $temp1 -> [0];
						
						my $md5 = MD5 -> new ();
						my $hash = $md5 -> hexhash ($insert -> {post_url});
						$md5 = undef;
						
						
						my $file = getcwd () .'/html/'.$hash.'.xml';
						if (-f $file) {
						
							my @file1 = ();	
							my $read_text_file = read_text_file -> new ($file); 
							while (my $str1 = $read_text_file -> get_str ()) {
								my $clear_str = clear_str -> new ($str1); 
								$str1 = $clear_str -> delete_4 ();
								$clear_str = undef;			
								push (@file1, $str1); 
							}
							$read_text_file = undef;
							
							my $content1 = join (' ', @file1); 
						
										
							# <iGameID>
							my $game_id = '';
							my $pattern1 = '(<iGameID>.+?</iGameID>)';
							my $work_for_content = work_for_content -> new ($content1); 
							my $work_for_content_result = $work_for_content -> get_pattern ($pattern1); 
							if (defined $work_for_content_result -> [0]) {
								foreach (@$work_for_content_result) {		
									my $clear_str = clear_str -> new ($_);
									$_ = $clear_str -> delete_3 ();
									$_ = $clear_str -> delete_4 ();
									$clear_str = undef;		
									$game_id = $_;
								}
							}
							
							print '$game_id = ' . $game_id ."\n";
							if ($game_id ne '') {
							
								if (-d $workdir0 .'/'.$game_id) {
								
									my $count_file = 0;
									
									my $dir_scan_recurce = dir_scan_recurce -> new ($workdir0 .'/'.$game_id);
									while (my $file1 = $dir_scan_recurce -> get_file ()) {
										
										my $pattern = 'mp4|wmv';
										if ($file1 =~ /$pattern/i) {
											$count_file++;
										}
									}
									
									if ($count_file > 25) {
									
										if (-f $workdir2 .'/'.$game_id.'.xml') {
											
											my $file_size = -s $workdir2 .'/'.$game_id.'.xml';
											print $file_size ."\n";
											
											
											if (-s $workdir2 .'/'.$game_id.'.xml' > 500) {
											
												my $write_to_txt1 = write_to_txt1 -> new ();			
												
												$write_to_txt1 -> put ($post_str);
												
												
												my $str = $write_to_txt1 -> get ();
												$write_text_file_mode_rewrite1 -> put_str ($str."\n");														
												$write_to_txt1 = undef;								
												
											
											} else {
											
											}
											
											
										}
									}
									
								}
							
							}
							
							
							
							
						
						}
					}					
				}
			}
		}
	}
}

$dir_scan_recurce = undef;
$write_text_file_mode_rewrite1 = undef;


sub utf8_to_win1251 {
	use Encode qw (encode decode); 
	my $str = shift;
	$str = encode ('cp1251', decode ('utf8', $str)); 
	return $str;
}

sub entities_decode {
	use HTML::Entities;
	my $str = shift;
	#����� ������� ������ ����� ������� decode � ����� ���������
	$str = decode ('cp1251', $str);
	$str = decode_entities ($str);
	$str = encode ('cp1251', $str);
	return $str;
}

sub entities_decode1 {
	use HTML::Entities;
	my $str = shift;
	#����� ������� ������ ����� ������� decode � ����� ���������
	$str = decode ('utf8', $str);
	$str = decode_entities ($str);
	$str = encode ('utf8', $str);
	return $str;
}

sub get_date {
	my $time = shift;
	use Date::Calc qw (Time_to_Date Date_to_Time);
	my ($year,$month,$day, $hour,$min,$sec) = Time_to_Date ($time);
	# my $str = $year .'.'.$month .'.'. $day;
	# my $str = $year .'-'.$month ;
	
	# my @date = split ('\.', $str);
	my @date = ();
	push (@date, $year);
	push (@date, $month);
	push (@date, $day);
	
	if (scalar (@date) > 0) {
		foreach (@date) {
			while (length ($_) < 2) {
				$_ = '0'.$_;
			}
		}
	}
	my $str = $date[0] .'-'.$date[1];
	return $str;
}	

sub json_str {
	my $str = shift;
	$str =~ s/\n+/ /g;
	$str =~ s/\r+/ /g;
	$str = encode ('cp1251', $str);
	return $str;
}
