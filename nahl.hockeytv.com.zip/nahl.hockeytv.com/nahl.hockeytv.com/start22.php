<?php

ini_set('date.timezone', 'Europe/Moscow');
//setlocale(LC_ALL, 'ru_RU.CP1251', 'rus_RUS.CP1251', 'Russian_Russia.1251');
setlocale(LC_ALL, 'ru_RU.UTF-8');
error_reporting(E_ALL | E_STRICT) ;
ini_set('display_errors', 'On');		
set_time_limit(0); //������������� ����� �� ��������
flush ();

$count = 0;
$count_day_back = 10;
$count_day_foward = 30;

$lockfile = getcwd () .'/lockfile.txt';
if (!is_file ($lockfile)) {

	$fh = fopen ($lockfile, 'w') or die ();
	fclose ($fh);
	
	$url_array = array ();
	$time = time ();
	
	while ($count_day_back > 0) {
	
		$date = getdate ($time);
		//print_r ($date);
		
		$time = $time - 24*3600; //������� �����
		//$time = $time + 24*3600; //������� ������
		
		$count_day_back--;
		
		$date_0 = array ();
		array_push ($date_0, $date['year']);
		array_push ($date_0, $date['mon']);
		array_push ($date_0, $date['mday']);
		
		foreach ($date_0 as $key => $value) {
			if (strlen ($value) < 2) {
				$date_0 [$key] = '0'.$value;
			}
		}
		
		//https://api.hockeytv.com/schedule/search?date_disabled=false&limit=100&&offset=0&start_date=2018-10-15+00:00:00
		//https://api.hockeytv.com/schedule/search?date_disabled=false&limit=100&&offset=0&start_date=2018-10-25+00:00:00&end_date=2018-10-25+23:59:59
		$url = 'https://api.hockeytv.com/schedule/search?date_disabled=false&limit=16&offset=0&start_date='.$date_0[0].'-'.$date_0[1].'-'.$date_0[2].'+00:00:00'.'&end_date='.$date_0[0].'-'.$date_0[1].'-'.$date_0[2].'+23:59:59';
		array_push ($url_array, $url);
	}
	

	while ($count_day_foward > 0) {
	
		$date = getdate ($time);
		//print_r ($date);
		
		//$time = $time - 24*3600; //������� �����
		$time = $time + 24*3600; //������� ������
		
		$count_day_foward--;
		
		$date_0 = array ();
		array_push ($date_0, $date['year']);
		array_push ($date_0, $date['mon']);
		array_push ($date_0, $date['mday']);
		
		foreach ($date_0 as $key => $value) {
			if (strlen ($value) < 2) {
				$date_0 [$key] = '0'.$value;
			}
		}
		
		//https://api.hockeytv.com/schedule/search?date_disabled=false&limit=100&&offset=0&start_date=2018-10-15+00:00:00
		//https://api.hockeytv.com/schedule/search?date_disabled=false&limit=100&&offset=0&start_date=2018-10-25+00:00:00&end_date=2018-10-25+23:59:59
		$url = 'https://api.hockeytv.com/schedule/search?date_disabled=false&limit=16&offset=0&start_date='.$date_0[0].'-'.$date_0[1].'-'.$date_0[2].'+00:00:00'.'&end_date='.$date_0[0].'-'.$date_0[1].'-'.$date_0[2].'+23:59:59';
		array_push ($url_array, $url);
	}

	
	if (count ($url_array) > 0) {
		$file = getcwd () .'/city/001.xls';
		
		$fh = fopen ($file, 'w') or die ();
		foreach ($url_array as $value) {
			fwrite ($fh, $value ."\t". 1 ."\n");
		}
		fclose ($fh);
	}
	
	
	$workdir0 = getcwd ();
	$workdir1 = getcwd () .'/city';
	$workdir2 = getcwd () .'/graber1';
	$workdir3 = getcwd () .'/graber2';
	

	$file_array = array ();
	$dh = opendir ($workdir1) or die;
	while ($file = readdir ($dh)) {
		if ($file != '.' and $file != '..') {
			$file = $workdir1.'/'.$file;
			$pattern = '/xls$/';
			
			if (preg_match ($pattern, $file)) {
				print ++$count ."\n";
				
				$fh = fopen ($file, 'r') or die ();
				while ($str = fgets ($fh)) {
					$str = str_replace(array("\r","\n"), '', $str);
					
					array_push ($file_array, $str);
				}
				fclose ($fh);
			}
		}
	}
	closedir ($dh);
	
	if (count ($file_array) > 0) {
		foreach ($file_array as $file_array_value) {
			
			//graber1
			chdir ($workdir2);
			
			if (is_dir ($workdir2)) {
		
				$file = $workdir2 .'/xls/001.xls';
				$fh = fopen ($file, 'w') or die ();
				fwrite ($fh, $file_array_value);
				fclose ($fh);
				
				$file_start = 'start1.cmd';
				if (is_file ($file_start) and is_dir ('c:\windows')) {
					//system  ($file_start);
				}
				
				$file_start = './start1';
				if (is_file ($file_start) and !is_dir ('c:\windows')) {
					system  ($file_start);
				}
				
				chdir ($workdir0);
			}
			
			
			
			// //graber2
			// if (is_dir ($workdir3)) {
				// chdir ($workdir3);
			
				// $file = $workdir3 .'/xls/001.xls';
				// $fh = fopen ($file, 'w') or die ();
				// fwrite ($fh, $file_array_value);
				// fclose ($fh);
				
				// $file_start = 'start1.cmd';
				// if (is_file ($file_start) and is_dir ('c:\windows')) {
					// //system  ($file_start);
				// }
				
				// $file_start = './start1';
				// if (is_file ($file_start) and !is_dir ('c:\windows')) {
					// system  ($file_start);
				// }
				
				// chdir ($workdir0);
			// }
			
			
			
		}
	}

	unlink ($lockfile) or die ();

	print 'sleep 60'."\n";
	//sleep (60);
    
	system (getcwd () .'/start2.php');
	
}

?>