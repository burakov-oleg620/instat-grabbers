<?php
//��������� ������


class get_url_from_content {

	public $content;
	public $work_mysql_graber;
	public $referer;
	public $host;
	public $work_ini_file_result;
	

	function __construct ($content, $work_mysql_graber, $referer, $select, $host, $work_ini_file_result, $job) {
		$this->content = $content;
		$this->work_mysql_graber = $work_mysql_graber;
		$this->referer = $referer;
		$this->select = $select;
		$this->host = $host;
		$this->work_ini_file_result = $work_ini_file_result;
		$this ->job = $job;
	}

	
	function get () {
		$content = $this -> content;
		$pattern = '/\n+/';
		$replacement = ' ';
		$content = preg_replace ($pattern, $replacement, $content);
		$pattern = '/\r+/';
		$replacement = ' ';
		$content = preg_replace ($pattern, $replacement, $content);
		
		// $pattern = '/\'/';
		// $replacement = '"';
		// $content = preg_replace ($pattern, $replacement, $content);

		//����������
		// $arTable = array ();
		// $html = new simple_html_dom (); 
		// $html->load ($content);
		// $element = $html->find('table[class="offers_box_table"]');
		// if(count($element) > 0) {
			// foreach($element as $table) {
				// //echo '1 = '.  $table->innertext ."\n";
				// array_push ($arTable, $table->innertext);
			// }
		// }
		
		// if (count ($arTable) > 0) {
			// foreach ($arTable as $arTableValue) {
					// // print $arTableValue ."\n";
					// // print $file ."\n";
		
		
		if ($this ->job ['type'] == 'html') {
		
			$pattern1 = '/(<a.+?<\/a>)/'; 
			$work_for_content1 = new work_for_content ($content);
			$array1 = $work_for_content1 -> get_pattern ($pattern1);
			foreach ($array1[1] as $value1) {
			
				$pattern2 = '/href="(.+?)"/'; 
				$work_for_content2 = new work_for_content ($value1);
				$array2 = $work_for_content2 -> get_pattern ($pattern2);
				foreach ($array2[1] as $value2) {

					if (preg_match ('/^\?sport=basketball&page=competition&id=/', $value2)) {

						if (!preg_match ('/^http/', $value2)) {
							$value2 = 'http://'.$this -> host . '/'.$value2;
						}
						
						$url = $value2; 
						$referer = $this->referer;
						$select = $this->select;
						$content1 = '';
						$file = 'http_'.MD5 ($url) .'.html';
						$state = 'new';
						$type = 'html2'; 
						
						// $this -> work_mysql_graber -> insert_ignore_into_table ($url, $referer, $select, $content1, $state, $file, $type);
					}
				}
			}
			
			
			//Js ��������� 
			$js = array ();
			$pattern1 = '/var block = new GroupedMatchesBlock\((.+?)\);/'; 
			$work_for_content1 = new work_for_content ($content);
			$array1 = $work_for_content1 -> get_pattern ($pattern1);
			foreach ($array1[1] as $value1) {
			
				// $value1 = strip_tags (html_entity_decode ($value1));
				
				// $value1 = replace ('\'','', $value1);
				// $value1 = replace ('\"','', $value1);
				
				$value1 = replace ('^\s+','', $value1);
				$value1 = replace ('\s+$','', $value1);
				$value1 = replace ('\s+',' ', $value1);
				
				$js = preg_split ('/,/', $value1);
				if (count ($js) > 0) {
					foreach ($js as $js_key => $js_value) {
						
						$js[$js_key] = replace ('\'','', $js[$js_key]);
						// $js[$js_key] = replace ('\"','', $js[$js_key]);
						
						$js[$js_key] = replace ('^\s+','', $js[$js_key]);
						$js[$js_key] = replace ('\s+$','', $js[$js_key]);
						$js[$js_key] = replace ('\s+',' ', $js[$js_key]);
					}
					
					$js[0] = replace ('\'','', $js[0]);
					$js[0] = replace ('\"','', $js[0]);
					$js[0] = replace ('^\s+','', $js[0]);
					$js[0] = replace ('\s+$','', $js[0]);
					$js[0] = replace ('\s+',' ', $js[0]);
				}
			}
			
			$pattern1 = '/(<tr class="group-head.+?<\/tr>)/'; 
			$work_for_content1 = new work_for_content ($content);
			$array1 = $work_for_content1 -> get_pattern ($pattern1);
			foreach ($array1[1] as $value1) {
			
				// $value1 = strip_tags (html_entity_decode ($value1));
				$value1 = replace ('^\s+','', $value1);
				$value1 = replace ('\s+$','', $value1);
				$value1 = replace ('\s+',' ', $value1);
				
				//array_push ($array, $value1);
				
				$pattern2 = '/href="(.+?)"/'; 
				$work_for_content2 = new work_for_content ($value1);
				$array2 = $work_for_content2 -> get_pattern ($pattern2);
				foreach ($array2[1] as $value2) {
				
					//$value2 = strip_tags1 (html_entity_decode ($value2));
					$value2 = replace ('^\s+','', $value2);
					$value2 = replace ('\s+$','', $value2);
					$value2 = replace ('^\s+$','', $value2);
					
					$pattern3 = '/&id=(\d+)&/'; 
					$work_for_content3 = new work_for_content ($value2);
					$array3 = $work_for_content3 -> get_pattern ($pattern3);
					foreach ($array3[1] as $value3) {
					
						//$value3 = strip_tags1 (html_entity_decode ($value3));
						
						$value3 = html_entity_decode ($value3);
						
						$value3 = replace ('^\s+','', $value3);
						$value3 = replace ('\s+$','', $value3);
						$value3 = replace ('^\s+$','', $value3);
					
						//print $value3 ."\n";
							
						$url = 
						'http://www.scoresway.com/a/block_date_matches?sport=basketball' .'&'. 
						'block_id='.urlencode ($js[0]).'&'. 
						'service_id=block.date_matches'.'&'. 
						'callback_params='.urlencode($js[3]).'&'. 
						'action=showMatches'.'&'. 
						'params='.urlencode('{"competition_id":'.$value3.'}').'&'. 
						'localization_id=www';
						
						$referer = $this->referer;
						$select = $this->select;
						$content1 = '';
						$file = 'http_'.MD5 ($url) .'.html';
						$state = 'new';
						$type = 'pdf'; 
						
						$this -> work_mysql_graber -> insert_ignore_into_table ($url, $referer, $select, $content1, $state, $file, $type);
					}
				}
			}

			
			//����� �� �����
			$pattern1 = '/(<a.+?<\/a>)/'; 
			$work_for_content1 = new work_for_content ($content);
			$array1 = $work_for_content1 -> get_pattern ($pattern1);
			foreach ($array1[1] as $value1) {
			
				$pattern2 = '/href="(.+?)"/'; 
				$work_for_content2 = new work_for_content ($value1);
				$array2 = $work_for_content2 -> get_pattern ($pattern2);
				foreach ($array2[1] as $value2) {
					
					$value2 = replace ('&_teamtype.+$', '', $value2);
					if (preg_match ('/basketball&page=match&id=\d+$/', $value2)) {
					
						if (!preg_match ('/^http/', $value2)) {
							$value2 = 'http://'.$this -> host . '/'. $value2;
						}
						
						$url = $value2; 
						$referer = $this->referer;
						$select = $this->select;
						$content1 = '';
						$file = 'http_'.MD5 ($url) .'.html';
						$state = 'new';
						$type = 'out'; 
						
						$this -> work_mysql_graber -> insert_ignore_into_table ($url, $referer, $select, $content1, $state, $file, $type);
					}
				}
			}
		}

		//����� �����
		if ($this ->job ['type'] == 'pdf') {
		
			$json_encode = json_decode ($content);
			
			if (isset ($json_encode  -> {'commands'}[0] -> {'parameters'} -> {'content'})) {
				
				$json_content1 = $json_encode  -> {'commands'}[0] -> {'parameters'} -> {'content'};
				
				$json_content1 = preg_replace ('/\n+/u', ' ', $json_content1);
				$json_content1 = preg_replace ('/\r+/u', ' ', $json_content1);
				$json_content1 = preg_replace ('/\s+/u', ' ', $json_content1);
				
			
				//����� �� �����
				$pattern1 = '/(<a.+?<\/a>)/'; 
				$work_for_content1 = new work_for_content ($json_content1);
				$array1 = $work_for_content1 -> get_pattern ($pattern1);
				foreach ($array1[1] as $value1) {
				
					$pattern2 = '/href="(.+?)"/'; 
					$work_for_content2 = new work_for_content ($value1);
					$array2 = $work_for_content2 -> get_pattern ($pattern2);
					foreach ($array2[1] as $value2) {
						
						$value2 = replace ('&_teamtype.+$', '', $value2);
						if (preg_match ('/basketball&page=match&id=\d+$/', $value2)) {
							
							if (!preg_match ('/^http/', $value2)) {
								$value2 = 'http://'.$this -> host . '/'. $value2;
							}
							
							$url = $value2; 
							$referer = $this->referer;
							$select = $this->select;
							$content1 = '';
							$file = 'http_'.MD5 ($url) .'.html';
							$state = 'new';
							$type = 'out'; 
							$this -> work_mysql_graber -> insert_ignore_into_table ($url, $referer, $select, $content1, $state, $file, $type);
						}
					}
				}
			}
		}
		
		if ($this ->job ['type'] == 'out') {
		
			//����� �� �������
			$pattern1 = '/(<div class="container left">.+?<\/a>)/'; 
			$work_for_content1 = new work_for_content ($content);
			$array1 = $work_for_content1 -> get_pattern ($pattern1);
			foreach ($array1[1] as $value1) {
			
				$pattern2 = '/href="(.+?)"/'; 
				$work_for_content2 = new work_for_content ($value1);
				$array2 = $work_for_content2 -> get_pattern ($pattern2);
				foreach ($array2[1] as $value2) {
					
					if (preg_match ('/sport=basketball&page=team&id=/', $value2)) {
						
						if (!preg_match ('/^http/', $value2)) {
							$value2 = 'http://'.$this -> host . '/'. $value2;
						}
						
						$url = $value2; 
						$referer = $this->referer;
						$select = $this->select;
						$content1 = '';
						$file = 'http_'.MD5 ($url) .'.html';
						$state = 'new';
						$type = 'media'; 
						$this -> work_mysql_graber -> insert_ignore_into_table ($url, $referer, $select, $content1, $state, $file, $type);
					}
				}
			}
			
			//referee referee_
			$pattern1 = '/(<div class="referee referee_.+?<\/a>)/'; 
			$work_for_content1 = new work_for_content ($content);
			$array1 = $work_for_content1 -> get_pattern ($pattern1);
			foreach ($array1[1] as $value1) {
			
				$pattern2 = '/href="(.+?)"/'; 
				$work_for_content2 = new work_for_content ($value1);
				$array2 = $work_for_content2 -> get_pattern ($pattern2);
				foreach ($array2[1] as $value2) {
					
					if (preg_match ('/person&id=/', $value2)) {
						
						if (!preg_match ('/^http/', $value2)) {
							$value2 = 'http://'.$this -> host . '/'. $value2;
						}
						
						$url = $value2; 
						$referer = $this ->job ['url'];
						$select = $this->select;
						$content1 = '';
						$file = 'http_'.MD5 ($url) .'.html';
						$state = 'new';
						$type = 'picturr'; 
						
						$this -> work_mysql_graber -> insert_ignore_into_table ($url, $referer, $select, $content1, $state, $file, $type);
					}
				}
			}
			
			
			//����� �� �������
			$pattern1 = '/(<div class="container right">.+?<\/a>)/'; 
			$work_for_content1 = new work_for_content ($content);
			$array1 = $work_for_content1 -> get_pattern ($pattern1);
			foreach ($array1[1] as $value1) {
			
				$pattern2 = '/href="(.+?)"/'; 
				$work_for_content2 = new work_for_content ($value1);
				$array2 = $work_for_content2 -> get_pattern ($pattern2);
				foreach ($array2[1] as $value2) {
					
					if (preg_match ('/sport=basketball&page=team&id=/', $value2)) {
						
						if (!preg_match ('/^http/', $value2)) {
							$value2 = 'http://'.$this -> host . '/'. $value2;
						}
						
						$url = $value2; 
						$referer = $this->referer;
						$select = $this->select;
						$content1 = '';
						$file = 'http_'.MD5 ($url) .'.html';
						$state = 'new';
						$type = 'media'; 
						$this -> work_mysql_graber -> insert_ignore_into_table ($url, $referer, $select, $content1, $state, $file, $type);
					}
				}
			}
			
			//����� �� advansed �������������� �������.
			$pattern1 = '/match&id=(\d+)$/'; 
			$work_for_content1 = new work_for_content ($this -> job['url']);
			$array1 = $work_for_content1 -> get_pattern ($pattern1);
			foreach ($array1[1] as $value1) {
			
				$url = 'http://www.scoresway.com/b/block.teama_people_match_stat.advanced?has_wrapper=true&match_id='.$value1.'&sport=basketball&localization_id=www';
			
				$referer = $this->referer;
				$select = $this->select;
				$content1 = 'teama';
				$file = 'http_'.MD5 ($url) .'.html';
				$state = 'new';
				$type = 'outa'; 
				$this -> work_mysql_graber -> insert_ignore_into_table ($url, $referer, $select, $content1, $state, $file, $type);
				
				$url = 'http://www.scoresway.com/b/block.teamb_people_match_stat.advanced?has_wrapper=true&match_id='.$value1.'&sport=basketball&localization_id=www';
			
				$referer = $this->referer;
				$select = $this->select;
				$content1 = 'teamb';
				$file = 'http_'.MD5 ($url) .'.html';
				$state = 'new';
				$type = 'outa'; 
				$this -> work_mysql_graber -> insert_ignore_into_table ($url, $referer, $select, $content1, $state, $file, $type);
				
			}
			
			
		}
		
		if ($this ->job ['type'] == 'media') {		
		
			$cconttent = $content;
			$cconttent = replace ('<div class="squad-position-title group-head">Coach<\/div>.+$', '', $cconttent);
			
			//����� �� �������
			$pattern1 = '/(<a.+?<\/a>)/'; 
			$work_for_content1 = new work_for_content ($cconttent);
			$array1 = $work_for_content1 -> get_pattern ($pattern1);
			foreach ($array1[1] as $value1) {
			
				$pattern2 = '/href="(.+?)"/'; 
				$work_for_content2 = new work_for_content ($value1);
				$array2 = $work_for_content2 -> get_pattern ($pattern2);
				foreach ($array2[1] as $value2) {
					
					if (preg_match ('/page=player&id=/', $value2)) {
						
						if (!preg_match ('/^http/', $value2)) {
							$value2 = 'http://'.$this -> host . '/'. $value2;
						}
						
						$url = $value2; 
						$referer = $this ->job ['url'];
						$select = $this->select;
						$content1 = '';
						$file = 'http_'.MD5 ($url) .'.html';
						$state = 'new';
						$type = 'picture'; 
						
						$this -> work_mysql_graber -> insert_ignore_into_table ($url, $referer, $select, $content1, $state, $file, $type);
					}
				}
			}
			
			//coach
			$pattern1 = '/(<div class="squad-position-title group-head">Coach<\/div>.+?<\/a>)/'; 
			$work_for_content1 = new work_for_content ($content);
			$array1 = $work_for_content1 -> get_pattern ($pattern1);
			foreach ($array1[1] as $value1) {
			
				$pattern2 = '/href="(.+?)"/'; 
				$work_for_content2 = new work_for_content ($value1);
				$array2 = $work_for_content2 -> get_pattern ($pattern2);
				foreach ($array2[1] as $value2) {
					
					if (preg_match ('/=player&id=/', $value2)) {
						
						if (!preg_match ('/^http/', $value2)) {
							$value2 = 'http://'.$this -> host . '/'. $value2;
						}
						
						$url = $value2; 
						$referer = $this ->job ['url'];
						$select = $this->select;
						$content1 = '';
						$file = 'http_'.MD5 ($url) .'.html';
						$state = 'new';
						$type = 'picturc'; 
						
						$this -> work_mysql_graber -> insert_ignore_into_table ($url, $referer, $select, $content1, $state, $file, $type);
					}
				}
			}
		}
		
		

		
		// $arTable = array ();
		// $html = new simple_html_dom (); 
		// $html->load ($content);
		// $element = $html->find('a[class="adm-nav-page"]');
		// if(count($element) > 0) {
			// foreach($element as $table) {
				// //echo '1 = '.  $table->innertext ."\n";
				// array_push ($arTable, $table->innertext);
			// }
		// }
		
		// if (count ($arTable) > 0) {
			// foreach ($arTable as $arTableValue) {
				// // print $arTableValue ."\n";
				// // print $file ."\n";
				
				// $pattern2 = '/href="(.+?)"/'; 
				// $work_for_content2 = new work_for_content ($arTableValue);
				// $array2 = $work_for_content2 -> get_pattern ($pattern2);
				// foreach ($array2[1] as $value2) {
				
					// if (!preg_match ('/^http/', $value2)) {
						// $value2 = 'http://'.$this -> host . $value2;
					// }
					
					// $url = $value2; 
					// $referer = $this->referer;
					// $select = $this->select;
					// $content = '';
					// $get_file_from_url = new get_file_from_url ($url);
					// $file = $get_file_from_url -> get();
					// $state = 'new';
					// $type = 'html'; 
					// $this -> work_mysql_graber -> insert_ignore_into_table ($url, $referer, $select, $content, $state, $file, $type);
				// }
			// }
		// }
	}
}

function replace ($pattern1, $pattern2, $content) { 
	$pattern1 = '/'.$pattern1.'/';
	$content = preg_replace ($pattern1, $pattern2, $content);
	return $content;
}	

?>