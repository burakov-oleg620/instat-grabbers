<?php
ini_set('date.timezone', 'Europe/Moscow');
// setlocale(LC_ALL, 'ru_RU.CP1251', 'rus_RUS.CP1251', 'Russian_Russia.1251');
//setlocale(LC_ALL, 'ru_RU.utf8', 'rus_RUS.ut8', 'Russian_Russia.utf8');
// setlocale(LC_ALL,"russian");
setlocale(LC_ALL, 'ru_RU.UTF-8');

error_reporting(E_ALL | E_STRICT) ;
ini_set('display_errors', 'On');		
set_time_limit(0); //устанавливаем время на безлимит
flush ();


include 'get_base_path_inc.php';
include 'clear_str_inc.php';
include 'work_for_content_inc.php';
include 'work_for_txt1_inc.php';
include 'write_text_file_rewrite_inc.php';
include 'simple_html_dom.php';
include 'work_ini_file_inc.php';
include 'work_mysql_graber_inc.php';
include 'get_file_from_url_inc.php';


$work_ini_file = new work_ini_file ('graber.ini');
$host_mysql = $work_ini_file -> get ('host_mysql');
$user = $work_ini_file -> get ('user');
$password = $work_ini_file -> get ('password');
$table = $work_ini_file -> get ('table');
$database = $work_ini_file -> get ('database');
$host = $work_ini_file -> get ('host');
$count_limit = $work_ini_file -> get ('count_limit');
$count_start_from_ini = $work_ini_file -> get ('count_start_from_ini');

//$work_mysql_graber = new work_mysql_graber ($host_mysql, $user, $password, $table, $database);


$get_base_path = new get_base_path;
$workdir = $get_base_path -> get ();
$workdir2 = $workdir .'/txt';
$file2 = $workdir2.'/write_text_file_rewrite1.xls';

$write_text_file_rewrite = new write_text_file_rewrite ($file2);

$workdir = $workdir .'/html';

$count = 0;

$dh = opendir ($workdir) or die;
while ($file = readdir ($dh)) {
	if ($file != '.' and $file != '..') {
		$file = $workdir.'/'.$file;
		$pattern = '/http_/';
		// preg_match ($pattern, $file, $array);
		// if (count ($array) > 0) {
		
		if (preg_match ($pattern, $file)) {
			print ++$count ."\n";
		
			$file_array = array ();
			$fh = fopen ($file, 'r') or die;
			while ($str = fgets ($fh)) {
				$clear_str = new clear_str ($str);
				$str = $clear_str -> delete_2 ();
				unset ($clear_str); 
				array_push ($file_array, $str);
			}
			fclose ($fh);
			
			$content = join (' ', $file_array);
			
			
			// $content2 = json_decode ($content);
			// // print var_dump ($content2) ."\n";
			// //print var_dump ($content2 -> {'team'} -> {'squad'}) ."\n";
			
			// foreach ($content2 -> {'team'} -> {'squad'} as $key => $value) {
				// print $value -> {'id'} ."\n";
			// }
			
			
			
			// print $content ."\n";
			//$content = iconv ("utf-8", "windows-1251", $content); 
			// $content = iconv ("utf-8", "windows-1251//IGNORE", $content); 
			// $content = iconv ("utf-8", "windows-1251//TRANSLIT//IGNORE", $content); 
			// print $content ."\n";
			
			// $arTable = array ();
			// $html = new simple_html_dom (); 
			// $html->load ($content);
			// $element = $html->find('table[class="offers_box_table"]');
			// //$element2 = $html->find('div[class="navig"]');
			// if(count($element) > 0) {
				// foreach($element as $table) {
					// //echo '1 = '.  $table->innertext ."\n";
					// array_push ($arTable, $table->innertext);
				// }
			// }
			
			// $table = array ();
			// if (count ($arTable) > 0) {
				// foreach ($arTable as $arTableValue) {
					// // print $arTableValue ."\n";
					// // print $file ."\n";
					
			$json = @json_decode($content, true);
			//print_r ($json) ."\n";
			
			if (is_array ($json)) {

				foreach  ($json as $gkey1 => $gvalue1) {
					if (is_array ($gvalue1)) {
						
						foreach  ($gvalue1 as $gkey2 => $gvalue2) {
							if (is_array ($gvalue2)) {
								
								foreach  ($gvalue2 as $gkey3 => $gvalue3) {
									if (is_array ($gvalue3)) {
										
										//print_r ($gvalue3) ."\n";
										//print_r ($gvalue3 ['awayteam']) ."\n";
										
										$work_for_txt1 = new work_for_txt1 (); 
										
										$id = '';
										$array = array ();					
										$pattern1 = '/^(.+)$/'; 
										$work_for_content1 = new work_for_content ($gvalue3['igameid']);
										$array1 = $work_for_content1 -> get_pattern ($pattern1);
										foreach ($array1[1] as $value1) {
										
											$value1 = strip_tags (html_entity_decode ($value1));
											$value1 = replace ('^\s+','', $value1);
											$value1 = replace ('\s+$','', $value1);
											$value1 = replace ('\s+',' ', $value1);
											
											array_push ($array, $value1);
										}
										
										if (count ($array) > 0) {
											$str = join ('||', $array);
											$work_for_txt1 -> put ($array[0]); 
											$id = $array[0];
										} else {
											$work_for_txt1 -> put ('-'); 
										}
										
	
										//date
										$array = array ();					
										$pattern1 = '/^(.+)$/'; 
										$work_for_content1 = new work_for_content ($gvalue3['dtegametimefixed']);
										$array1 = $work_for_content1 -> get_pattern ($pattern1);
										foreach ($array1[1] as $value1) {
										
											$value1 = strip_tags (html_entity_decode ($value1));
											$value1 = replace ('^\s+','', $value1);
											$value1 = replace ('\s+$','', $value1);
											$value1 = replace ('\s+',' ', $value1);
											
											array_push ($array, $value1);
										}
										
										if (count ($array) > 0) {
											$str = join ('||', $array);
											$work_for_txt1 -> put ($array[0]); 
										} else {
											$work_for_txt1 -> put ('-'); 
										}
										
										
										//away_team
										$array = array ();					
										$pattern1 = '/^(.+)$/'; 
										$work_for_content1 = new work_for_content ($gvalue3 ['awayteam']['iteamid']);
										$array1 = $work_for_content1 -> get_pattern ($pattern1);
										foreach ($array1[1] as $value1) {
										
											$value1 = strip_tags (html_entity_decode ($value1));
											$value1 = replace ('^\s+','', $value1);
											$value1 = replace ('\s+$','', $value1);
											$value1 = replace ('\s+',' ', $value1);
											
											array_push ($array, $value1);
										}
										
										if (count ($array) > 0) {
											$str = join ('||', $array);
											$work_for_txt1 -> put ($array[0]); 
										} else {
											$work_for_txt1 -> put ('-'); 
										}
										
										//away_team_name
										$array = array ();					
										$pattern1 = '/^(.+)$/'; 
										$work_for_content1 = new work_for_content ($gvalue3 ['awayteam']['label']);
										$array1 = $work_for_content1 -> get_pattern ($pattern1);
										foreach ($array1[1] as $value1) {
										
											$value1 = strip_tags (html_entity_decode ($value1));
											$value1 = replace ('^\s+','', $value1);
											$value1 = replace ('\s+$','', $value1);
											$value1 = replace ('\s+',' ', $value1);
											
											array_push ($array, $value1);
										}
										
										if (count ($array) > 0) {
											$str = join ('||', $array);
											$work_for_txt1 -> put ($array[0]); 
										} else {
											$work_for_txt1 -> put ('-'); 
										}
										
										//home_team
										$array = array ();					
										$pattern1 = '/^(.+)$/'; 
										$work_for_content1 = new work_for_content ($gvalue3 ['hometeam']['iteamid']);
										$array1 = $work_for_content1 -> get_pattern ($pattern1);
										foreach ($array1[1] as $value1) {
										
											$value1 = strip_tags (html_entity_decode ($value1));
											$value1 = replace ('^\s+','', $value1);
											$value1 = replace ('\s+$','', $value1);
											$value1 = replace ('\s+',' ', $value1);
											
											array_push ($array, $value1);
										}
										
										if (count ($array) > 0) {
											$str = join ('||', $array);
											$work_for_txt1 -> put ($array[0]); 
										} else {
											$work_for_txt1 -> put ('-'); 
										}
										
										//home_team_name
										$array = array ();					
										$pattern1 = '/^(.+)$/'; 
										$work_for_content1 = new work_for_content ($gvalue3 ['hometeam']['label']);
										$array1 = $work_for_content1 -> get_pattern ($pattern1);
										foreach ($array1[1] as $value1) {
										
											$value1 = strip_tags (html_entity_decode ($value1));
											$value1 = replace ('^\s+','', $value1);
											$value1 = replace ('\s+$','', $value1);
											$value1 = replace ('\s+',' ', $value1);
											
											array_push ($array, $value1);
										}
										
										if (count ($array) > 0) {
											$str = join ('||', $array);
											$work_for_txt1 -> put ($array[0]); 
										} else {
											$work_for_txt1 -> put ('-'); 
										}
										
										//league_id
										$array = array ();					
										$pattern1 = '/^(.+)$/'; 
										$work_for_content1 = new work_for_content ($gvalue3 ['league']['ileagueid']);
										$array1 = $work_for_content1 -> get_pattern ($pattern1);
										foreach ($array1[1] as $value1) {
										
											$value1 = strip_tags (html_entity_decode ($value1));
											$value1 = replace ('^\s+','', $value1);
											$value1 = replace ('\s+$','', $value1);
											$value1 = replace ('\s+',' ', $value1);
											
											array_push ($array, $value1);
										}
										
										if (count ($array) > 0) {
											$str = join ('||', $array);
											$work_for_txt1 -> put ($array[0]); 
										} else {
											$work_for_txt1 -> put ('-'); 
										}
										
										//league_name
										$array = array ();					
										$pattern1 = '/^(.+)$/'; 
										$work_for_content1 = new work_for_content ($gvalue3 ['league']['strleaguename']);
										$array1 = $work_for_content1 -> get_pattern ($pattern1);
										foreach ($array1[1] as $value1) {
										
											$value1 = strip_tags (html_entity_decode ($value1));
											$value1 = replace ('^\s+','', $value1);
											$value1 = replace ('\s+$','', $value1);
											$value1 = replace ('\s+',' ', $value1);
											
											array_push ($array, $value1);
										}
										
										if (count ($array) > 0) {
											$str = join ('||', $array);
											$work_for_txt1 -> put ($array[0]); 
										} else {
											$work_for_txt1 -> put ('-'); 
										}
										
										//league_nick
										$array = array ();					
										$pattern1 = '/^(.+)$/'; 
										$work_for_content1 = new work_for_content ($gvalue3 ['league']['strleaguenickname']);
										$array1 = $work_for_content1 -> get_pattern ($pattern1);
										foreach ($array1[1] as $value1) {
										
											$value1 = strip_tags (html_entity_decode ($value1));
											$value1 = replace ('^\s+','', $value1);
											$value1 = replace ('\s+$','', $value1);
											$value1 = replace ('\s+',' ', $value1);
											
											array_push ($array, $value1);
										}
										
										if (count ($array) > 0) {
											$str = join ('||', $array);
											$work_for_txt1 -> put ($array[0]); 
										} else {
											$work_for_txt1 -> put ('-'); 
										}
										

										//video_url
										$array = array ();					
										//$f = getcwd ().'/outc/http_'.$id.'.html';
										$f = getcwd ().'/outa/http_'.$id.'.html';
										//$f = getcwd ().'/outa/http_'.$id.'.html';
										if (is_file ($f)) {
										
											$array = array ();		
											
											$cc = file_get_contents ($f);
											$json = json_decode ($cc, true);
											if (isset ($json['video'])) {
												if (preg_match ('/^http/ui',$json['video'] )) {
													array_push ($array, $json['video']);	
												}
											}
											
											// $fh = fopen ($f, 'r') or die ();
											// while ($str = fgets ($fh)) {
												
												
												// $str = str_replace (array ("\t", "\n", "\r"), ' ', $str);
											
												// $pattern1 = '/(http.+?)\s+/'; 
												// $work_for_content1 = new work_for_content ($str);
												// $array1 = $work_for_content1 -> get_pattern ($pattern1);
												// foreach ($array1[1] as $value1) {
												
													// $value1 = trim (strip_tags (html_entity_decode ($value1)));
													// $value1 = replace ('^\s+','', $value1);
													// $value1 = replace ('\s+$','', $value1);
													// $value1 = replace ('\s+',' ', $value1);
													
													// array_push ($array, $value1);
												// }
											// }
											// fclose ($fh);
											
										}
										
										if (count ($array) > 0) {
											$str = join ('||', $array);
											$work_for_txt1 -> put ($str); 
										} else {
											$work_for_txt1 -> put ('-'); 
										}
										
										
										$str = $work_for_txt1 -> get ();
										$write_text_file_rewrite -> put_str ($str ."\n");
										unset ($work_for_txt1);
										
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
closedir ($dh);



function get_param ($str, $pattern) {
	preg_match_all ($pattern, $str, $array);
	return $array;
}

function strip_tags1 ($str) {
	$str = replace ('<.+?>', ' ', $str);
	return $str;
}

function replace ($pattern1, $pattern2, $content) { 
	$pattern1 = '/'.$pattern1.'/u';
	$content = preg_replace ($pattern1, $pattern2, $content);
	return $content;
}	


?>