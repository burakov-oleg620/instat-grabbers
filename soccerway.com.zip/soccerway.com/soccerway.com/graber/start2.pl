#!/usr/bin/env perl
use strict;
use warnings;
use Cwd;
use lib getcwd ();

my $system = undef;

$system = './fail_to_new.pl';
system ($system); 

$system = './work1.pl';
system ($system); 

$system = './graber.pl';
system ($system); 

$system = './parser_html1.pl';
system ($system); 

$system = './parser_html2.pl';
system ($system); 

$system = './parser_html3.pl';
system ($system); 

$system = './parser_html4.pl';
system ($system); 

$system = './parser_html5.pl';
system ($system); 

$system = './parser_html6.pl';
system ($system); 

$system = './parser_txt1.pl'; 
system ($system); 

$system = './parser_txt11.pl'; 
system ($system); 

$system = './parser_txt2.pl'; 
system ($system); 

$system = './parser_txt3.pl'; 
system ($system); 

$system = './parser_txt4.pl'; 
system ($system); 

$system = './parser_txt6.pl'; 
system ($system); 

$system = './parser_txt66.pl'; 
system ($system); 



