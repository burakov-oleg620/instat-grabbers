#!/usr/bin/env perl
use strict;
use warnings;



my $system = undef;

$system = '/usr/local/bin/perl ./clear_dir.pl';
system ($system); 

$system = '/usr/local/bin/perl ./clear_table.pl';
system ($system); 

$system = '/usr/local/bin/perl ./work3.pl';
system ($system); 

$system = '/usr/local/bin/perl ./graber.pl';
system ($system); 

$system = '/usr/local/bin/perl ./parser_html1.pl';
system ($system); 

$system = '/usr/local/bin/perl ./parser_html2.pl';
system ($system); 

$system = '/usr/local/bin/perl ./parser_html3.pl';
system ($system); 

$system = '/usr/local/bin/perl ./parser_html4.pl';
system ($system); 

$system = '/usr/local/bin/perl ./parser_html5.pl';
system ($system); 

$system = '/usr/local/bin/perl ./parser_html6.pl';
system ($system); 

$system = '/usr/local/bin/perl ./parser_txt1.pl'; 
system ($system); 

$system = '/usr/local/bin/perl ./parser_txt11.pl'; 
system ($system); 

$system = '/usr/local/bin/perl ./parser_txt2.pl'; 
system ($system); 

$system = '/usr/local/bin/perl ./parser_txt3.pl'; 
system ($system); 

$system = '/usr/local/bin/perl ./parser_txt4.pl'; 
system ($system); 

$system = '/usr/local/bin/perl ./parser_txt6.pl'; 
system ($system); 

$system = '/usr/local/bin/perl ./parser_txt66.pl'; 
system ($system); 

#$system = './start4.pl'; 
#system ($system); 

#$system = './start4.pl'; 
#system ($system); 

